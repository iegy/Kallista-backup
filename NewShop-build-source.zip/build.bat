@echo off
setlocal
cd /d "%~dp0"
echo NewShop 2.0.0 - verified Windows build
powershell -NoProfile -ExecutionPolicy Bypass -File ".\build.ps1"
exit /b %errorlevel%
