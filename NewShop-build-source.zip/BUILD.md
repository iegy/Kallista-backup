# بناء NewShop 2.0.0 على Windows x64

## المتطلبات

1. Windows 10/11 x64.
2. Node.js LTS وnpm.
3. Rust stable عبر `rustup` مع target `x86_64-pc-windows-msvc`.
4. Visual Studio Build Tools مع Desktop development with C++ وWindows SDK.
5. WebView2 Runtime. أداة Tauri تبني NSIS تلقائيًا من إعدادات `src-tauri/tauri.conf.json`.

## البناء الموثق

من PowerShell داخل مجلد المشروع:

```powershell
.\build.bat
```

ينفذ `build.ps1` بالترتيب:

1. فحص Node/npm/Rust.
2. `npm ci` من `package-lock.json`.
3. TypeScript وكل اختبارات JavaScript، ثم اختبارات Rust للتطبيق وأداة التراخيص.
4. `npm run tauri:build` لإنتاج مثبت NSIS x64 حقيقي.
5. بناء `NewShop-License-Manager.exe`.
6. إنشاء Source ZIP بدون أسرار وPortable ZIP.
7. إنشاء `SHA256SUMS.txt` وفحص عدم وجود المفتاح الخاص خارج مجلد المالك.

## الملفات المتوقعة

- `NewShop-2.0.0-Setup-x64.exe`
- `NewShop-2.0.0-Portable-x64.zip`
- `NewShop-2.0.0-Source.zip`
- `OWNER_ONLY_DO_NOT_SHARE/NewShop-License-Manager.exe`
- `SHA256SUMS.txt`
- `OWNER_ONLY_DO_NOT_SHARE/newshop-private.key`

## فحص يدوي إلزامي قبل التسليم

- تثبيت نظيف على Windows وحذف/إعادة التثبيت بدون فقد بيانات المستخدم.
- تشغيل البرنامج من قائمة Start ومن دون صلاحية Administrator.
- ترقية نسخة فعلية من قاعدة 1.1 بعد أخذ نسخة خارجية منها.
- تسجيل بيع/مرتجع/شراء/مصروف وفتح/إغلاق وردية ومطابقة Z.
- طباعة A4 و80mm و58mm، وتجربة قارئ باركود فعلي.
- تفعيل ترخيص صالح، ثم تجربة كود جهاز آخر وكود منتهي وكود تم العبث به.
- اختبار Backup/Restore ثم فتح قاعدة البيانات المستعادة.

يمكن أيضًا تشغيل workflow `Windows release verification` في GitHub Actions لبناء artifacts على Windows.

## آخر بناء موثق

نجح بناء Windows Server 2022 بتاريخ 2026-08-24: npm/TypeScript/XLSX، اختبارات Rust، Tauri Release، مثبت NSIS، أداة التراخيص ذات واجهة Win32، النسخة Portable، وفحص SHA-256. كما ظهر معالج التثبيت فعليًا، نجح التثبيت الصامت، وظهرت نافذتا NewShop ومدير التراخيص. رقم GitHub Actions run النهائي: `32699709932`.
