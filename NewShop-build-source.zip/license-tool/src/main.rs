//! NewShop 2 License Manager — owner-only offline Ed25519 issuer.
//! The private key is loaded from a separate file and is never embedded.

#![cfg_attr(windows, windows_subsystem = "windows")]

use base64::{engine::general_purpose::URL_SAFE_NO_PAD, Engine as _};
use ed25519_dalek::{Signer, SigningKey};
use serde::Serialize;
use std::fs;
use std::io::{self, BufRead, Write};
use std::path::PathBuf;
use std::time::{SystemTime, UNIX_EPOCH};
use uuid::Uuid;

#[cfg(windows)]
mod gui;

const KEY_FILE: &str = "newshop-private.key";
const LOG_FILE: &str = "licenses.csv";
const B32: &[u8] = b"ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";

#[derive(Debug, Clone, Serialize)]
struct LicensePayload {
    format_version: u8,
    license_id: String,
    customer_name: String,
    device_code: String,
    issued_at: String,
    license_type: String,
    expires_at: Option<String>,
    edition: String,
    features: Vec<String>,
}

#[derive(Debug, Clone)]
struct Request {
    device_code: String,
    customer_name: String,
    license_type: String,
    expires_at: Option<String>,
    edition: String,
    features: Vec<String>,
    notes: String,
    legacy: bool,
}

fn b32_encode(data: &[u8]) -> String {
    let mut out = String::new();
    let (mut buf, mut bits) = (0u32, 0);
    for &b in data {
        buf = (buf << 8) | b as u32;
        bits += 8;
        while bits >= 5 {
            bits -= 5;
            out.push(B32[((buf >> bits) & 31) as usize] as char);
        }
    }
    if bits > 0 {
        out.push(B32[((buf << (5 - bits)) & 31) as usize] as char);
    }
    out
}

fn from_hex(s: &str) -> Option<Vec<u8>> {
    let s: String = s.chars().filter(|c| c.is_ascii_hexdigit()).collect();
    if s.len() % 2 != 0 {
        return None;
    }
    (0..s.len())
        .step_by(2)
        .map(|i| u8::from_str_radix(&s[i..i + 2], 16).ok())
        .collect()
}

fn to_hex(bytes: &[u8]) -> String {
    bytes.iter().map(|b| format!("{b:02x}")).collect()
}

fn exe_dir() -> PathBuf {
    std::env::current_exe()
        .ok()
        .and_then(|p| p.parent().map(|x| x.to_path_buf()))
        .unwrap_or_else(|| PathBuf::from("."))
}

fn key_path() -> PathBuf {
    if let Ok(path) = std::env::var("NEWSHOP_PRIVATE_KEY") {
        if !path.trim().is_empty() { return PathBuf::from(path); }
    }
    let beside_exe = exe_dir().join(KEY_FILE);
    if beside_exe.exists() { beside_exe } else { PathBuf::from(KEY_FILE) }
}

fn load_signing_key(path: &PathBuf) -> Result<SigningKey, String> {
    let raw = fs::read_to_string(&path).map_err(|_| {
        format!("Private key file not found: {}. Put {KEY_FILE} next to this owner-only program.", path.display())
    })?;
    let bytes = from_hex(&raw).ok_or_else(|| "Invalid private key file".to_string())?;
    if bytes.len() != 32 {
        return Err(format!("Bad private key length: expected 32 bytes, found {}", bytes.len()));
    }
    let mut arr = [0u8; 32];
    arr.copy_from_slice(&bytes);
    Ok(SigningKey::from_bytes(&arr))
}

fn clean_code(s: &str) -> String {
    s.chars().filter(|c| c.is_ascii_alphanumeric()).collect::<String>().to_uppercase()
}

fn format_device(s: &str) -> Result<String, String> {
    let clean = clean_code(s);
    if clean.len() != 16 {
        return Err(format!("Device code must contain 16 characters. Found {}.", clean.len()));
    }
    Ok(clean.as_bytes().chunks(4)
        .map(|x| std::str::from_utf8(x).unwrap_or(""))
        .collect::<Vec<_>>().join("-"))
}

fn make_legacy(sk: &SigningKey, device_code: &str) -> Result<String, String> {
    let code = clean_code(&format_device(device_code)?);
    let sig = sk.sign(code.as_bytes());
    Ok(b32_encode(&sig.to_bytes()).as_bytes().chunks(8)
        .map(|x| std::str::from_utf8(x).unwrap_or(""))
        .collect::<Vec<_>>().join("-"))
}

fn make_v2(sk: &SigningKey, req: &Request) -> Result<(LicensePayload, String), String> {
    let device_code = format_device(&req.device_code)?;
    if req.customer_name.trim().is_empty() { return Err("Customer name is required for a V2 license".into()); }
    if req.license_type != "lifetime" && req.license_type != "expiring" {
        return Err("License type must be lifetime or expiring".into());
    }
    if req.license_type == "expiring" {
        let date = req.expires_at.as_deref().ok_or_else(|| "Expiration date is required".to_string())?;
        validate_date(date)?;
        if date < today_utc().as_str() { return Err("Expiration date cannot be in the past".into()); }
    }
    let payload = LicensePayload {
        format_version: 2,
        license_id: Uuid::new_v4().to_string(),
        customer_name: req.customer_name.trim().to_string(),
        device_code,
        issued_at: today_utc(),
        license_type: req.license_type.clone(),
        expires_at: if req.license_type == "expiring" { req.expires_at.clone() } else { None },
        edition: if req.edition.trim().is_empty() { "Professional".into() } else { req.edition.trim().to_string() },
        features: req.features.clone(),
    };
    let json = serde_json::to_vec(&payload).map_err(|e| format!("Cannot serialize license: {e}"))?;
    let encoded = URL_SAFE_NO_PAD.encode(json);
    let signed = format!("NS2.{encoded}");
    let signature = URL_SAFE_NO_PAD.encode(sk.sign(signed.as_bytes()).to_bytes());
    Ok((payload, format!("{signed}.{signature}")))
}

fn validate_date(s: &str) -> Result<(), String> {
    let b = s.as_bytes();
    if b.len() != 10 || b[4] != b'-' || b[7] != b'-' { return Err("Date must use YYYY-MM-DD".into()); }
    let y = s[0..4].parse::<u32>().map_err(|_| "Invalid year")?;
    let m = s[5..7].parse::<u32>().map_err(|_| "Invalid month")?;
    let d = s[8..10].parse::<u32>().map_err(|_| "Invalid day")?;
    if y < 2020 || !(1..=12).contains(&m) || !(1..=31).contains(&d) { return Err("Invalid date".into()); }
    Ok(())
}

fn today_utc() -> String {
    let days = SystemTime::now().duration_since(UNIX_EPOCH).map(|d| d.as_secs() / 86400).unwrap_or(0);
    let (y, m, d) = civil_from_days(days as i64);
    format!("{y:04}-{m:02}-{d:02}")
}

fn civil_from_days(z: i64) -> (i64, u32, u32) {
    let z = z + 719468;
    let era = if z >= 0 { z } else { z - 146096 } / 146097;
    let doe = z - era * 146097;
    let yoe = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365;
    let y = yoe + era * 400;
    let doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
    let mp = (5 * doy + 2) / 153;
    let d = doy - (153 * mp + 2) / 5 + 1;
    let m = mp + if mp < 10 { 3 } else { -9 };
    (y + i64::from(m <= 2), m as u32, d as u32)
}

fn csv(s: &str) -> String { format!("\"{}\"", s.replace('"', "\"\"")) }

fn log_license(payload: &LicensePayload, notes: &str, key: &str) -> io::Result<()> {
    let path = exe_dir().join(LOG_FILE);
    let is_new = !path.exists();
    let mut f = fs::OpenOptions::new().create(true).append(true).open(path)?;
    if is_new {
        writeln!(f, "license_id,customer_name,device_code,issued_at,license_type,expires_at,edition,features,notes,license_key")?;
    }
    writeln!(f, "{},{},{},{},{},{},{},{},{},{}",
        csv(&payload.license_id), csv(&payload.customer_name), csv(&payload.device_code), csv(&payload.issued_at),
        csv(&payload.license_type), csv(payload.expires_at.as_deref().unwrap_or("")), csv(&payload.edition),
        csv(&payload.features.join(";")), csv(notes), csv(key))
}

fn export_license(name: &str, key: &str) -> io::Result<PathBuf> {
    let safe: String = name.chars().map(|c| if c.is_ascii_alphanumeric() || c == '-' || c == '_' { c } else { '_' }).collect();
    let base = if safe.is_empty() { "NewShop-License" } else { &safe };
    let path = exe_dir().join(format!("{base}.lic"));
    fs::write(&path, key)?;
    Ok(path)
}

fn emit(sk: &SigningKey, req: Request) -> bool {
    if req.legacy {
        match make_legacy(sk, &req.device_code) {
            Ok(key) => {
                println!("\nLEGACY LIFETIME LICENSE\n{key}\n");
                match export_license(&clean_code(&req.device_code), &key) {
                    Ok(path) => println!("Saved: {}", path.display()),
                    Err(e) => println!("[WARN] Cannot export license: {e}"),
                }
                true
            }
            Err(e) => { println!("[ERROR] {e}"); false }
        }
    } else {
        match make_v2(sk, &req) {
            Ok((payload, key)) => {
                println!("\nLICENSE ID : {}", payload.license_id);
                println!("CUSTOMER   : {}", payload.customer_name);
                println!("DEVICE     : {}", payload.device_code);
                println!("TYPE       : {}", payload.license_type);
                println!("LICENSE:\n{key}\n");
                match export_license(&payload.license_id, &key) {
                    Ok(path) => println!("Saved: {}", path.display()),
                    Err(e) => println!("[WARN] Cannot export license: {e}"),
                }
                if let Err(e) = log_license(&payload, &req.notes, &key) { println!("[WARN] Cannot update local issue log: {e}"); }
                true
            }
            Err(e) => { println!("[ERROR] {e}"); false }
        }
    }
}

fn request_from_line(line: &str, legacy: bool) -> Request {
    let (device, customer) = line.split_once('=').map(|(d, c)| (d.trim(), c.trim())).unwrap_or((line.trim(), ""));
    Request { device_code: device.into(), customer_name: customer.into(), license_type: "lifetime".into(), expires_at: None,
        edition: "Professional".into(), features: vec![], notes: String::new(), legacy }
}

fn arg_value(args: &[String], flag: &str) -> Option<String> {
    let i = args.iter().position(|a| a == flag)?;
    args.get(i + 1).cloned()
}

fn search_log(term: &str) {
    let path = exe_dir().join(LOG_FILE);
    match fs::read_to_string(&path) {
        Ok(text) => {
            let q = term.to_lowercase();
            for (i, line) in text.lines().enumerate() {
                if i == 0 || line.to_lowercase().contains(&q) { println!("{line}"); }
            }
        }
        Err(_) => println!("No local license log found at {}", path.display()),
    }
}

fn genkey(path: PathBuf) {
    use rand_core::OsRng;
    let sk = SigningKey::generate(&mut OsRng);
    if path.exists() { println!("[ERROR] Refusing to overwrite existing private key: {}", path.display()); return; }
    if let Some(parent) = path.parent() {
        if let Err(e) = fs::create_dir_all(parent) { println!("[ERROR] Cannot create key folder: {e}"); return; }
    }
    if let Err(e) = fs::write(&path, to_hex(&sk.to_bytes())) { println!("[ERROR] Cannot save key: {e}"); return; }
    println!("New private key saved to: {}", path.display());
    println!("Back it up offline. Existing licenses will not validate with this key.");
    println!("Public key bytes:");
    for chunk in sk.verifying_key().to_bytes().chunks(8) {
        println!("    {},", chunk.iter().map(|b| format!("0x{b:02x}")).collect::<Vec<_>>().join(", "));
    }
}

fn read_prompt(label: &str) -> String {
    print!("{label}");
    let _ = io::stdout().flush();
    let mut s = String::new();
    let _ = io::stdin().read_line(&mut s);
    s.trim().to_string()
}

fn interactive_request(legacy: bool) -> Request {
    let device_code = read_prompt("Device code: ");
    if legacy { return request_from_line(&device_code, true); }
    let customer_name = read_prompt("Customer name: ");
    let kind = read_prompt("License type [lifetime/expiring] (lifetime): ").to_lowercase();
    let license_type = if kind == "expiring" { kind } else { "lifetime".into() };
    let expires_at = if license_type == "expiring" { Some(read_prompt("Expiration date YYYY-MM-DD: ")) } else { None };
    let edition = read_prompt("Edition (Professional): ");
    let features = read_prompt("Features, comma separated (optional): ").split(',').map(str::trim)
        .filter(|s| !s.is_empty()).map(str::to_string).collect();
    let notes = read_prompt("Owner notes (optional): ");
    Request { device_code, customer_name, license_type, expires_at, edition, features, notes, legacy: false }
}

fn banner() {
    println!("========================================================");
    println!(" NewShop 2.0.0 License Manager - OWNER ONLY");
    println!(" Design and development: Mohamed Hussein - iegy.net");
    println!(" Offline Ed25519 licensing; private key stays separate");
    println!("========================================================\n");
}

fn usage() {
    println!("Usage:");
    println!("  NewShop-License-Manager.exe                         Interactive V2");
    println!("  NewShop-License-Manager.exe --device CODE --customer NAME [--type expiring --expires YYYY-MM-DD]");
    println!("  NewShop-License-Manager.exe --batch devices.txt     Lines: CODE=Customer");
    println!("  NewShop-License-Manager.exe --legacy CODE           Legacy V1 key");
    println!("  NewShop-License-Manager.exe --search TEXT           Search local issue log");
    println!("  NewShop-License-Manager.exe --genkey [--key PATH]    Explicit only; never automatic");
    println!("  Add --key PATH to load a separate private key (or set NEWSHOP_PRIVATE_KEY)");
}

fn run_cli() {
    let args: Vec<String> = std::env::args().skip(1).collect();
    banner();
    if args.iter().any(|a| a == "--help" || a == "-h") { usage(); return; }
    let selected_key = arg_value(&args, "--key").map(PathBuf::from).unwrap_or_else(key_path);
    if args.iter().any(|a| a == "--genkey") { genkey(selected_key); return; }
    if let Some(term) = arg_value(&args, "--search") { search_log(&term); return; }
    let sk = match load_signing_key(&selected_key) { Ok(k) => k, Err(e) => { println!("[ERROR] {e}"); return; } };
    println!("[OK] Separate private key loaded from {}\n", selected_key.display());

    if let Some(path) = arg_value(&args, "--batch") {
        match fs::File::open(&path) {
            Ok(file) => {
                let mut ok = 0; let mut bad = 0;
                for line in io::BufReader::new(file).lines().map_while(Result::ok) {
                    let line = line.trim();
                    if line.is_empty() || line.starts_with('#') { continue; }
                    if emit(&sk, request_from_line(line, false)) { ok += 1 } else { bad += 1 }
                }
                println!("Done: {ok} generated, {bad} failed");
            }
            Err(e) => println!("[ERROR] Cannot read batch file: {e}"),
        }
        return;
    }

    if let Some(i) = args.iter().position(|a| a == "--legacy") {
        let code = args.get(i + 1).cloned().unwrap_or_default();
        if code.is_empty() { usage(); } else { emit(&sk, request_from_line(&code, true)); }
        return;
    }

    if let Some(device_code) = arg_value(&args, "--device") {
        let customer_name = arg_value(&args, "--customer").unwrap_or_default();
        let license_type = arg_value(&args, "--type").unwrap_or_else(|| "lifetime".into()).to_lowercase();
        let expires_at = arg_value(&args, "--expires");
        let edition = arg_value(&args, "--edition").unwrap_or_else(|| "Professional".into());
        let features = arg_value(&args, "--features").unwrap_or_default().split(',').map(str::trim)
            .filter(|x| !x.is_empty()).map(str::to_string).collect();
        let notes = arg_value(&args, "--notes").unwrap_or_default();
        emit(&sk, Request { device_code, customer_name, license_type, expires_at, edition, features, notes, legacy: false });
        return;
    }
    emit(&sk, interactive_request(false));
}

fn main() {
    let has_args = std::env::args_os().len() > 1;
    #[cfg(windows)]
    {
        if !has_args {
            gui::run();
            return;
        }
        gui::attach_console();
    }
    run_cli();
}

#[cfg(test)]
mod tests {
    use super::*;

    fn request() -> Request {
        Request { device_code: "A7K2-9MPX-4LQ8-33RF".into(), customer_name: "Test Customer".into(),
            license_type: "lifetime".into(), expires_at: None, edition: "Professional".into(),
            features: vec!["sales".into()], notes: String::new(), legacy: false }
    }

    #[test]
    fn legacy_format_is_stable() {
        use rand_core::OsRng;
        let sk = SigningKey::generate(&mut OsRng);
        let key = make_legacy(&sk, "a7k2 9mpx 4lq8 33rf").unwrap();
        assert_eq!(key.matches('-').count(), 12);
        assert_eq!(key.replace('-', "").len(), 103);
    }

    #[test]
    fn v2_payload_is_signed_and_versioned() {
        use ed25519_dalek::{Signature, Verifier};
        use rand_core::OsRng;
        let sk = SigningKey::generate(&mut OsRng);
        let (payload, key) = make_v2(&sk, &request()).unwrap();
        assert_eq!(payload.format_version, 2);
        let parts: Vec<&str> = key.split('.').collect();
        assert_eq!(parts.len(), 3);
        assert_eq!(parts[0], "NS2");
        let sig_bytes = URL_SAFE_NO_PAD.decode(parts[2]).unwrap();
        let sig = Signature::from_slice(&sig_bytes).unwrap();
        sk.verifying_key().verify(format!("NS2.{}", parts[1]).as_bytes(), &sig).unwrap();
    }

    #[test]
    fn v2_rejects_missing_customer() {
        use rand_core::OsRng;
        let sk = SigningKey::generate(&mut OsRng);
        let mut req = request(); req.customer_name.clear();
        assert!(make_v2(&sk, &req).is_err());
    }

    #[test]
    fn printed_output_stays_ascii() {
        let src = include_str!("main.rs");
        for (i, line) in src.lines().enumerate() {
            let t = line.trim_start();
            if t.starts_with("//") || t.starts_with("///") || t.starts_with("//!") { continue; }
            if (t.starts_with("println!") || t.starts_with("print!") || t.contains("format!(")) && !line.is_ascii() {
                panic!("Non-ASCII console output on line {}", i + 1);
            }
        }
    }
}
