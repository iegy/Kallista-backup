//! Native Win32 interface for the owner license manager.
//! It deliberately uses Windows controls only, so it starts without WebView2.

use super::{clean_code, emit, exe_dir, key_path, load_signing_key, Request};
use std::mem::{size_of, zeroed};
use std::ptr::{null, null_mut};
use windows_sys::Win32::Foundation::{HINSTANCE, HWND, LPARAM, LRESULT, WPARAM};
use windows_sys::Win32::Graphics::Gdi::{
    CreateFontW, UpdateWindow, COLOR_WINDOW, DEFAULT_CHARSET, DEFAULT_PITCH, FF_DONTCARE,
    FW_NORMAL, HFONT,
};
use windows_sys::Win32::System::Console::{AttachConsole, ATTACH_PARENT_PROCESS};
use windows_sys::Win32::System::DataExchange::{
    CloseClipboard, EmptyClipboard, OpenClipboard, SetClipboardData,
};
use windows_sys::Win32::System::LibraryLoader::GetModuleHandleW;
use windows_sys::Win32::System::Memory::{
    GlobalAlloc, GlobalLock, GlobalUnlock, GMEM_MOVEABLE,
};
use windows_sys::Win32::UI::Shell::ShellExecuteW;
use windows_sys::Win32::UI::WindowsAndMessaging::*;

const ID_DEVICE: i32 = 101;
const ID_CUSTOMER: i32 = 102;
const ID_EXPIRING: i32 = 103;
const ID_EXPIRES: i32 = 104;
const ID_EDITION: i32 = 105;
const ID_FEATURES: i32 = 106;
const ID_NOTES: i32 = 107;
const ID_RESULT: i32 = 108;
const ID_STATUS: i32 = 109;
const ID_GENERATE: i32 = 201;
const ID_LEGACY: i32 = 202;
const ID_COPY: i32 = 203;
const ID_FOLDER: i32 = 204;
const CLIPBOARD_UNICODE_TEXT: u32 = 13;
const BUTTON_CHECKED: isize = 1;

fn wide(value: &str) -> Vec<u16> {
    value.encode_utf16().chain(std::iter::once(0)).collect()
}

unsafe fn control(parent: HWND, class: &str, text: &str, style: i32, ex_style: u32,
                  x: i32, y: i32, width: i32, height: i32, id: i32, font: HFONT) -> HWND {
    let class_w = wide(class);
    let text_w = wide(text);
    let hwnd = CreateWindowExW(
        ex_style,
        class_w.as_ptr(),
        text_w.as_ptr(),
        WS_CHILD | WS_VISIBLE | style as u32,
        x, y, width, height,
        parent,
        id as usize as _,
        GetModuleHandleW(null()),
        null_mut(),
    );
    if !hwnd.is_null() && !font.is_null() {
        SendMessageW(hwnd, WM_SETFONT, font as WPARAM, 1);
    }
    hwnd
}

unsafe fn text(parent: HWND, id: i32) -> String {
    let hwnd = GetDlgItem(parent, id);
    let len = GetWindowTextLengthW(hwnd);
    let mut buffer = vec![0u16; len as usize + 1];
    GetWindowTextW(hwnd, buffer.as_mut_ptr(), buffer.len() as i32);
    String::from_utf16_lossy(&buffer[..len as usize])
}

unsafe fn set_text(parent: HWND, id: i32, value: &str) {
    let value_w = wide(value);
    SetWindowTextW(GetDlgItem(parent, id), value_w.as_ptr());
}

unsafe fn message(parent: HWND, title: &str, body: &str, flags: u32) {
    let title_w = wide(title);
    let body_w = wide(body);
    MessageBoxW(parent, body_w.as_ptr(), title_w.as_ptr(), flags);
}

unsafe fn copy_text(parent: HWND, value: &str) -> Result<(), String> {
    if value.trim().is_empty() {
        return Err("Generate a license first.".into());
    }
    let data = wide(value);
    if OpenClipboard(parent) == 0 {
        return Err("Could not open the Windows clipboard.".into());
    }
    EmptyClipboard();
    let bytes = data.len() * size_of::<u16>();
    let handle = GlobalAlloc(GMEM_MOVEABLE, bytes);
    if handle.is_null() {
        CloseClipboard();
        return Err("Could not allocate clipboard memory.".into());
    }
    let target = GlobalLock(handle) as *mut u16;
    if target.is_null() {
        CloseClipboard();
        return Err("Could not lock clipboard memory.".into());
    }
    std::ptr::copy_nonoverlapping(data.as_ptr(), target, data.len());
    GlobalUnlock(handle);
    if SetClipboardData(CLIPBOARD_UNICODE_TEXT, handle).is_null() {
        CloseClipboard();
        return Err("Could not write the license to the clipboard.".into());
    }
    CloseClipboard();
    Ok(())
}

unsafe fn generate(parent: HWND, legacy: bool) {
    let selected_key = key_path();
    let sk = match load_signing_key(&selected_key) {
        Ok(key) => key,
        Err(error) => {
            set_text(parent, ID_STATUS, "Private key missing or invalid.");
            message(parent, "NewShop License Manager", &error, MB_OK | MB_ICONERROR);
            return;
        }
    };

    let device_code = text(parent, ID_DEVICE);
    if legacy {
        if clean_code(&device_code).len() != 16 {
            message(parent, "Invalid device code", "Device code must contain exactly 16 letters or digits.", MB_OK | MB_ICONWARNING);
            return;
        }
        let req = Request {
            device_code,
            customer_name: String::new(),
            license_type: "lifetime".into(),
            expires_at: None,
            edition: "Professional".into(),
            features: vec![],
            notes: text(parent, ID_NOTES),
            legacy: true,
        };
        // Reuse the validated core generator, then read the newly exported file.
        if emit(&sk, req) {
            let code = clean_code(&text(parent, ID_DEVICE));
            let path = exe_dir().join(format!("{code}.lic"));
            if let Ok(value) = std::fs::read_to_string(&path) {
                set_text(parent, ID_RESULT, &value);
                set_text(parent, ID_STATUS, &format!("Legacy license saved: {}", path.display()));
            }
        }
        return;
    }

    let expiring = SendMessageW(GetDlgItem(parent, ID_EXPIRING), BM_GETCHECK, 0, 0) == BUTTON_CHECKED;
    let expires = text(parent, ID_EXPIRES);
    let req = Request {
        device_code,
        customer_name: text(parent, ID_CUSTOMER),
        license_type: if expiring { "expiring".into() } else { "lifetime".into() },
        expires_at: if expiring { Some(expires) } else { None },
        edition: text(parent, ID_EDITION),
        features: text(parent, ID_FEATURES).split(',').map(str::trim)
            .filter(|item| !item.is_empty()).map(str::to_string).collect(),
        notes: text(parent, ID_NOTES),
        legacy: false,
    };

    match super::make_v2(&sk, &req) {
        Ok((payload, license)) => {
            match super::export_license(&payload.license_id, &license) {
                Ok(path) => {
                    let _ = super::log_license(&payload, &req.notes, &license);
                    set_text(parent, ID_RESULT, &license);
                    set_text(parent, ID_STATUS, &format!("License created and saved: {}", path.display()));
                }
                Err(error) => message(parent, "Save failed", &error.to_string(), MB_OK | MB_ICONERROR),
            }
        }
        Err(error) => message(parent, "Cannot create license", &error, MB_OK | MB_ICONWARNING),
    }
}

unsafe extern "system" fn window_proc(hwnd: HWND, msg: u32, wparam: WPARAM, lparam: LPARAM) -> LRESULT {
    match msg {
        WM_CREATE => {
            let font = CreateFontW(-18, 0, 0, 0, FW_NORMAL as i32, 0, 0, 0, DEFAULT_CHARSET as u32,
                0, 0, 0, (DEFAULT_PITCH | FF_DONTCARE) as u32, wide("Segoe UI").as_ptr());
            let bold = CreateFontW(-24, 0, 0, 0, 600, 0, 0, 0, DEFAULT_CHARSET as u32,
                0, 0, 0, (DEFAULT_PITCH | FF_DONTCARE) as u32, wide("Segoe UI").as_ptr());

            control(hwnd, "STATIC", "NewShop 2.0 License Manager", 0, 0, 24, 18, 720, 34, 0, bold);
            control(hwnd, "STATIC", "OWNER ONLY - Offline Ed25519 license issuer", 0, 0, 24, 52, 720, 24, 0, font);

            control(hwnd, "STATIC", "Device code | كود الجهاز", 0, 0, 24, 94, 220, 24, 0, font);
            control(hwnd, "EDIT", "", ES_AUTOHSCROLL, WS_EX_CLIENTEDGE, 250, 90, 494, 30, ID_DEVICE, font);
            control(hwnd, "STATIC", "Customer name | اسم العميل", 0, 0, 24, 134, 220, 24, 0, font);
            control(hwnd, "EDIT", "", ES_AUTOHSCROLL, WS_EX_CLIENTEDGE, 250, 130, 494, 30, ID_CUSTOMER, font);
            control(hwnd, "BUTTON", "Expiring license | ترخيص مؤقت", BS_AUTOCHECKBOX, 0, 24, 174, 250, 28, ID_EXPIRING, font);
            control(hwnd, "STATIC", "Expiry YYYY-MM-DD", 0, 0, 290, 177, 160, 24, 0, font);
            control(hwnd, "EDIT", "", ES_AUTOHSCROLL, WS_EX_CLIENTEDGE, 455, 172, 289, 30, ID_EXPIRES, font);
            control(hwnd, "STATIC", "Edition | الإصدار", 0, 0, 24, 216, 220, 24, 0, font);
            control(hwnd, "EDIT", "Professional", ES_AUTOHSCROLL, WS_EX_CLIENTEDGE, 250, 212, 494, 30, ID_EDITION, font);
            control(hwnd, "STATIC", "Features (comma separated)", 0, 0, 24, 256, 220, 24, 0, font);
            control(hwnd, "EDIT", "", ES_AUTOHSCROLL, WS_EX_CLIENTEDGE, 250, 252, 494, 30, ID_FEATURES, font);
            control(hwnd, "STATIC", "Owner notes | ملاحظات", 0, 0, 24, 296, 220, 24, 0, font);
            control(hwnd, "EDIT", "", ES_AUTOHSCROLL, WS_EX_CLIENTEDGE, 250, 292, 494, 30, ID_NOTES, font);

            control(hwnd, "BUTTON", "Generate V2 license", BS_DEFPUSHBUTTON, 0, 24, 340, 220, 38, ID_GENERATE, font);
            control(hwnd, "BUTTON", "Generate legacy V1", BS_PUSHBUTTON, 0, 258, 340, 190, 38, ID_LEGACY, font);
            control(hwnd, "BUTTON", "Copy license", BS_PUSHBUTTON, 0, 462, 340, 132, 38, ID_COPY, font);
            control(hwnd, "BUTTON", "Open folder", BS_PUSHBUTTON, 0, 608, 340, 136, 38, ID_FOLDER, font);

            control(hwnd, "STATIC", "Generated license | مفتاح التفعيل", 0, 0, 24, 396, 720, 24, 0, font);
            control(hwnd, "EDIT", "", ES_MULTILINE | ES_AUTOVSCROLL | ES_READONLY | WS_VSCROLL as i32,
                WS_EX_CLIENTEDGE, 24, 424, 720, 116, ID_RESULT, font);
            let status = if key_path().exists() {
                "Ready - private key found beside the program."
            } else {
                "Private key not found. Put newshop-private.key beside this program."
            };
            control(hwnd, "STATIC", status, 0, 0, 24, 554, 720, 44, ID_STATUS, font);
            0
        }
        WM_COMMAND => {
            match (wparam & 0xffff) as i32 {
                ID_GENERATE => generate(hwnd, false),
                ID_LEGACY => generate(hwnd, true),
                ID_COPY => {
                    match copy_text(hwnd, &text(hwnd, ID_RESULT)) {
                        Ok(()) => set_text(hwnd, ID_STATUS, "License copied to clipboard."),
                        Err(error) => message(hwnd, "Copy failed", &error, MB_OK | MB_ICONWARNING),
                    }
                }
                ID_FOLDER => {
                    let operation = wide("open");
                    let folder = wide(&exe_dir().to_string_lossy());
                    ShellExecuteW(hwnd, operation.as_ptr(), folder.as_ptr(), null(), null(), SW_SHOWNORMAL);
                }
                _ => {}
            }
            0
        }
        WM_CLOSE => {
            DestroyWindow(hwnd);
            0
        }
        WM_DESTROY => {
            PostQuitMessage(0);
            0
        }
        _ => DefWindowProcW(hwnd, msg, wparam, lparam),
    }
}

pub fn attach_console() {
    unsafe { AttachConsole(ATTACH_PARENT_PROCESS); }
}

pub fn run() {
    unsafe {
        let instance: HINSTANCE = GetModuleHandleW(null());
        let class_name = wide("NewShopLicenseManagerWindow");
        let title = wide("NewShop 2.0 - License Manager");
        let mut class: WNDCLASSW = zeroed();
        class.lpfnWndProc = Some(window_proc);
        class.hInstance = instance;
        class.hCursor = LoadCursorW(null_mut(), IDC_ARROW);
        class.hbrBackground = (COLOR_WINDOW as usize + 1) as _;
        class.lpszClassName = class_name.as_ptr();
        if RegisterClassW(&class) == 0 {
            message(null_mut(), "NewShop License Manager", "Could not register the Windows interface.", MB_OK | MB_ICONERROR);
            return;
        }
        let hwnd = CreateWindowExW(
            WS_EX_CONTROLPARENT,
            class_name.as_ptr(),
            title.as_ptr(),
            WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX,
            CW_USEDEFAULT, CW_USEDEFAULT, 790, 650,
            null_mut(), null_mut(), instance, null_mut(),
        );
        if hwnd.is_null() {
            message(null_mut(), "NewShop License Manager", "Could not create the program window.", MB_OK | MB_ICONERROR);
            return;
        }
        ShowWindow(hwnd, SW_SHOW);
        UpdateWindow(hwnd);
        let mut msg: MSG = zeroed();
        while GetMessageW(&mut msg, null_mut(), 0, 0) > 0 {
            if IsDialogMessageW(hwnd, &mut msg) == 0 {
                TranslateMessage(&msg);
                DispatchMessageW(&msg);
            }
        }
    }
}
