@echo off
cd /d "%~dp0license-tool"
echo Rebuilding NewShop 2.0.0 License Manager only...
echo (the main NewShop app is NOT affected)
echo.
cargo build --release
if errorlevel 1 goto :fail
echo.
copy /Y "target\release\NewShop-License-Manager.exe" "..\FINAL_DELIVERY\" >nul 2>&1
echo Done. Updated file:
echo   FINAL_DELIVERY\NewShop-License-Manager.exe
echo.
pause
exit /b 0
:fail
echo.
echo Build failed - read the messages above.
pause
exit /b 1
