// license.rs — نظام الحماية: بصمة الجهاز + تفعيل أوفلاين مدى الحياة
//
// الفكرة:
//   ١) البرنامج بيحسب بصمة الجهاز = SHA256(MachineGuid + سيريال البارتيشن + معرّف المعالج)
//   ٢) بيعرضها ككود قصير مقروء (Base32) العميل يبعته لصاحب البرنامج
//   ٣) صاحب البرنامج بيوقّع البصمة بالمفتاح السري Ed25519 (في أداة منفصلة عنده هو بس)
//   ٤) البرنامج بيتحقق من التوقيع بالمفتاح العام المدفون تحت — من غير إنترنت خالص
//
// المفتاح السري مش موجود جوه البرنامج نهائيًا، فمحدش يقدر يولّد أكواد تفعيل.

use ed25519_dalek::{Signature, Verifier, VerifyingKey};
use base64::Engine;
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::fs;

/// المفتاح العام (آمن إنه يكون مكشوف — بيتحقق بس، مايوقّعش)
const PUBLIC_KEY: [u8; 32] = [
    0x26, 0x34, 0xfc, 0x1f, 0xd7, 0x05, 0xa6, 0xd7, 0x7c, 0x2c, 0xe9, 0xe3, 0x11, 0x90, 0x8b,
    0x9f, 0x96, 0xf4, 0x95, 0x9c, 0x21, 0xb1, 0x93, 0x26, 0x1d, 0xbe, 0xf3, 0xba, 0xf6, 0xb5,
    0xaf, 0x37,
];

const B32: &[u8] = b"ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
const TRIAL_DAYS: u64 = 15;
const TRIAL_FORMAT_VERSION: u8 = 1;
// ليست مفتاح ترخيص؛ تستخدم فقط لكشف العبث العرضي بملف الفترة التجريبية المحلي.
const TRIAL_INTEGRITY_TAG: &[u8] = b"NewShop-2|Trial-State|2026|MH";

/* ---------------- Base32 (RFC 4648 من غير حشو) ---------------- */

pub fn b32_encode(data: &[u8]) -> String {
    let mut out = String::new();
    let mut buf: u32 = 0;
    let mut bits = 0;
    for &b in data {
        buf = (buf << 8) | b as u32;
        bits += 8;
        while bits >= 5 {
            bits -= 5;
            out.push(B32[((buf >> bits) & 31) as usize] as char);
        }
    }
    if bits > 0 {
        out.push(B32[((buf << (5 - bits)) & 31) as usize] as char);
    }
    out
}

pub fn b32_decode(s: &str) -> Result<Vec<u8>, String> {
    let mut out = Vec::new();
    let mut buf: u32 = 0;
    let mut bits = 0;
    for c in s.chars() {
        if c == '-' || c == ' ' || c == '\n' || c == '\r' || c == '\t' {
            continue;
        }
        let u = c.to_ascii_uppercase();
        let v = B32
            .iter()
            .position(|&x| x as char == u)
            .ok_or_else(|| format!("حرف غير صالح في الكود: {c}"))? as u32;
        buf = (buf << 5) | v;
        bits += 5;
        if bits >= 8 {
            bits -= 8;
            out.push(((buf >> bits) & 0xff) as u8);
        }
    }
    Ok(out)
}

/* ---------------- بصمة الجهاز ---------------- */

#[cfg(windows)]
fn machine_parts() -> Vec<String> {
    use winreg::enums::*;
    use winreg::RegKey;

    let hklm = RegKey::predef(HKEY_LOCAL_MACHINE);
    let mut parts = Vec::new();

    // ١) MachineGuid — بيتولد مرة واحدة عند تثبيت ويندوز
    if let Ok(k) = hklm.open_subkey_with_flags(
        r"SOFTWARE\Microsoft\Cryptography",
        KEY_READ | KEY_WOW64_64KEY,
    ) {
        if let Ok(v) = k.get_value::<String, _>("MachineGuid") {
            parts.push(v);
        }
    }

    // ٢) معرّف المعالج
    if let Ok(k) = hklm.open_subkey(r"HARDWARE\DESCRIPTION\System\CentralProcessor\0") {
        if let Ok(v) = k.get_value::<String, _>("Identifier") {
            parts.push(v);
        }
        if let Ok(v) = k.get_value::<String, _>("ProcessorNameString") {
            parts.push(v);
        }
    }

    // ٣) سيريال بارتيشن الويندوز
    if let Some(serial) = volume_serial() {
        parts.push(format!("VOL{serial:08X}"));
    }

    parts
}

#[cfg(windows)]
fn volume_serial() -> Option<u32> {
    use windows_sys::Win32::Storage::FileSystem::GetVolumeInformationW;

    let root: Vec<u16> = "C:\\\0".encode_utf16().collect();
    let mut serial: u32 = 0;
    let ok = unsafe {
        GetVolumeInformationW(
            root.as_ptr(),
            std::ptr::null_mut(),
            0,
            &mut serial,
            std::ptr::null_mut(),
            std::ptr::null_mut(),
            std::ptr::null_mut(),
            0,
        )
    };
    if ok != 0 {
        Some(serial)
    } else {
        None
    }
}

/// بديل للتطوير على غير ويندوز — البرنامج النهائي بيشتغل على ويندوز بس
#[cfg(not(windows))]
fn machine_parts() -> Vec<String> {
    let mut parts = Vec::new();
    for p in ["/etc/machine-id", "/var/lib/dbus/machine-id"] {
        if let Ok(v) = fs::read_to_string(p) {
            parts.push(v.trim().to_string());
        }
    }
    if let Ok(v) = std::env::var("HOSTNAME") {
        parts.push(v);
    }
    if parts.is_empty() {
        parts.push("dev-machine".into());
    }
    parts
}

/// بصمة الجهاز الخام (٣٢ بايت) — دي اللي بتتوقّع
pub fn fingerprint_bytes() -> [u8; 32] {
    let joined = machine_parts().join("|");
    let mut h = Sha256::new();
    h.update(b"NewShop-v1|");
    h.update(joined.as_bytes());
    h.finalize().into()
}

/// كود الجهاز المقروء: A7K2-9MPX-4LQ8-33RF
pub fn fingerprint_code() -> String {
    let fp = fingerprint_bytes();
    let s = b32_encode(&fp[..10]); // ١٦ حرف
    s.as_bytes()
        .chunks(4)
        .map(|c| std::str::from_utf8(c).unwrap_or(""))
        .collect::<Vec<_>>()
        .join("-")
}

/* ---------------- التحقق والتفعيل ---------------- */

fn license_path() -> std::path::PathBuf {
    crate::app_dir().join("license.dat")
}

fn trial_path() -> std::path::PathBuf {
    crate::app_dir().join("trial.dat")
}

/// نسخ مستقلة عن مجلد التثبيت. إلغاء تثبيت البرنامج لا يحذفها، وأي نسخة
/// سليمة تعيد تكوين النسخ المفقودة في التشغيل التالي.
fn trial_copy_paths() -> Vec<std::path::PathBuf> {
    let mut paths = vec![trial_path()];
    #[cfg(windows)]
    {
        if let Ok(local) = std::env::var("LOCALAPPDATA") {
            paths.push(
                std::path::PathBuf::from(local)
                    .join("Microsoft")
                    .join("NewShop")
                    .join("trial.dat"),
            );
        }
        if let Ok(program_data) = std::env::var("PROGRAMDATA") {
            paths.push(
                std::path::PathBuf::from(program_data)
                    .join("NewShop")
                    .join("trial.dat"),
            );
        }
    }
    paths.sort();
    paths.dedup();
    paths
}

/// الرسالة اللي بتتوقّع = كود الجهاز نفسه من غير شرطات (بحروف كبيرة).
/// مهم: صاحب البرنامج بيستلم الكود ده بس من العميل، فلازم يكون هو نفسه
/// اللي بيتوقّع عشان الأداة تقدر تولّد التفعيل من غير أي بيانات تانية.
pub fn signed_message() -> Vec<u8> {
    fingerprint_code().replace('-', "").into_bytes()
}

/// التحقق من كود التفعيل مقابل بصمة الجهاز الحالي
pub fn verify_key(key: &str) -> Result<(), String> {
    let sig_bytes = b32_decode(key)?;
    if sig_bytes.len() != 64 {
        return Err("كود التفعيل ناقص أو فيه حروف زيادة".into());
    }
    let vk = VerifyingKey::from_bytes(&PUBLIC_KEY).map_err(|e| e.to_string())?;
    let mut arr = [0u8; 64];
    arr.copy_from_slice(&sig_bytes);
    let sig = Signature::from_bytes(&arr);
    vk.verify(&signed_message(), &sig)
        .map_err(|_| "كود التفعيل مش صحيح للجهاز ده".to_string())
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LicensePayload {
    pub format_version: u8,
    pub license_id: String,
    pub customer_name: String,
    pub device_code: String,
    pub issued_at: String,
    pub license_type: String,
    pub expires_at: Option<String>,
    pub edition: String,
    #[serde(default)]
    pub features: Vec<String>,
}

fn verify_v2(raw: &str) -> Result<LicensePayload, String> {
    let parts: Vec<&str> = raw.trim().split('.').collect();
    if parts.len() != 3 || parts[0] != "NS2" {
        return Err("صيغة ترخيص NewShop 2 غير صحيحة".into());
    }
    let payload_bytes = base64::engine::general_purpose::URL_SAFE_NO_PAD
        .decode(parts[1])
        .map_err(|_| "بيانات الترخيص غير صالحة".to_string())?;
    let sig_bytes = base64::engine::general_purpose::URL_SAFE_NO_PAD
        .decode(parts[2])
        .map_err(|_| "توقيع الترخيص غير صالح".to_string())?;
    if sig_bytes.len() != 64 {
        return Err("طول توقيع الترخيص غير صالح".into());
    }
    let vk = VerifyingKey::from_bytes(&PUBLIC_KEY).map_err(|e| e.to_string())?;
    let mut arr = [0u8; 64];
    arr.copy_from_slice(&sig_bytes);
    let sig = Signature::from_bytes(&arr);
    let signed = format!("NS2.{}", parts[1]);
    vk.verify(signed.as_bytes(), &sig)
        .map_err(|_| "تم تعديل بيانات الترخيص أو أن التوقيع غير صحيح".to_string())?;

    let payload: LicensePayload =
        serde_json::from_slice(&payload_bytes).map_err(|_| "تعذّر قراءة بيانات الترخيص".to_string())?;
    if payload.format_version != 2 {
        return Err("إصدار صيغة الترخيص غير مدعوم".into());
    }
    if clean_device(&payload.device_code) != clean_device(&fingerprint_code()) {
        return Err("هذا الترخيص صادر لجهاز آخر".into());
    }
    if payload.license_type == "expiring" {
        let expires = payload
            .expires_at
            .as_deref()
            .ok_or_else(|| "الترخيص المؤقت لا يحتوي تاريخ انتهاء".to_string())?;
        if expires < today_utc().as_str() {
            return Err(format!("انتهت صلاحية الترخيص بتاريخ {expires}"));
        }
    }
    Ok(payload)
}

fn clean_device(s: &str) -> String {
    s.chars()
        .filter(|c| c.is_ascii_alphanumeric())
        .collect::<String>()
        .to_uppercase()
}

fn today_utc() -> String {
    use std::time::{SystemTime, UNIX_EPOCH};
    let secs = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_secs())
        .unwrap_or(0);
    let (y, m, d) = civil_from_days((secs / 86400) as i64);
    format!("{y:04}-{m:02}-{d:02}")
}

#[cfg(windows)]
fn save_registry_copy(key: &str) {
    use winreg::enums::*;
    use winreg::RegKey;
    let hkcu = RegKey::predef(HKEY_CURRENT_USER);
    if let Ok((k, _)) = hkcu.create_subkey(r"Software\NewShop") {
        let _ = k.set_value("License", &key.to_string());
        let _ = k.set_value("Device", &fingerprint_code());
    }
}

#[cfg(windows)]
fn read_registry_copy() -> Option<String> {
    use winreg::enums::*;
    use winreg::RegKey;
    RegKey::predef(HKEY_CURRENT_USER)
        .open_subkey(r"Software\NewShop")
        .ok()?
        .get_value::<String, _>("License")
        .ok()
}

#[cfg(windows)]
fn save_registry_trial(raw: &str) {
    use winreg::enums::*;
    use winreg::RegKey;
    let hkcu = RegKey::predef(HKEY_CURRENT_USER);
    if let Ok((k, _)) = hkcu.create_subkey(r"Software\NewShop") {
        let _ = k.set_value("Trial", &raw.to_string());
        let _ = k.set_value("TrialDevice", &fingerprint_code());
    }
}

#[cfg(windows)]
fn read_registry_trial() -> Option<String> {
    use winreg::enums::*;
    use winreg::RegKey;
    RegKey::predef(HKEY_CURRENT_USER)
        .open_subkey(r"Software\NewShop")
        .ok()?
        .get_value::<String, _>("Trial")
        .ok()
}

#[cfg(not(windows))]
fn save_registry_copy(_key: &str) {}
#[cfg(not(windows))]
fn read_registry_copy() -> Option<String> {
    None
}
#[cfg(not(windows))]
fn save_registry_trial(_raw: &str) {}
#[cfg(not(windows))]
fn read_registry_trial() -> Option<String> {
    None
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct TrialRecord {
    format_version: u8,
    device_code: String,
    started_day: u64,
    last_seen_day: u64,
    checksum: String,
}

#[derive(Debug, Clone)]
struct TrialInfo {
    active: bool,
    days_remaining: u32,
    started_at: String,
    expires_at: String,
    message: String,
}

fn trial_checksum(device_code: &str, started_day: u64, last_seen_day: u64) -> String {
    let mut h = Sha256::new();
    h.update(TRIAL_INTEGRITY_TAG);
    h.update(b"|");
    h.update(clean_device(device_code).as_bytes());
    h.update(b"|");
    h.update(started_day.to_string().as_bytes());
    h.update(b"|");
    h.update(last_seen_day.to_string().as_bytes());
    format!("{:x}", h.finalize())
}

fn make_trial_record(started_day: u64, last_seen_day: u64) -> TrialRecord {
    let device_code = fingerprint_code();
    TrialRecord {
        format_version: TRIAL_FORMAT_VERSION,
        checksum: trial_checksum(&device_code, started_day, last_seen_day),
        device_code,
        started_day,
        last_seen_day,
    }
}

fn parse_trial_record(raw: &str) -> Option<TrialRecord> {
    let record: TrialRecord = serde_json::from_str(raw).ok()?;
    if record.format_version != TRIAL_FORMAT_VERSION
        || clean_device(&record.device_code) != clean_device(&fingerprint_code())
        || record.checksum
            != trial_checksum(
                &record.device_code,
                record.started_day,
                record.last_seen_day,
            )
    {
        return None;
    }
    Some(record)
}

fn write_trial_record(record: &TrialRecord) {
    if let Ok(raw) = serde_json::to_string(record) {
        for path in trial_copy_paths() {
            if let Some(parent) = path.parent() {
                let _ = fs::create_dir_all(parent);
            }
            let _ = fs::write(path, &raw);
        }
        save_registry_trial(&raw);
    }
}

fn current_utc_day() -> u64 {
    use std::time::{SystemTime, UNIX_EPOCH};
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_secs() / 86_400)
        .unwrap_or(0)
}

fn day_as_date(day: u64) -> String {
    let (y, m, d) = civil_from_days(day as i64);
    format!("{y:04}-{m:02}-{d:02}")
}

fn evaluate_trial(started_day: u64, last_seen_day: u64, today: u64) -> (bool, u32, bool) {
    if today < started_day || today < last_seen_day {
        return (false, 0, true);
    }
    let elapsed = today.saturating_sub(started_day);
    let remaining = TRIAL_DAYS.saturating_sub(elapsed) as u32;
    (remaining > 0, remaining, false)
}

fn load_or_create_trial() -> TrialInfo {
    let today = current_utc_day();
    let mut raw_copies: Vec<String> = trial_copy_paths()
        .into_iter()
        .filter_map(|path| fs::read_to_string(path).ok())
        .collect();
    if let Some(registry) = read_registry_trial() {
        raw_copies.push(registry);
    }
    let had_invalid_copy = raw_copies
        .iter()
        .any(|raw| parse_trial_record(raw).is_none());

    let valid: Vec<TrialRecord> = raw_copies
        .iter()
        .map(String::as_str)
        .filter_map(parse_trial_record)
        .collect();

    let mut record = if valid.is_empty() {
        if had_invalid_copy {
            make_trial_record(today.saturating_sub(TRIAL_DAYS), today)
        } else {
            make_trial_record(today, today)
        }
    } else {
        let started_day = valid.iter().map(|r| r.started_day).min().unwrap_or(today);
        let last_seen_day = valid.iter().map(|r| r.last_seen_day).max().unwrap_or(today);
        make_trial_record(started_day, last_seen_day)
    };

    let (active, days_remaining, clock_rollback) =
        evaluate_trial(record.started_day, record.last_seen_day, today);
    if today > record.last_seen_day {
        record = make_trial_record(record.started_day, today);
    }
    write_trial_record(&record);

    let message = if had_invalid_copy && valid.is_empty() {
        "تم إيقاف النسخة التجريبية بسبب تلف أو تعديل بيانات الفترة التجريبية".into()
    } else if clock_rollback {
        "تم إيقاف النسخة التجريبية بسبب تغيير تاريخ الجهاز للخلف".into()
    } else if active {
        format!("نسخة تجريبية — متبقي {days_remaining} يوم")
    } else {
        "انتهت الفترة التجريبية بعد 15 يومًا — فعّل البرنامج للمتابعة".into()
    };

    TrialInfo {
        active,
        days_remaining,
        started_at: day_as_date(record.started_day),
        expires_at: day_as_date(record.started_day.saturating_add(TRIAL_DAYS)),
        message,
    }
}

#[derive(Serialize)]
pub struct LicenseStatus {
    pub activated: bool,
    pub trial: bool,
    pub trial_days_remaining: Option<u32>,
    pub trial_started_at: Option<String>,
    pub trial_expires_at: Option<String>,
    pub device_code: String,
    pub key: Option<String>,
    pub since: Option<String>,
    pub format_version: u8,
    pub license_id: Option<String>,
    pub customer_name: Option<String>,
    pub license_type: Option<String>,
    pub expires_at: Option<String>,
    pub edition: Option<String>,
    pub features: Vec<String>,
    pub legacy: bool,
    pub message: Option<String>,
}

fn status_from_license(raw: &str, since: Option<String>) -> Result<LicenseStatus, String> {
    if raw.trim().starts_with("NS2.") {
        let payload = verify_v2(raw)?;
        Ok(LicenseStatus {
            activated: true,
            trial: false,
            trial_days_remaining: None,
            trial_started_at: None,
            trial_expires_at: None,
            device_code: fingerprint_code(),
            key: Some(raw.trim().to_string()),
            since,
            format_version: 2,
            license_id: Some(payload.license_id),
            customer_name: Some(payload.customer_name),
            license_type: Some(payload.license_type),
            expires_at: payload.expires_at,
            edition: Some(payload.edition),
            features: payload.features,
            legacy: false,
            message: None,
        })
    } else {
        let clean = clean_device(raw);
        verify_key(&clean)?;
        Ok(LicenseStatus {
            activated: true,
            trial: false,
            trial_days_remaining: None,
            trial_started_at: None,
            trial_expires_at: None,
            device_code: fingerprint_code(),
            key: Some(clean),
            since,
            format_version: 1,
            license_id: None,
            customer_name: None,
            license_type: Some("lifetime".into()),
            expires_at: None,
            edition: Some("Legacy".into()),
            features: vec![],
            legacy: true,
            message: Some("Legacy Lifetime License".into()),
        })
    }
}

/// فحص مركزي للخصائص المدفوعة. النسخة التجريبية تسمح بتجربة التشغيل،
/// لكنها لا تُعتبر تفعيلًا رسميًا ولا تفتح تصدير البيانات خارج البرنامج.
pub fn require_official_license() -> Result<(), String> {
    let stored = fs::read_to_string(license_path())
        .ok()
        .or_else(read_registry_copy);

    if let Some(raw) = stored {
        let mut lines = raw.lines();
        let key = lines.next().unwrap_or("").trim();
        let since = lines.next().map(|s| s.trim().to_string());
        if !key.is_empty() && status_from_license(key, since).is_ok() {
            return Ok(());
        }
    }

    Err("تصدير البيانات والنسخ الاحتياطي الخارجي متاحان بعد التفعيل الرسمي فقط".into())
}

/* ---------------- أوامر Tauri ---------------- */

#[tauri::command]
pub fn license_status() -> LicenseStatus {
    let device_code = fingerprint_code();
    // بننشئ/نحدّث سجل الديمو حتى لو الجهاز مفعّل؛ وبكده انتهاء ترخيص مؤقت
    // ما يفتحش فترة ديمو جديدة بعد شهور من أول استخدام.
    let trial = load_or_create_trial();

    // الملف الأساسي، ولو اتمسح بنجرب نسخة الريجستري
    let stored = fs::read_to_string(license_path())
        .ok()
        .or_else(read_registry_copy);

    if let Some(raw) = stored {
        let mut lines = raw.lines();
        let key = lines.next().unwrap_or("").trim().to_string();
        let since = lines.next().map(|s| s.trim().to_string());
        if let Ok(status) = status_from_license(&key, since.clone()) {
            // لو الملف كان ناقص نرجّعه من الريجستري
            let _ = fs::write(
                license_path(),
                format!("{}\n{}\n", key, since.clone().unwrap_or_default()),
            );
            return status;
        }
    }

    LicenseStatus {
        activated: trial.active,
        trial: true,
        trial_days_remaining: Some(trial.days_remaining),
        trial_started_at: Some(trial.started_at.clone()),
        trial_expires_at: Some(trial.expires_at.clone()),
        device_code,
        key: None,
        since: None,
        format_version: 0,
        license_id: None,
        customer_name: None,
        license_type: Some("trial".into()),
        expires_at: Some(trial.expires_at),
        edition: Some("Demo".into()),
        features: vec![],
        legacy: false,
        message: Some(trial.message),
    }
}

#[tauri::command]
pub fn activate(key: String) -> Result<LicenseStatus, String> {
    let clean = if key.trim().starts_with("NS2.") {
        key.trim().to_string()
    } else {
        clean_device(&key)
    };
    let _ = status_from_license(&clean, None)?;

    let now = chrono_like_now();
    fs::write(license_path(), format!("{clean}\n{now}\n"))
        .map_err(|e| format!("تعذّر حفظ ملف الترخيص: {e}"))?;
    save_registry_copy(&clean);

    status_from_license(&clean, Some(now))
}

/// تاريخ بسيط من غير مكتبة وقت إضافية
fn chrono_like_now() -> String {
    use std::time::{SystemTime, UNIX_EPOCH};
    let secs = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_secs())
        .unwrap_or(0);
    // تحويل مبسط لتاريخ ميلادي (UTC)
    let days = secs / 86400;
    let (y, m, d) = civil_from_days(days as i64);
    let rem = secs % 86400;
    format!(
        "{y:04}-{m:02}-{d:02} {:02}:{:02}",
        rem / 3600,
        (rem % 3600) / 60
    )
}

/// نسخة عامة يستخدمها ملف النسخ الاحتياطي
pub fn civil_from_days_pub(z: i64) -> (i64, u32, u32) {
    civil_from_days(z)
}

/// خوارزمية Howard Hinnant لتحويل عدد الأيام إلى تاريخ
fn civil_from_days(z: i64) -> (i64, u32, u32) {
    let z = z + 719468;
    let era = if z >= 0 { z } else { z - 146096 } / 146097;
    let doe = (z - era * 146097) as u64;
    let yoe = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365;
    let y = yoe as i64 + era * 400;
    let doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
    let mp = (5 * doy + 2) / 153;
    let d = (doy - (153 * mp + 2) / 5 + 1) as u32;
    let m = if mp < 10 { mp + 3 } else { mp - 9 } as u32;
    (if m <= 2 { y + 1 } else { y }, m, d)
}

#[tauri::command]
pub fn machine_code() -> String {
    fingerprint_code()
}

#[cfg(test)]
mod tests {
    use super::*;

    /// مفيد وقت الدعم الفني: بيطبع كود الجهاز الحالي
    #[test]
    fn show_device_code() {
        println!("DEVICE_CODE={}", fingerprint_code());
    }

    #[test]
    fn base32_roundtrip() {
        for len in [1usize, 5, 10, 32, 64] {
            let data: Vec<u8> = (0..len).map(|i| (i * 37 % 251) as u8).collect();
            let enc = b32_encode(&data);
            let dec = b32_decode(&enc).unwrap();
            assert_eq!(&dec[..len], &data[..], "فشل التحويل عند طول {len}");
        }
    }

    #[test]
    fn device_code_is_stable_and_formatted() {
        let a = fingerprint_code();
        let b = fingerprint_code();
        assert_eq!(a, b, "بصمة الجهاز لازم تكون ثابتة");
        assert_eq!(a.len(), 19, "الكود لازم يكون ١٦ حرف + ٣ شرطات");
        assert_eq!(a.matches('-').count(), 3);
    }

    #[test]
    fn signed_message_matches_device_code() {
        let m = String::from_utf8(signed_message()).unwrap();
        assert_eq!(m, fingerprint_code().replace('-', ""));
        assert_eq!(m.len(), 16);
    }

    /// اختبار شامل: بيتفعّل بمفتاح حقيقي متولّد من أداة التراخيص.
    /// شغّله كده:  NEWSHOP_TEST_KEY=<الكود> cargo test
    #[test]
    fn accepts_real_key_when_provided() {
        if let Ok(k) = std::env::var("NEWSHOP_TEST_KEY") {
            assert!(verify_key(&k).is_ok(), "المفتاح الحقيقي المفروض يعدّي");
            // نفس المفتاح لازم يترفض لو البصمة اتغيرت
            let tampered = k.replacen('A', "B", 1);
            if tampered != k {
                assert!(verify_key(&tampered).is_err(), "مفتاح معدّل المفروض يترفض");
            }
        }
    }

    #[test]
    fn rejects_garbage_key() {
        assert!(verify_key("AAAA-BBBB-CCCC").is_err());
        assert!(verify_key(&"A".repeat(104)).is_err());
    }

    #[test]
    fn trial_counts_exactly_fifteen_days() {
        assert_eq!(evaluate_trial(10_000, 10_000, 10_000), (true, 15, false));
        assert_eq!(evaluate_trial(10_000, 10_013, 10_014), (true, 1, false));
        assert_eq!(evaluate_trial(10_000, 10_014, 10_015), (false, 0, false));
        assert_eq!(evaluate_trial(10_000, 10_020, 10_019), (false, 0, true));
    }

    #[test]
    fn trial_checksum_detects_changes() {
        let mut record = make_trial_record(20_000, 20_003);
        assert_eq!(
            record.checksum,
            trial_checksum(&record.device_code, record.started_day, record.last_seen_day)
        );
        record.started_day -= 1;
        assert_ne!(
            record.checksum,
            trial_checksum(&record.device_code, record.started_day, record.last_seen_day)
        );
    }
}
