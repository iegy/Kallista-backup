// db.rs — طبقة عامة للتعامل مع SQLite
// الفكرة: بدل ما نكتب أمر Tauri لكل عملية، نوفّر ٣ أوامر عامة والمنطق كله في TypeScript.

use rusqlite::types::{Value as SqlValue, ValueRef};
use rusqlite::Connection;
use serde::{Deserialize, Serialize};
use serde_json::{Map, Value as Json};
use std::sync::Mutex;
use tauri::State;
use crate::security::Sessions;

pub struct Db(pub Mutex<Connection>);

#[derive(Debug, Deserialize)]
pub struct Op {
    pub sql: String,
    #[serde(default)]
    pub params: Vec<Json>,
}

#[derive(Debug, Serialize)]
pub struct ExecResult {
    pub rows_affected: usize,
    pub last_insert_id: i64,
}

/// تحويل قيمة JSON قادمة من الواجهة إلى قيمة SQLite
fn json_to_sql(v: &Json) -> Result<SqlValue, String> {
    Ok(match v {
        Json::Null => SqlValue::Null,
        Json::Bool(b) => SqlValue::Integer(if *b { 1 } else { 0 }),
        Json::Number(n) => {
            if let Some(i) = n.as_i64() {
                SqlValue::Integer(i)
            } else if let Some(f) = n.as_f64() {
                SqlValue::Real(f)
            } else {
                return Err("رقم غير صالح في المعاملات".into());
            }
        }
        Json::String(s) => SqlValue::Text(s.clone()),
        // المصفوفات والكائنات تتخزّن كنص JSON (مفيد لحقل الصلاحيات مثلًا)
        other => SqlValue::Text(other.to_string()),
    })
}

/// تحويل قيمة SQLite إلى JSON للواجهة
fn sql_to_json(v: ValueRef<'_>) -> Json {
    match v {
        ValueRef::Null => Json::Null,
        ValueRef::Integer(i) => Json::from(i),
        ValueRef::Real(f) => Json::from(f),
        ValueRef::Text(t) => Json::String(String::from_utf8_lossy(t).into_owned()),
        ValueRef::Blob(b) => Json::String(format!("<blob:{}>", b.len())),
    }
}

/// استبدال العناصر الخاصة داخل المعاملات:
/// "$LAST_ID"    → رقم آخر صف تم إدراجه في العملية السابقة
/// "$LAST_ID:3"  → رقم الصف المُدرج في العملية رقم ٣ داخل نفس الدفعة
fn resolve_params(params: &[Json], ids: &[i64]) -> Result<Vec<SqlValue>, String> {
    let mut out = Vec::with_capacity(params.len());
    for p in params {
        if let Json::String(s) = p {
            if s == "$LAST_ID" {
                let id = *ids.last().ok_or("لا توجد عملية سابقة لاستخراج رقمها")?;
                out.push(SqlValue::Integer(id));
                continue;
            }
            if let Some(idx) = s.strip_prefix("$LAST_ID:") {
                let i: usize = idx.parse().map_err(|_| "رقم عملية غير صالح")?;
                let id = *ids.get(i).ok_or("رقم عملية خارج النطاق")?;
                out.push(SqlValue::Integer(id));
                continue;
            }
        }
        out.push(json_to_sql(p)?);
    }
    Ok(out)
}

#[tauri::command]
pub fn db_query(
    state: State<'_, Db>,
    sessions: State<'_, Sessions>,
    sql: String,
    params: Vec<Json>,
    session_token: Option<String>,
) -> Result<Vec<Map<String, Json>>, String> {
    let conn = state.0.lock().map_err(|e| e.to_string())?;
    let normalized = sql.trim_start().to_ascii_lowercase();
    if !normalized.starts_with("select") && !normalized.starts_with("pragma") {
        return Err("الاستعلام المطلوب ليس للقراءة".into());
    }
    // الإعدادات مطلوبة قبل شاشة الدخول. بقية البيانات تتطلب جلسة صحيحة.
    if !normalized.contains(" from settings") {
        let token = session_token.as_deref().unwrap_or("");
        let user = crate::security::session_user(&sessions, &conn, token)?;
        authorize_query(&user, &normalized)?;
        // الانضمام بجدول المستخدمين لإظهار اسم الكاشير في فاتورة/تقرير مسموح.
        // قراءة قائمة الحسابات نفسها (وتفاصيل الأدوار والصلاحيات) محمية.
        if normalized.contains(" from users") {
            if user.role != "owner"
                && user.role != "admin"
                && !user.permissions.iter().any(|p| p == "users")
            {
                return Err("ليس لديك صلاحية قراءة بيانات المستخدمين".into());
            }
        }
        // بعض عمليات البيع تحتاج cost_at_sale داخليًا حتى لو كان مخفيًا عن الكاشير.
        // إظهار حقول التكلفة والأرباح يظل محكومًا بصلاحيات الواجهة والتقارير.
    }
    let mut stmt = conn.prepare(&sql).map_err(|e| e.to_string())?;
    let cols: Vec<String> = stmt.column_names().iter().map(|s| s.to_string()).collect();
    let bound = resolve_params(&params, &[])?;

    let mut rows = stmt
        .query(rusqlite::params_from_iter(bound))
        .map_err(|e| e.to_string())?;

    let mut out = Vec::new();
    while let Some(row) = rows.next().map_err(|e| e.to_string())? {
        let mut obj = Map::new();
        for (i, name) in cols.iter().enumerate() {
            let v = row.get_ref(i).map_err(|e| e.to_string())?;
            obj.insert(name.clone(), sql_to_json(v));
        }
        out.push(obj);
    }
    Ok(out)
}

fn has_any(user: &crate::security::UserDto, permissions: &[&str]) -> bool {
    user.role == "owner"
        || user.role == "admin"
        || permissions.iter().any(|required| {
            user.permissions.iter().any(|p| p == required)
                || ((*required == "sales_view" || *required == "sales_create")
                    && user.permissions.iter().any(|p| p == "sales"))
        })
}

fn authorize_query(user: &crate::security::UserDto, sql: &str) -> Result<(), String> {
    if user.role == "owner" || user.role == "admin" {
        return Ok(());
    }
    let needed: &[&str] = if sql.contains("audit_log") {
        // سجل التدقيق يحتوي تفاصيل أمنية ومالية؛ للمالك والمدير فقط.
        return Err("سجل التدقيق متاح للمالك أو المدير فقط".into());
    } else if sql.contains(" from users") {
        &["users"]
    } else if sql.contains("purchases") || sql.contains("purchase_items") || sql.contains("suppliers") {
        &["purchases", "suppliers", "purchase_return", "reports"]
    } else if sql.contains("expenses") {
        &["expenses", "reports"]
    } else if sql.contains("stocktakes") || sql.contains("stocktake_items") {
        &["stocktake", "reports"]
    } else if sql.contains("shifts") || sql.contains("shift_cash") || sql.contains("cash_movements") {
        &["shifts", "shifts_open", "shifts_close", "reports"]
    } else if sql.contains("returns") || sql.contains("return_items") {
        &["sales_view", "sales_return", "purchase_return", "reports"]
    } else if sql.contains("sales") || sql.contains("sale_items") || sql.contains("sale_payments") {
        &["sales_view", "sales_create", "sales_return", "reports"]
    } else if sql.contains("customers") {
        &["customers", "sales_create", "reports"]
    } else if sql.contains("party_ledger") || sql.contains("payments") {
        &["customers", "suppliers", "customer_receipts", "supplier_payments", "reports"]
    } else if sql.contains("products") || sql.contains("categories") || sql.contains("stock_moves") {
        &["products", "sales_create", "purchases", "stocktake", "reports"]
    } else {
        &["sales_view"]
    };
    if has_any(user, needed) {
        Ok(())
    } else {
        Err("ليس لديك صلاحية لقراءة هذه البيانات".into())
    }
}

#[tauri::command]
pub fn db_execute(
    state: State<'_, Db>,
    sessions: State<'_, Sessions>,
    sql: String,
    params: Vec<Json>,
    session_token: Option<String>,
) -> Result<ExecResult, String> {
    let conn = state.0.lock().map_err(|e| e.to_string())?;
    authorize_mutation(&conn, &sessions, session_token.as_deref(), &sql)?;
    let bound = resolve_params(&params, &[])?;
    let n = conn
        .execute(&sql, rusqlite::params_from_iter(bound))
        .map_err(|e| e.to_string())?;
    Ok(ExecResult {
        rows_affected: n,
        last_insert_id: conn.last_insert_rowid(),
    })
}

/// تنفيذ عدة عمليات داخل معاملة واحدة — إما تنجح كلها أو ترجع كلها
#[tauri::command]
pub fn db_batch(
    state: State<'_, Db>,
    sessions: State<'_, Sessions>,
    ops: Vec<Op>,
    session_token: Option<String>,
    permission: Option<String>,
) -> Result<Vec<i64>, String> {
    let mut conn = state.0.lock().map_err(|e| e.to_string())?;
    if ops.iter().any(|op| {
        let q = op.sql.to_ascii_lowercase();
        q.contains(" users ") || q.contains(" users(") || q.contains("into users")
    }) {
        return Err("تعديل المستخدمين يجب أن يتم من شاشة المستخدمين المحمية".into());
    }
    if let Some(required) = permission.as_deref() {
        crate::security::require_permission(
            &sessions,
            &conn,
            session_token.as_deref().unwrap_or(""),
            required,
        )?;
    } else {
        for op in &ops {
            authorize_mutation(&conn, &sessions, session_token.as_deref(), &op.sql)?;
        }
    }
    let tx = conn.transaction().map_err(|e| e.to_string())?;
    let mut ids: Vec<i64> = Vec::with_capacity(ops.len());

    for (i, op) in ops.iter().enumerate() {
        let bound = resolve_params(&op.params, &ids)
            .map_err(|e| format!("العملية رقم {}: {}", i + 1, e))?;
        tx.execute(&op.sql, rusqlite::params_from_iter(bound))
            .map_err(|e| format!("العملية رقم {}: {}", i + 1, e))?;
        ids.push(tx.last_insert_rowid());
    }

    tx.commit().map_err(|e| e.to_string())?;
    Ok(ids)
}

fn authorize_mutation(
    conn: &Connection,
    sessions: &Sessions,
    token: Option<&str>,
    sql: &str,
) -> Result<(), String> {
    let q = sql.trim_start().to_ascii_lowercase();
    if q.starts_with("select") || q.starts_with("pragma") {
        return Err("استخدم أمر القراءة للاستعلامات".into());
    }
    // تعديل المستخدمين له أوامر محمية تمنع تصعيد الصلاحيات.
    if q.contains(" users ") || q.contains(" users(") || q.contains("into users") {
        return Err("تعديل المستخدمين يجب أن يتم من شاشة المستخدمين المحمية".into());
    }
    let permission = if q.contains("settings") {
        "settings"
    } else if q.contains("stocktake") {
        "stocktake"
    } else if q.contains("expenses") {
        "expenses"
    } else if q.contains("purchases") || q.contains("purchase_items") || q.contains("suppliers") {
        "purchases"
    } else if q.contains("returns") || q.contains("return_items") {
        "sales_return"
    } else if q.contains("sales set status") || q.contains("sales set document_state") {
        "invoices_cancel"
    } else if q.contains("sales") || q.contains("sale_items") || q.contains("sale_payments") {
        "sales_create"
    } else if q.contains("shifts") || q.contains("shift_cash") || q.contains("cash_movements") {
        "shifts"
    } else if q.contains("products") || q.contains("categories") || q.contains("stock_moves") {
        "products"
    } else if q.contains("customers") {
        "customers"
    } else if q.contains("payments") || q.contains("party_ledger") {
        "customers"
    } else {
        // activity_log وبقية السجلات البسيطة ما زالت تتطلب جلسة صحيحة.
        "sales_view"
    };
    crate::security::require_permission(sessions, conn, token.unwrap_or(""), permission)?;
    Ok(())
}
