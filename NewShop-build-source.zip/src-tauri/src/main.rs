// منع ظهور نافذة الـ console السوداء في ويندوز
#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

fn main() {
    newshop_lib::run()
}
