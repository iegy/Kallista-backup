// migrations.rs — إنشاء الجداول وترقية النسخ
use rusqlite::Connection;

pub const CURRENT_VERSION: i64 = 3;

pub fn run(conn: &Connection) -> Result<(), String> {
    conn.execute_batch(
        "PRAGMA journal_mode = WAL;
         PRAGMA foreign_keys = ON;
         PRAGMA synchronous = NORMAL;",
    )
    .map_err(|e| e.to_string())?;

    let version: i64 = conn
        .query_row("PRAGMA user_version", [], |r| r.get(0))
        .map_err(|e| e.to_string())?;

    if version >= CURRENT_VERSION {
        validate(conn)?;
        return Ok(());
    }

    // قاعدة بيانات فيها بيانات وهنرقّيها؟ ناخد نسخة احتياطية الأول.
    // لو النسخة فشلت لأي سبب، مانكملش الترقية أصلًا — الأمان أهم.
    if version > 0 {
        safety_copy(conn, version)?;
    }

    conn.execute_batch("BEGIN IMMEDIATE TRANSACTION;")
        .map_err(|e| format!("تعذّر بدء ترقية قاعدة البيانات: {e}"))?;

    let result = (|| -> Result<(), String> {
        if version < 1 {
            conn.execute_batch(V1)
                .map_err(|e| format!("تعذّر إنشاء مخطط قاعدة البيانات الأساسي: {e}"))?;
        }
        if version < 2 {
            conn.execute_batch(V2)
                .map_err(|e| format!("تعذّرت ترقية قاعدة البيانات إلى نسخة ٢: {e}"))?;
        }
        if version < 3 {
            conn.execute_batch(V3)
                .map_err(|e| format!("تعذّرت ترقية قاعدة البيانات إلى NewShop 2.0: {e}"))?;
        }

        conn.execute_batch(&format!("PRAGMA user_version = {CURRENT_VERSION};"))
            .map_err(|e| e.to_string())?;
        validate(conn)?;
        Ok(())
    })();

    match result {
        Ok(()) => conn
            .execute_batch("COMMIT;")
            .map_err(|e| format!("تعذّر تثبيت ترقية قاعدة البيانات: {e}")),
        Err(e) => {
            let _ = conn.execute_batch("ROLLBACK;");
            Err(format!(
                "تم إلغاء الترقية بالكامل وبقيت قاعدة البيانات الأصلية كما هي. {e}"
            ))
        }
    }
}

/// فحص النزاهة والجداول الجوهرية قبل اعتماد Migration أو فتح البرنامج.
pub fn validate(conn: &Connection) -> Result<(), String> {
    let integrity: String = conn
        .query_row("PRAGMA integrity_check", [], |r| r.get(0))
        .map_err(|e| format!("تعذّر فحص سلامة قاعدة البيانات: {e}"))?;
    if integrity.to_ascii_lowercase() != "ok" {
        return Err(format!("فحص سلامة SQLite فشل: {integrity}"));
    }

    for table in [
        "settings",
        "products",
        "customers",
        "suppliers",
        "sales",
        "sale_items",
        "purchases",
        "purchase_items",
        "returns",
        "return_items",
        "stock_moves",
        "users",
        "shifts",
        "party_ledger",
        "audit_log",
    ] {
        let found: i64 = conn
            .query_row(
                "SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name=?1",
                [table],
                |r| r.get(0),
            )
            .map_err(|e| e.to_string())?;
        if found != 1 {
            return Err(format!("قاعدة البيانات لا تحتوي الجدول المطلوب: {table}"));
        }
    }

    let mut fk = conn
        .prepare("PRAGMA foreign_key_check")
        .map_err(|e| e.to_string())?;
    let mut rows = fk.query([]).map_err(|e| e.to_string())?;
    if rows.next().map_err(|e| e.to_string())?.is_some() {
        return Err("فحص العلاقات Foreign Keys فشل".into());
    }
    Ok(())
}

/// نسخة احتياطية قبل الترقية، جوّه مجلد النسخ باسم واضح.
fn safety_copy(conn: &Connection, from_version: i64) -> Result<(), String> {
    let dir = crate::app_dir().join("backups");
    let _ = std::fs::create_dir_all(&dir);
    let name = format!(
        "before-upgrade-v{from_version}-to-v{CURRENT_VERSION}_{}.db",
        crate::backup::stamp()
    );
    let path = dir.join(name);
    let _ = std::fs::remove_file(&path);
    let escaped = path.to_string_lossy().replace('\'', "''");
    conn.execute_batch(&format!("VACUUM INTO '{escaped}'"))
        .map_err(|e| format!("تعذّر أخذ نسخة احتياطية قبل الترقية: {e}"))?;
    Ok(())
}

/// مخطط قاعدة البيانات — مصدر واحد مشترك بين Rust وواجهة المعاينة
const V1: &str = include_str!("../../src/db/schema.sql");
const V2: &str = include_str!("../../src/db/schema_v2.sql");
const V3: &str = include_str!("../../src/db/schema_v3.sql");

#[cfg(test)]
mod tests {
    use super::*;

    /// نفس منطق run() من غير النسخة الاحتياطية (عشان الاختبار مايكتبش على القرص)
    fn migrate(conn: &Connection) {
        let version: i64 = conn
            .query_row("PRAGMA user_version", [], |r| r.get(0))
            .unwrap();
        if version >= CURRENT_VERSION {
            return;
        }
        if version < 1 {
            conn.execute_batch(V1).unwrap();
        }
        if version < 2 {
            conn.execute_batch(V2).unwrap();
        }
        if version < 3 {
            conn.execute_batch(V3).unwrap();
        }
        conn.execute_batch(&format!("PRAGMA user_version = {CURRENT_VERSION};"))
            .unwrap();
    }

    /// قاعدة جديدة لازم تتعمل كاملة وتوصل لآخر نسخة
    #[test]
    fn fresh_database_reaches_current_version() {
        let conn = Connection::open_in_memory().unwrap();
        migrate(&conn);

        let v: i64 = conn
            .query_row("PRAGMA user_version", [], |r| r.get(0))
            .unwrap();
        assert_eq!(v, CURRENT_VERSION);

        for t in [
            "shifts",
            "shift_cash",
            "sale_payments",
            "party_ledger",
            "audit_log",
            "product_barcodes",
            "suspended_sales",
        ] {
            let n: i64 = conn
                .query_row(
                    "SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name=?1",
                    [t],
                    |r| r.get(0),
                )
                .unwrap();
            assert_eq!(n, 1, "الجدول {t} مش موجود بعد الترقية");
        }
    }

    /// قاعدة نسخة ١٫٠ فيها بيانات: الترقية لازم تحافظ عليها وترحّل المدفوعات
    #[test]
    fn upgrade_keeps_data_and_moves_payments() {
        let conn = Connection::open_in_memory().unwrap();
        conn.execute_batch(V1).unwrap();
        conn.execute_batch("PRAGMA user_version = 1;").unwrap();
        conn.execute_batch(
            "INSERT INTO products(code,name,cost_price,sell_price,qty)
               VALUES('P1','لبن',20,25,50);
             INSERT INTO customers(name,balance) VALUES('أحمد',0);
             INSERT INTO sales(invoice_no,customer_id,subtotal,total,paid,remaining,payment_type)
               VALUES('INV-1',1,500,500,500,0,'cash');
             INSERT INTO sales(invoice_no,customer_id,subtotal,total,paid,remaining,payment_type)
               VALUES('INV-2',1,300,300,100,200,'credit');",
        )
        .unwrap();

        migrate(&conn);

        let products: i64 = conn
            .query_row("SELECT COUNT(*) FROM products", [], |r| r.get(0))
            .unwrap();
        assert_eq!(products, 1, "البيانات القديمة ضاعت");

        let sales_total: f64 = conn
            .query_row("SELECT SUM(total) FROM sales", [], |r| r.get(0))
            .unwrap();
        let moved: f64 = conn
            .query_row("SELECT SUM(amount) FROM sale_payments", [], |r| r.get(0))
            .unwrap();
        assert!(
            (sales_total - moved).abs() < 0.001,
            "المدفوعات المرحّلة ({moved}) مش مساوية إجمالي الفواتير ({sales_total})"
        );

        conn.query_row("SELECT shift_id FROM sales LIMIT 1", [], |r| {
            r.get::<_, Option<i64>>(0)
        })
        .unwrap();
        conn.query_row("SELECT plu FROM products LIMIT 1", [], |r| {
            r.get::<_, Option<String>>(0)
        })
        .unwrap();
        let name: String = conn
            .query_row(
                "SELECT product_name_snapshot FROM sale_items LIMIT 1",
                [],
                |r| r.get(0),
            )
            .unwrap_or_else(|_| "".into());
        assert!(name.is_empty() || name == "لبن");
    }

    /// الترقية مابتتنفذش مرتين على نفس القاعدة
    #[test]
    fn migration_is_not_applied_twice() {
        let conn = Connection::open_in_memory().unwrap();
        conn.execute_batch(V1).unwrap();
        conn.execute_batch("PRAGMA user_version = 1;").unwrap();
        conn.execute_batch(
            "INSERT INTO sales(invoice_no,subtotal,total,paid,remaining)
               VALUES('INV-1',100,100,100,0);",
        )
        .unwrap();

        migrate(&conn);
        let before: i64 = conn
            .query_row("SELECT COUNT(*) FROM sale_payments", [], |r| r.get(0))
            .unwrap();
        migrate(&conn);
        let after: i64 = conn
            .query_row("SELECT COUNT(*) FROM sale_payments", [], |r| r.get(0))
            .unwrap();
        assert_eq!(before, after, "الترقية اتنفذت مرتين وكرّرت البيانات");
        assert_eq!(before, 1);
    }

    #[test]
    fn audit_and_ledger_are_immutable() {
        let conn = Connection::open_in_memory().unwrap();
        migrate(&conn);
        conn.execute(
            "INSERT INTO audit_log(action, reason) VALUES('test','original')",
            [],
        )
        .unwrap();
        assert!(conn.execute("DELETE FROM audit_log", []).is_err());

        conn.execute_batch("INSERT INTO customers(name,balance) VALUES('عميل',0);")
            .unwrap();
        conn.execute(
            "INSERT INTO party_ledger(party_type,party_id,entry_type,debit) VALUES('customer',1,'sale',10)",
            [],
        )
        .unwrap();
        assert!(conn.execute("UPDATE party_ledger SET debit=20", []).is_err());
    }
}
