// auth.rs — تشفير كلمات السر بـ Argon2
// كلمة السر نفسها مابتتخزنش أبدًا — بيتخزن هاش مع ملح عشوائي لكل مستخدم.

use argon2::Argon2;
use password_hash::{rand_core::OsRng, PasswordHash, PasswordHasher, PasswordVerifier, SaltString};

#[tauri::command]
pub fn hash_password(password: String) -> Result<String, String> {
    if password.chars().count() < 8 {
        return Err("كلمة السر يجب ألا تقل عن ٨ أحرف".into());
    }
    let salt = SaltString::generate(&mut OsRng);
    Argon2::default()
        .hash_password(password.as_bytes(), &salt)
        .map(|h| h.to_string())
        .map_err(|e| format!("تعذّر تشفير كلمة السر: {e}"))
}

#[tauri::command]
pub fn verify_password(password: String, hash: String) -> bool {
    match PasswordHash::new(&hash) {
        Ok(parsed) => Argon2::default()
            .verify_password(password.as_bytes(), &parsed)
            .is_ok(),
        Err(_) => false,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn hash_then_verify() {
        let h = hash_password("s3cret-pass".into()).unwrap();
        assert!(h.starts_with("$argon2"), "لازم يكون هاش Argon2");
        assert!(verify_password("s3cret-pass".into(), h.clone()));
        assert!(!verify_password("wrong".into(), h));
    }

    #[test]
    fn same_password_gives_different_hashes() {
        let a = hash_password("same-pass".into()).unwrap();
        let b = hash_password("same-pass".into()).unwrap();
        assert_ne!(a, b, "الملح لازم يكون عشوائي لكل مستخدم");
    }

    #[test]
    fn rejects_short_password() {
        assert!(hash_password("ab".into()).is_err());
    }
}
