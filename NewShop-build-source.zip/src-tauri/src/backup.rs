// backup.rs — النسخ الاحتياطي والاسترجاع
// النسخة بتتاخد بـ VACUUM INTO عشان تطلع نسخة سليمة ومضغوطة حتى والبرنامج شغال،
// وبعدين بتتحط جوه ملف ZIP.

use crate::db::Db;
use crate::security::Sessions;
use rusqlite::Connection;
use serde::Serialize;
use std::fs;
use std::io::{Read, Write};
use std::path::{Path, PathBuf};
use tauri::State;
use zip::write::SimpleFileOptions;

const KEEP: usize = 10;

fn backups_dir() -> PathBuf {
    let d = crate::app_dir().join("backups");
    let _ = fs::create_dir_all(&d);
    d
}

pub fn stamp() -> String {
    use std::time::{SystemTime, UNIX_EPOCH};
    let secs = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_secs())
        .unwrap_or(0);
    let days = (secs / 86400) as i64;
    let (y, m, d) = crate::license::civil_from_days_pub(days);
    let rem = secs % 86400;
    format!(
        "{y:04}-{m:02}-{d:02}_{:02}-{:02}-{:02}",
        rem / 3600,
        (rem % 3600) / 60,
        rem % 60
    )
}

/// نسخة سليمة من قاعدة البيانات إلى ملف مؤقت
fn snapshot(conn: &Connection) -> Result<PathBuf, String> {
    let tmp = std::env::temp_dir().join(format!("newshop_snap_{}.db", stamp()));
    let _ = fs::remove_file(&tmp);
    let escaped = tmp.to_string_lossy().replace('\'', "''");
    conn.execute_batch(&format!("VACUUM INTO '{escaped}'"))
        .map_err(|e| format!("تعذّر أخذ نسخة من قاعدة البيانات: {e}"))?;
    Ok(tmp)
}

fn zip_file(src: &Path, dest: &Path, name_inside: &str) -> Result<u64, String> {
    let data = fs::read(src).map_err(|e| format!("تعذّر قراءة النسخة: {e}"))?;
    let f = fs::File::create(dest).map_err(|e| format!("تعذّر إنشاء ملف النسخة: {e}"))?;
    let mut z = zip::ZipWriter::new(f);
    z.start_file(
        name_inside,
        SimpleFileOptions::default().compression_method(zip::CompressionMethod::Deflated),
    )
    .map_err(|e| e.to_string())?;
    z.write_all(&data).map_err(|e| e.to_string())?;
    z.finish().map_err(|e| e.to_string())?;
    Ok(fs::metadata(dest).map(|m| m.len()).unwrap_or(0))
}

#[derive(Serialize)]
pub struct BackupInfo {
    pub path: String,
    pub name: String,
    pub size: u64,
}

/// نسخة احتياطية في مكان يختاره المستخدم
#[tauri::command]
pub fn backup_now(
    state: State<'_, Db>,
    sessions: State<'_, Sessions>,
    dest: String,
    session_token: String,
) -> Result<BackupInfo, String> {
    let conn = state.0.lock().map_err(|e| e.to_string())?;
    let user = crate::security::require_permission(&sessions, &conn, &session_token, "backup")?;
    crate::license::require_official_license()?;
    let tmp = snapshot(&conn)?;
    let dest_path = PathBuf::from(&dest);
    if let Some(p) = dest_path.parent() {
        let _ = fs::create_dir_all(p);
    }
    let size = zip_file(&tmp, &dest_path, "newshop.db")?;
    let _ = fs::remove_file(&tmp);
    conn.execute(
        "INSERT INTO audit_log(user_id,action,entity_type,reason) VALUES(?1,'backup_created','backup',?2)",
        rusqlite::params![user.id, dest_path.to_string_lossy()],
    )
    .map_err(|e| e.to_string())?;
    Ok(BackupInfo {
        name: dest_path
            .file_name()
            .map(|s| s.to_string_lossy().to_string())
            .unwrap_or_default(),
        path: dest,
        size,
    })
}

/// نسخة تلقائية في مجلد البرنامج مع الاحتفاظ بآخر ١٠ نسخ
#[tauri::command]
pub fn auto_backup(state: State<'_, Db>, daily: Option<bool>) -> Result<BackupInfo, String> {
    let dir = backups_dir();
    if daily.unwrap_or(false) {
        let prefix = format!("NewShop-{}", &stamp()[..10]);
        let mut found: Vec<PathBuf> = fs::read_dir(&dir)
            .map(|rd| rd.filter_map(|e| e.ok()).map(|e| e.path())
                .filter(|p| p.file_name().map(|n| n.to_string_lossy().starts_with(&prefix)).unwrap_or(false)).collect())
            .unwrap_or_default();
        found.sort();
        if let Some(path) = found.pop() {
            return Ok(BackupInfo {
                name: path.file_name().map(|n| n.to_string_lossy().to_string()).unwrap_or_default(),
                size: fs::metadata(&path).map(|m| m.len()).unwrap_or(0),
                path: path.to_string_lossy().to_string(),
            });
        }
    }
    let dest = dir.join(format!("NewShop-{}.zip", stamp()));
    let info = {
        let conn = state.0.lock().map_err(|e| e.to_string())?;
        let tmp = snapshot(&conn)?;
        let size = zip_file(&tmp, &dest, "newshop.db")?;
        let _ = fs::remove_file(&tmp);
        BackupInfo {
            name: dest.file_name().unwrap().to_string_lossy().to_string(),
            path: dest.to_string_lossy().to_string(),
            size,
        }
    };
    prune(&dir);
    Ok(info)
}

/// حذف النسخ الزيادة والاحتفاظ بأحدث ١٠
fn prune(dir: &Path) {
    let mut files: Vec<PathBuf> = fs::read_dir(dir)
        .map(|rd| {
            rd.filter_map(|e| e.ok())
                .map(|e| e.path())
                .filter(|p| p.extension().map(|x| x == "zip").unwrap_or(false))
                .collect()
        })
        .unwrap_or_default();
    files.sort();
    while files.len() > KEEP {
        let old = files.remove(0);
        let _ = fs::remove_file(old);
    }
}

#[tauri::command]
pub fn list_backups(
    state: State<'_, Db>,
    sessions: State<'_, Sessions>,
    session_token: String,
) -> Result<Vec<BackupInfo>, String> {
    {
        let conn = state.0.lock().map_err(|e| e.to_string())?;
        crate::security::require_permission(&sessions, &conn, &session_token, "backup")?;
    }
    let dir = backups_dir();
    let mut out: Vec<BackupInfo> = fs::read_dir(&dir)
        .map(|rd| {
            rd.filter_map(|e| e.ok())
                .filter(|e| e.path().extension().map(|x| x == "zip").unwrap_or(false))
                .map(|e| BackupInfo {
                    name: e.file_name().to_string_lossy().to_string(),
                    path: e.path().to_string_lossy().to_string(),
                    size: e.metadata().map(|m| m.len()).unwrap_or(0),
                })
                .collect()
        })
        .unwrap_or_default();
    out.sort_by(|a, b| b.name.cmp(&a.name));
    Ok(out)
}

/// استرجاع من ملف نسخة (.zip أو .db) — بيعمل نسخة أمان قبل الاستبدال
#[tauri::command]
pub fn restore(
    state: State<'_, Db>,
    sessions: State<'_, Sessions>,
    path: String,
    session_token: String,
) -> Result<String, String> {
    let src = PathBuf::from(&path);
    if !src.exists() {
        return Err("الملف مش موجود".into());
    }

    // ١) نطلّع محتوى قاعدة البيانات من الملف
    let data: Vec<u8> = if src.extension().map(|x| x == "zip").unwrap_or(false) {
        let f = fs::File::open(&src).map_err(|e| e.to_string())?;
        let mut z = zip::ZipArchive::new(f).map_err(|e| format!("ملف مضغوط غير صالح: {e}"))?;
        let mut entry = z
            .by_index(0)
            .map_err(|e| format!("الملف المضغوط فاضي: {e}"))?;
        let mut v = Vec::new();
        entry.read_to_end(&mut v).map_err(|e| e.to_string())?;
        v
    } else {
        fs::read(&src).map_err(|e| e.to_string())?
    };

    if data.len() < 16 || &data[..15] != b"SQLite format 3" {
        return Err("الملف ده مش نسخة احتياطية صالحة من NewShop".into());
    }

    let candidate = crate::app_dir().join(format!("restore-candidate-{}.db", stamp()));
    fs::write(&candidate, &data).map_err(|e| format!("تعذّر تجهيز ملف الاسترجاع: {e}"))?;
    if let Err(e) = validate_candidate(&candidate) {
        let _ = fs::remove_file(&candidate);
        return Err(e);
    }

    // ٢) نسخة أمان من الوضع الحالي قبل ما نستبدله
    let mut guard = state.0.lock().map_err(|e| e.to_string())?;
    let actor = crate::security::require_permission(&sessions, &guard, &session_token, "restore")?;
    let safety = backups_dir().join(format!("before-restore-{}.zip", stamp()));
    let tmp = snapshot(&guard)?;
    if let Err(e) = zip_file(&tmp, &safety, "newshop.db") {
        let _ = fs::remove_file(&tmp);
        let _ = fs::remove_file(&candidate);
        return Err(format!("توقف الاسترجاع لأن نسخة الأمان الإلزامية فشلت: {e}"));
    }
    let _ = fs::remove_file(&tmp);

    // ٣) نقفل الاتصال ونستبدل الملف بطريقة قابلة للرجوع الفوري.
    *guard = Connection::open_in_memory().map_err(|e| e.to_string())?;

    let db = crate::db_path();
    for ext in ["-wal", "-shm"] {
        let _ = fs::remove_file(format!("{}{}", db.to_string_lossy(), ext));
    }
    let rollback = crate::app_dir().join(format!("restore-rollback-{}.db", stamp()));
    if db.exists() {
        fs::rename(&db, &rollback)
            .map_err(|e| format!("تعذّر تأمين قاعدة البيانات الحالية: {e}"))?;
    }
    if let Err(e) = fs::rename(&candidate, &db) {
        let _ = fs::rename(&rollback, &db);
        *guard = Connection::open(&db).map_err(|open| open.to_string())?;
        return Err(format!("تعذّر وضع قاعدة البيانات المسترجعة: {e}"));
    }

    let opened = Connection::open(&db)
        .map_err(|e| format!("تعذّر فتح قاعدة البيانات المسترجعة: {e}"))
        .and_then(|conn| {
            crate::migrations::run(&conn)?;
            crate::migrations::validate(&conn)?;
            conn.execute(
                "INSERT INTO audit_log(user_id,action,entity_type,reason,metadata)
                 VALUES(?1,'restore_completed','backup',?2,?3)",
                rusqlite::params![actor.id, path, safety.to_string_lossy()],
            )
            .map_err(|e| e.to_string())?;
            Ok(conn)
        });

    match opened {
        Ok(conn) => {
            *guard = conn;
            let _ = fs::remove_file(&rollback);
            Ok(safety.to_string_lossy().to_string())
        }
        Err(e) => {
            let failed = crate::app_dir().join(format!("failed-restore-{}.db", stamp()));
            let _ = fs::rename(&db, &failed);
            fs::rename(&rollback, &db)
                .map_err(|rollback_error| format!("فشل الاسترجاع وفشل الرجوع للقاعدة الأصلية: {rollback_error}"))?;
            *guard = Connection::open(&db).map_err(|open| open.to_string())?;
            Err(format!("فشل الاسترجاع وتمت إعادة قاعدة البيانات الأصلية بأمان: {e}"))
        }
    }
}

fn validate_candidate(path: &Path) -> Result<(), String> {
    let conn = Connection::open(path).map_err(|e| format!("ملف SQLite غير صالح: {e}"))?;
    let integrity: String = conn
        .query_row("PRAGMA integrity_check", [], |r| r.get(0))
        .map_err(|e| e.to_string())?;
    if integrity.to_ascii_lowercase() != "ok" {
        return Err(format!("فحص سلامة النسخة فشل: {integrity}"));
    }
    for table in ["settings", "products", "sales", "sale_items", "users"] {
        let exists: i64 = conn
            .query_row(
                "SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name=?1",
                [table],
                |r| r.get(0),
            )
            .map_err(|e| e.to_string())?;
        if exists != 1 {
            return Err(format!("الملف ليس نسخة NewShop: الجدول {table} غير موجود"));
        }
    }
    let version: i64 = conn
        .query_row("PRAGMA user_version", [], |r| r.get(0))
        .map_err(|e| e.to_string())?;
    if version > crate::migrations::CURRENT_VERSION {
        return Err("النسخة الاحتياطية من إصدار أحدث ولا يمكن فتحها بهذا البرنامج".into());
    }
    Ok(())
}
