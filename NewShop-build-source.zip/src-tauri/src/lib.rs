// lib.rs — نقطة البداية، تسجيل الأوامر، فتح قاعدة البيانات
mod auth;
mod backup;
mod db;
mod license;
mod migrations;
mod security;

use rusqlite::Connection;
use std::fs;
use std::path::PathBuf;
use std::sync::Mutex;

/// مجلد البيانات. وجود portable.txt بجوار NewShop.exe يفعّل الوضع المحمول.
pub fn app_dir() -> PathBuf {
    if let Ok(exe) = std::env::current_exe() {
        if let Some(dir) = exe.parent() {
            if dir.join("portable.txt").is_file() {
                let portable = dir.join("NewShopData");
                let _ = fs::create_dir_all(portable.join("backups"));
                return portable;
            }
        }
    }
    let base = dirs::config_dir().unwrap_or_else(|| PathBuf::from("."));
    let dir = base.join("NewShop");
    let _ = fs::create_dir_all(&dir);
    let _ = fs::create_dir_all(dir.join("backups"));
    dir
}


pub fn db_path() -> PathBuf {
    app_dir().join("newshop.db")
}

/// حفظ ملف على القرص (بيستخدمه تصدير Excel) — المحتوى بيتبعت Base64
#[tauri::command]
fn save_file(
    path: String,
    contents_b64: String,
    session_token: String,
    state: tauri::State<'_, db::Db>,
    sessions: tauri::State<'_, security::Sessions>,
) -> Result<(), String> {
    {
        let conn = state.0.lock().map_err(|e| e.to_string())?;
        security::session_user(&sessions, &conn, &session_token)?;
    }
    license::require_official_license()?;
    let target = PathBuf::from(&path);
    let ext = target.extension().and_then(|x| x.to_str()).unwrap_or("").to_ascii_lowercase();
    if ext != "xlsx" {
        return Err("التصدير مسموح لملفات Excel (.xlsx) فقط".into());
    }
    use base64::Engine;
    let bytes = base64::engine::general_purpose::STANDARD
        .decode(contents_b64.as_bytes())
        .map_err(|e| format!("محتوى غير صالح: {e}"))?;
    fs::write(&path, bytes).map_err(|e| format!("تعذّر حفظ الملف: {e}"))
}

/// قراءة ملف نصي (بيستخدمه تحميل ملف الترخيص .lic)
#[tauri::command]
fn read_text_file(path: String) -> Result<String, String> {
    let target = PathBuf::from(&path);
    let ext = target.extension().and_then(|x| x.to_str()).unwrap_or("").to_ascii_lowercase();
    if ext != "lic" && ext != "txt" {
        return Err("يمكن قراءة ملفات الترخيص .lic أو .txt فقط".into());
    }
    let meta = fs::metadata(&target).map_err(|e| format!("تعذّر قراءة الملف: {e}"))?;
    if meta.len() > 256 * 1024 {
        return Err("ملف الترخيص أكبر من الحد المسموح".into());
    }
    fs::read_to_string(&target).map_err(|e| format!("تعذّر قراءة الملف: {e}"))
}

/// معلومات عامة تعرضها صفحة "عن البرنامج"
#[tauri::command]
fn app_info() -> serde_json::Value {
    serde_json::json!({
        "name": "NewShop",
        "version": env!("CARGO_PKG_VERSION"),
        "developer": "محمد حسين",
        "phone": "01000220606",
        "email": "egyup@outlook.com",
        "db_path": db_path().to_string_lossy(),
        "device_code": license::fingerprint_code(),
        "app_dir": app_dir().to_string_lossy(),
        "portable": std::env::current_exe().ok().and_then(|p| p.parent().map(|d| d.join("portable.txt").is_file())).unwrap_or(false),
    })
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    let conn = Connection::open(db_path()).expect("تعذّر فتح قاعدة البيانات");
    migrations::run(&conn).expect("تعذّر تجهيز قاعدة البيانات");

    tauri::Builder::default()
        .plugin(tauri_plugin_dialog::init())
        .manage(db::Db(Mutex::new(conn)))
        .manage(security::Sessions::default())
        .invoke_handler(tauri::generate_handler![
            db::db_query,
            db::db_execute,
            db::db_batch,
            save_file,
            read_text_file,
            app_info,
            auth::hash_password,
            auth::verify_password,
            security::auth_login,
            security::auth_logout,
            security::auth_needs_setup,
            security::auth_create_owner,
            security::manager_approve,
            security::user_save,
            security::user_deactivate,
            license::license_status,
            license::activate,
            license::machine_code,
            backup::backup_now,
            backup::auto_backup,
            backup::list_backups,
            backup::restore
        ])
        .run(tauri::generate_context!())
        .expect("خطأ أثناء تشغيل البرنامج");
}
