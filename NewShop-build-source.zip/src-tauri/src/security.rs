//! جلسات الدخول والصلاحيات الحساسة في طبقة Rust.
//! الواجهة لا تستطيع ترقية الأدوار أو تعديل المالك مباشرةً عبر SQL.

use crate::db::Db;
use rusqlite::{params, OptionalExtension};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::sync::Mutex;
use std::time::{Duration, Instant};
use tauri::State;
use uuid::Uuid;

const ALL_PERMISSIONS: &[&str] = &[
    "sales_view",
    "sales_create",
    "invoices_cancel",
    "sales_return",
    "sales_reprint",
    "discount_line",
    "discount_invoice",
    "edit_prices",
    "view_cost",
    "view_profits",
    "shifts_open",
    "shifts_close",
    "shifts",
    "products",
    "products_edit",
    "stock_adjust",
    "stocktake",
    "purchases",
    "purchase_return",
    "customers",
    "customer_receipts",
    "suppliers",
    "supplier_payments",
    "expenses",
    "reports",
    "users",
    "backup",
    "restore",
    "settings",
    "license_info",
    "override_stock",
    "labels",
    "import",
];

#[derive(Clone)]
struct Session {
    user_id: i64,
    touched: Instant,
}

#[derive(Default)]
pub struct Sessions(Mutex<HashMap<String, Session>>);

#[derive(Debug, Serialize)]
pub struct UserDto {
    pub id: i64,
    pub username: String,
    pub full_name: Option<String>,
    pub role: String,
    pub permissions: Vec<String>,
    pub is_active: i64,
    pub max_line_discount: f64,
    pub max_invoice_discount: f64,
}

#[derive(Debug, Serialize)]
pub struct LoginResult {
    pub session_token: String,
    pub user: UserDto,
}

fn permissions(raw: Option<String>) -> Vec<String> {
    raw.and_then(|s| serde_json::from_str::<Vec<String>>(&s).ok())
        .unwrap_or_default()
}

fn user_by_id(conn: &rusqlite::Connection, id: i64) -> Result<UserDto, String> {
    conn.query_row(
        "SELECT id,username,full_name,role,permissions,is_active,
                max_line_discount,max_invoice_discount
           FROM users WHERE id=?1",
        [id],
        |r| {
            Ok(UserDto {
                id: r.get(0)?,
                username: r.get(1)?,
                full_name: r.get(2)?,
                role: r.get(3)?,
                permissions: permissions(r.get(4)?),
                is_active: r.get(5)?,
                max_line_discount: r.get(6)?,
                max_invoice_discount: r.get(7)?,
            })
        },
    )
    .map_err(|e| e.to_string())
}

fn role_allows(user: &UserDto, permission: &str) -> bool {
    user.role == "owner"
        || user.role == "admin"
        || user.permissions.iter().any(|p| p == permission)
        // توافق مع مفاتيح v1.1 العامة أثناء الترقية.
        || (permission == "sales_create" && user.permissions.iter().any(|p| p == "sales"))
        || (permission == "sales_view" && user.permissions.iter().any(|p| p == "sales"))
}

pub fn session_user(
    sessions: &Sessions,
    conn: &rusqlite::Connection,
    token: &str,
) -> Result<UserDto, String> {
    let timeout_minutes: u64 = conn
        .query_row(
            "SELECT COALESCE(CAST(value AS INTEGER),30) FROM settings WHERE key='admin_session_minutes'",
            [],
            |r| r.get::<_, i64>(0),
        )
        .unwrap_or(30)
        .clamp(5, 1440) as u64;
    let mut map = sessions.0.lock().map_err(|e| e.to_string())?;
    let session = map
        .get_mut(token)
        .ok_or_else(|| "انتهت جلسة الدخول — سجّل الدخول مرة أخرى".to_string())?;
    if session.touched.elapsed() > Duration::from_secs(timeout_minutes * 60) {
        map.remove(token);
        return Err("انتهت جلسة الدخول — سجّل الدخول مرة أخرى".into());
    }
    session.touched = Instant::now();
    let user = user_by_id(conn, session.user_id)?;
    if user.is_active != 1 {
        map.remove(token);
        return Err("تم إيقاف حساب المستخدم".into());
    }
    Ok(user)
}

pub fn require_permission(
    sessions: &Sessions,
    conn: &rusqlite::Connection,
    token: &str,
    permission: &str,
) -> Result<UserDto, String> {
    let user = session_user(sessions, conn, token)?;
    if !role_allows(&user, permission) {
        return Err("ليس لديك صلاحية لتنفيذ هذه العملية".into());
    }
    Ok(user)
}

fn audit(
    conn: &rusqlite::Connection,
    user_id: Option<i64>,
    override_id: Option<i64>,
    action: &str,
    entity_type: Option<&str>,
    entity_id: Option<i64>,
    reason: Option<&str>,
    metadata: Option<&str>,
) -> Result<(), String> {
    conn.execute(
        "INSERT INTO audit_log(user_id,override_user_id,action,entity_type,entity_id,reason,metadata)
         VALUES(?1,?2,?3,?4,?5,?6,?7)",
        params![user_id, override_id, action, entity_type, entity_id, reason, metadata],
    )
    .map_err(|e| e.to_string())?;
    Ok(())
}

#[tauri::command]
pub fn auth_needs_setup(state: State<'_, Db>) -> Result<bool, String> {
    let conn = state.0.lock().map_err(|e| e.to_string())?;
    let count: i64 = conn
        .query_row("SELECT COUNT(*) FROM users", [], |r| r.get(0))
        .map_err(|e| e.to_string())?;
    Ok(count == 0)
}

#[tauri::command]
pub fn auth_create_owner(
    state: State<'_, Db>,
    username: String,
    full_name: String,
    password: String,
) -> Result<(), String> {
    if password.chars().count() < 8 {
        return Err("كلمة السر يجب ألا تقل عن ٨ أحرف".into());
    }
    let mut conn = state.0.lock().map_err(|e| e.to_string())?;
    let count: i64 = conn
        .query_row("SELECT COUNT(*) FROM users", [], |r| r.get(0))
        .map_err(|e| e.to_string())?;
    if count != 0 {
        return Err("تم إنشاء حساب المالك من قبل".into());
    }
    let name = username.trim();
    if name.len() < 3 {
        return Err("اسم المستخدم يجب ألا يقل عن ٣ أحرف".into());
    }
    let hash = crate::auth::hash_password(password)?;
    let tx = conn.transaction().map_err(|e| e.to_string())?;
    tx.execute(
        "INSERT INTO users(username,password_hash,full_name,role,permissions,is_active,
                           max_line_discount,max_invoice_discount)
         VALUES(?1,?2,?3,'owner',?4,1,100,100)",
        params![
            name,
            hash,
            if full_name.trim().is_empty() {
                "المالك"
            } else {
                full_name.trim()
            },
            serde_json::to_string(ALL_PERMISSIONS).map_err(|e| e.to_string())?
        ],
    )
    .map_err(|e| {
        if e.to_string().contains("UNIQUE") {
            "اسم المستخدم موجود بالفعل".to_string()
        } else {
            e.to_string()
        }
    })?;
    let id = tx.last_insert_rowid();
    audit(&tx, Some(id), None, "owner_created", Some("user"), Some(id), None, None)?;
    tx.commit().map_err(|e| e.to_string())
}

#[tauri::command]
pub fn auth_login(
    state: State<'_, Db>,
    sessions: State<'_, Sessions>,
    username: String,
    password: String,
) -> Result<LoginResult, String> {
    let conn = state.0.lock().map_err(|e| e.to_string())?;
    let name = username.trim();
    let row: Option<(i64, String, i64, i64)> = conn
        .query_row(
            "SELECT id,password_hash,is_active,
                    CASE WHEN locked_until IS NOT NULL AND locked_until > datetime('now','localtime')
                         THEN 1 ELSE 0 END
               FROM users WHERE username=?1",
            [name],
            |r| Ok((r.get(0)?, r.get(1)?, r.get(2)?, r.get(3)?)),
        )
        .optional()
        .map_err(|e| e.to_string())?;

    let Some((id, hash, active, locked)) = row else {
        let _ = audit(
            &conn,
            None,
            None,
            "login_failed",
            Some("user"),
            None,
            Some("بيانات دخول غير صحيحة"),
            None,
        );
        return Err("اسم المستخدم أو كلمة السر غير صحيحة".into());
    };
    if active != 1 {
        return Err("الحساب موقوف".into());
    }
    if locked == 1 {
        return Err("تم قفل الحساب مؤقتًا بسبب محاولات دخول فاشلة".into());
    }
    if !crate::auth::verify_password(password, hash) {
        conn.execute(
            "UPDATE users
                SET failed_login_count=failed_login_count+1,
                    locked_until=CASE WHEN failed_login_count+1 >=
                      COALESCE((SELECT CAST(value AS INTEGER) FROM settings WHERE key='failed_login_limit'),5)
                    THEN datetime('now','localtime','+' ||
                      COALESCE((SELECT value FROM settings WHERE key='failed_login_lock_minutes'),'15') || ' minutes')
                    ELSE locked_until END
              WHERE id=?1",
            [id],
        )
        .map_err(|e| e.to_string())?;
        let _ = audit(
            &conn,
            Some(id),
            None,
            "login_failed",
            Some("user"),
            Some(id),
            Some("كلمة سر غير صحيحة"),
            None,
        );
        return Err("اسم المستخدم أو كلمة السر غير صحيحة".into());
    }

    conn.execute(
        "UPDATE users SET failed_login_count=0,locked_until=NULL,
                          last_login_at=datetime('now','localtime') WHERE id=?1",
        [id],
    )
    .map_err(|e| e.to_string())?;
    audit(&conn, Some(id), None, "login", Some("user"), Some(id), None, None)?;
    let user = user_by_id(&conn, id)?;
    let token = Uuid::new_v4().to_string();
    sessions
        .0
        .lock()
        .map_err(|e| e.to_string())?
        .insert(
            token.clone(),
            Session {
                user_id: id,
                touched: Instant::now(),
            },
        );
    Ok(LoginResult {
        session_token: token,
        user,
    })
}

#[tauri::command]
pub fn auth_logout(sessions: State<'_, Sessions>, session_token: String) -> Result<(), String> {
    sessions
        .0
        .lock()
        .map_err(|e| e.to_string())?
        .remove(&session_token);
    Ok(())
}

#[derive(Debug, Serialize)]
pub struct ManagerApproval {
    pub id: i64,
    pub username: String,
    pub full_name: Option<String>,
}

#[tauri::command]
pub fn manager_approve(
    state: State<'_, Db>,
    sessions: State<'_, Sessions>,
    session_token: String,
    permission: String,
    username: String,
    pin_or_password: String,
    action: String,
    reason: String,
) -> Result<ManagerApproval, String> {
    let conn = state.0.lock().map_err(|e| e.to_string())?;
    let cashier = session_user(&sessions, &conn, &session_token)?;
    if reason.trim().is_empty() {
        return Err("اكتب سبب طلب موافقة المدير".into());
    }
    let row: Option<(i64, String, Option<String>, String, Option<String>, Option<String>, i64)> = conn
        .query_row(
            "SELECT id,username,full_name,role,permissions,
                    COALESCE(manager_pin_hash,password_hash),is_active
               FROM users WHERE username=?1",
            [username.trim()],
            |r| Ok((r.get(0)?,r.get(1)?,r.get(2)?,r.get(3)?,r.get(4)?,r.get(5)?,r.get(6)?)),
        )
        .optional()
        .map_err(|e| e.to_string())?;
    let Some((id, uname, full_name, role, raw_perms, hash, active)) = row else {
        return Err("بيانات موافقة المدير غير صحيحة".into());
    };
    if active != 1 || hash.is_none() || !crate::auth::verify_password(pin_or_password, hash.unwrap()) {
        return Err("بيانات موافقة المدير غير صحيحة".into());
    }
    let approver = UserDto {
        id,
        username: uname.clone(),
        full_name: full_name.clone(),
        role,
        permissions: permissions(raw_perms),
        is_active: active,
        max_line_discount: 100.0,
        max_invoice_discount: 100.0,
    };
    if !role_allows(&approver, &permission) {
        return Err("هذا المستخدم لا يملك صلاحية الموافقة المطلوبة".into());
    }
    audit(
        &conn,
        Some(cashier.id),
        Some(id),
        &action,
        None,
        None,
        Some(reason.trim()),
        None,
    )?;
    Ok(ManagerApproval {
        id,
        username: uname,
        full_name,
    })
}

#[derive(Debug, Deserialize)]
pub struct UserSaveInput {
    pub id: Option<i64>,
    pub username: String,
    pub full_name: Option<String>,
    pub role: String,
    #[serde(default)]
    pub permissions: Vec<String>,
    pub is_active: i64,
    pub password: Option<String>,
    pub max_line_discount: f64,
    pub max_invoice_discount: f64,
}

#[tauri::command]
pub fn user_save(
    state: State<'_, Db>,
    sessions: State<'_, Sessions>,
    session_token: String,
    input: UserSaveInput,
) -> Result<i64, String> {
    let mut conn = state.0.lock().map_err(|e| e.to_string())?;
    let actor = require_permission(&sessions, &conn, &session_token, "users")?;
    if input.username.trim().len() < 3 {
        return Err("اسم المستخدم يجب ألا يقل عن ٣ أحرف".into());
    }
    if !matches!(input.role.as_str(), "admin" | "cashier") {
        return Err("الدور المطلوب غير صالح".into());
    }
    if input.role == "admin" && actor.role != "owner" {
        return Err("المالك فقط يستطيع إنشاء أو ترقية مدير".into());
    }
    let password_hash = match input.password.as_deref().map(str::trim).filter(|p| !p.is_empty()) {
        Some(p) if p.chars().count() < 8 => return Err("كلمة السر يجب ألا تقل عن ٨ أحرف".into()),
        Some(p) => Some(crate::auth::hash_password(p.to_string())?),
        None => None,
    };

    let tx = conn.transaction().map_err(|e| e.to_string())?;
    let id = if let Some(id) = input.id {
        let (target_role, target_active): (String, i64) = tx
            .query_row("SELECT role,is_active FROM users WHERE id=?1", [id], |r| {
                Ok((r.get(0)?, r.get(1)?))
            })
            .map_err(|_| "المستخدم غير موجود".to_string())?;
        if target_role == "owner" && actor.id != id {
            return Err("لا يمكن لمستخدم آخر تعديل حساب المالك".into());
        }
        if target_role == "admin" && actor.role != "owner" && actor.id != id {
            return Err("لا يمكنك تعديل مدير أعلى منك".into());
        }
        if actor.id == id
            && (input.role != target_role || input.is_active != target_active)
        {
            return Err("لا يمكنك تغيير دورك أو إيقاف حسابك بنفسك".into());
        }
        let final_role = if target_role == "owner" { "owner" } else { input.role.as_str() };
        let final_permissions = if target_role == "owner" {
            serde_json::to_string(ALL_PERMISSIONS).map_err(|e| e.to_string())?
        } else {
            serde_json::to_string(&input.permissions).map_err(|e| e.to_string())?
        };
        tx.execute(
            "UPDATE users SET username=?1,full_name=?2,role=?3,permissions=?4,is_active=?5,
                              max_line_discount=?6,max_invoice_discount=?7,
                              updated_at=datetime('now','localtime') WHERE id=?8",
            params![
                input.username.trim(),
                input.full_name.as_deref().map(str::trim).filter(|s| !s.is_empty()),
                final_role,
                final_permissions,
                if target_role == "owner" { 1 } else { input.is_active },
                input.max_line_discount.clamp(0.0, 100.0),
                input.max_invoice_discount.clamp(0.0, 100.0),
                id
            ],
        )
        .map_err(|e| e.to_string())?;
        if let Some(hash) = password_hash {
            tx.execute("UPDATE users SET password_hash=?1 WHERE id=?2", params![hash, id])
                .map_err(|e| e.to_string())?;
        }
        id
    } else {
        let hash = password_hash.ok_or_else(|| "كلمة السر مطلوبة للمستخدم الجديد".to_string())?;
        tx.execute(
            "INSERT INTO users(username,password_hash,full_name,role,permissions,is_active,
                               max_line_discount,max_invoice_discount)
             VALUES(?1,?2,?3,?4,?5,?6,?7,?8)",
            params![
                input.username.trim(),
                hash,
                input.full_name.as_deref().map(str::trim).filter(|s| !s.is_empty()),
                input.role,
                serde_json::to_string(&input.permissions).map_err(|e| e.to_string())?,
                input.is_active,
                input.max_line_discount.clamp(0.0, 100.0),
                input.max_invoice_discount.clamp(0.0, 100.0)
            ],
        )
        .map_err(|e| e.to_string())?;
        tx.last_insert_rowid()
    };
    audit(
        &tx,
        Some(actor.id),
        None,
        "user_saved",
        Some("user"),
        Some(id),
        None,
        None,
    )?;
    tx.commit().map_err(|e| e.to_string())?;
    Ok(id)
}

#[tauri::command]
pub fn user_deactivate(
    state: State<'_, Db>,
    sessions: State<'_, Sessions>,
    session_token: String,
    user_id: i64,
    reason: String,
) -> Result<(), String> {
    let conn = state.0.lock().map_err(|e| e.to_string())?;
    let actor = require_permission(&sessions, &conn, &session_token, "users")?;
    if actor.id == user_id {
        return Err("لا يمكنك إيقاف الحساب الذي تعمل به".into());
    }
    let role: String = conn
        .query_row("SELECT role FROM users WHERE id=?1", [user_id], |r| r.get(0))
        .map_err(|_| "المستخدم غير موجود".to_string())?;
    if role == "owner" {
        return Err("حساب المالك محمي ولا يمكن إيقافه".into());
    }
    if role == "admin" && actor.role != "owner" {
        return Err("المالك فقط يستطيع إيقاف مدير".into());
    }
    conn.execute("UPDATE users SET is_active=0 WHERE id=?1", [user_id])
        .map_err(|e| e.to_string())?;
    audit(
        &conn,
        Some(actor.id),
        None,
        "user_deactivated",
        Some("user"),
        Some(user_id),
        Some(reason.trim()),
        None,
    )
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn permission_compatibility_keeps_v11_cashier_working() {
        let user = UserDto {
            id: 1,
            username: "cashier".into(),
            full_name: None,
            role: "cashier".into(),
            permissions: vec!["sales".into()],
            is_active: 1,
            max_line_discount: 10.0,
            max_invoice_discount: 10.0,
        };
        assert!(role_allows(&user, "sales_create"));
        assert!(!role_allows(&user, "users"));
    }
}
