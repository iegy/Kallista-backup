#!/usr/bin/env python3
"""يفحص تباين ألوان كل ثيم في theme.css على معيار WCAG AA.

التشغيل:  python3 scripts/check-contrast.py
بيرجّع كود خروج 1 لو في أي زوج ألوان راسب.
"""
import re
import sys
import pathlib

CSS = pathlib.Path(__file__).resolve().parent.parent / "src/styles/theme.css"

# الحد الأدنى: ٤٫٥ للنص العادي، ٣٫٠ للنص الكبير أو العناصر الرسومية
AA_TEXT = 4.5
AA_LARGE = 3.0


def parse_blocks(css: str) -> dict:
    """يطلّع متغيّرات كل ثيم من الكتل :root و [data-theme="..."]"""
    out = {}
    for sel, body in re.findall(r'(:root|\[data-theme="[a-z]+"\])\s*\{(.*?)\n\}', css, re.S):
        name = "olive" if sel == ":root" else re.search(r'"([a-z]+)"', sel).group(1)
        vars_ = dict(re.findall(r"(--[a-z0-9-]+)\s*:\s*([^;]+);", body))
        out[name] = {k: v.strip() for k, v in vars_.items()}
    return out


def resolve(themes: dict, theme: str, value: str, depth: int = 0) -> str:
    """يفكّ var(--x) لحد ما يوصل للون فعلي"""
    if depth > 6:
        raise ValueError(f"مرجع دائري: {value}")
    m = re.fullmatch(r"var\((--[a-z0-9-]+)\)", value.strip())
    if not m:
        return value.strip()
    key = m.group(1)
    src = themes[theme].get(key) or themes["olive"].get(key)
    if src is None:
        raise KeyError(f"متغيّر غير معرّف: {key} في ثيم {theme}")
    return resolve(themes, theme, src, depth + 1)


def rgb(h: str):
    h = h.strip().lstrip("#")
    if len(h) == 3:
        h = "".join(c * 2 for c in h)
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def luminance(h: str) -> float:
    def lin(c):
        c /= 255
        return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4
    r, g, b = rgb(h)
    return 0.2126 * lin(r) + 0.7152 * lin(g) + 0.0722 * lin(b)


def contrast(a: str, b: str) -> float:
    la, lb = luminance(a), luminance(b)
    hi, lo = max(la, lb), min(la, lb)
    return (hi + 0.05) / (lo + 0.05)


# (الوصف، لون النص، لون الخلفية، الحد الأدنى)
PAIRS = [
    ("نص الأزرار على اللون الأساسي",   "#ffffff",            "var(--primary)",           AA_TEXT),
    ("نص الأزرار عند المرور",          "#ffffff",            "var(--primary-dark)",      AA_TEXT),
    ("نص زرار accent",                 "#ffffff",            "var(--accent)",            AA_TEXT),
    ("نص زرار الحذف",                  "#ffffff",            "var(--danger-btn)",        AA_TEXT),
    ("تنبيه نجاح",                     "var(--toast-ink)",   "var(--ok-btn)",            AA_TEXT),
    ("تنبيه خطأ",                      "var(--toast-ink)",   "var(--danger-btn)",        AA_TEXT),
    ("إجمالي الفاتورة (نص كبير)",      "#ffffff",            "var(--primary)",           AA_LARGE),
    ("القائمة الجانبية",               "var(--sidebar-ink)", "var(--sidebar-bg)",        AA_TEXT),
    ("الصفحة المفتوحة في القائمة",     "var(--sidebar-active-ink)", "var(--sidebar-active-bg)", AA_TEXT),
    ("النص الأساسي على الخلفية",       "var(--ink)",         "var(--bg)",                AA_TEXT),
    ("النص الأساسي على البطاقة",       "var(--ink)",         "var(--card)",              AA_TEXT),
    ("عناوين الجدول",                  "var(--ink)",         "var(--surface)",           AA_TEXT),
    ("النص الثانوي",                   "var(--ink-2)",       "var(--card)",              AA_TEXT),
    ("التلميحات الصغيرة",              "var(--ink-3)",       "var(--bg)",                AA_TEXT),
    ("التلميحات على البطاقة",          "var(--ink-3)",       "var(--card)",              AA_TEXT),
    ("سعر الصنف في الاقتراحات",        "var(--primary-text)", "var(--card)",             AA_TEXT),
    ("التبويب المفتوح",                "var(--primary-text)", "var(--bg)",               AA_TEXT),
    ("طريقة الدفع المختارة",           "var(--primary-text)", "var(--primary-soft)",     AA_TEXT),
    ("الباقي للعميل",                  "var(--accent-text)",  "var(--card)",             AA_TEXT),
    ("نص أحمر داخل البطاقة",           "var(--danger)",       "var(--card)",             AA_TEXT),
    ("نص أخضر داخل البطاقة",           "var(--ok)",           "var(--card)",             AA_TEXT),
    ("الاقتراح المميّز",               "var(--ink)",         "var(--primary-soft)",      AA_TEXT),
    ("شارة ناجح",                      "var(--ok)",          "var(--ok-soft)",           AA_TEXT),
    ("شارة تحذير",                     "var(--warn)",        "var(--warn-soft)",         AA_TEXT),
    ("شارة خطر",                       "var(--danger)",      "var(--danger-soft)",       AA_TEXT),
    ("رسالة التنبيه",                  "var(--toast-ink)",   "var(--toast-bg)",          AA_TEXT),
    ("الحقول",                         "var(--ink)",         "var(--card)",              AA_TEXT),
    ("خانة مقفولة",                    "var(--ink-3)",       "var(--surface-2)",         AA_TEXT),
]

THEME_AR = {"olive": "الزيتي", "blue": "الأزرق السماوي", "dark": "الوضع الليلي"}


def main() -> int:
    themes = parse_blocks(CSS.read_text(encoding="utf-8"))
    failed = 0
    for theme in ("olive", "blue", "dark"):
        if theme not in themes:
            print(f"!! ثيم ناقص: {theme}")
            failed += 1
            continue
        print(f"\n=== {THEME_AR[theme]} ({theme}) ===")
        for label, fg, bg, minimum in PAIRS:
            f = resolve(themes, theme, fg)
            b = resolve(themes, theme, bg)
            c = contrast(f, b)
            ok = c >= minimum
            if not ok:
                failed += 1
            mark = "OK  " if ok else "FAIL"
            print(f"  [{mark}] {label:32s} {f} / {b}  = {c:5.2f}  (>= {minimum})")

    print()
    if failed:
        print(f"!! عدد الإخفاقات: {failed}")
        return 1
    print("كل الثيمات عدّت معيار WCAG AA.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
