/**
 * اختبار قراءة باركود الميزان — الأرقام كلها محسوبة بالإيد.
 * التشغيل:  npx tsx scripts/test-scale.ts
 */
import {
  eanCheckDigit,
  parseScaleBarcode,
  scaleQty,
  type ScaleConfig,
} from "../src/lib/scale";

let failed = 0;

function check(label: string, actual: unknown, expected: unknown) {
  const a = JSON.stringify(actual);
  const e = JSON.stringify(expected);
  const ok = a === e;
  if (!ok) failed++;
  console.log(`  [${ok ? "OK  " : "FAIL"}] ${label}\n         الناتج: ${a}\n         المتوقع: ${e}`);
}

const WEIGHT: ScaleConfig = {
  enabled: true,
  prefix: "2",
  pluLen: 6,
  valLen: 5,
  value: "weight",
  divisor: 1000,
};

const PRICE: ScaleConfig = { ...WEIGHT, value: "price", divisor: 100 };

console.log("=== خانة التحقق EAN-13 ===");
// 2 1 2 3 4 5 6 0 1 5 0 0  →  2+3+2+9+4+15+6+0+1+15+0+0 = 57  →  (10-7)%10 = 3
check("212345601500 → 3", eanCheckDigit("212345601500"), 3);
// 2 0 0 0 1 2 3 0 2 5 7 5  →  2+0+0+0+1+6+3+0+2+15+7+15 = 51  →  (10-1)%10 = 9
check("200012302575 → 9", eanCheckDigit("200012302575"), 9);

console.log("\n=== باركود وزن ===");
check("2123456015003 = صنف 123456 وزن 1.5 كجم", parseScaleBarcode("2123456015003", WEIGHT), {
  plu: "123456",
  weight: 1.5,
});
// 2 1 2 3 4 5 6 0 0 2 5 0  →  2+3+2+9+4+15+6+0+0+6+5+0 = 52  →  (10-2)%10 = 8
check("وزن 0.250 كجم", parseScaleBarcode("2123456002508", WEIGHT), {
  plu: "123456",
  weight: 0.25,
});

console.log("\n=== باركود سعر ===");
check("2000123025759 = صنف 000123 بسعر 25.75", parseScaleBarcode("2000123025759", PRICE), {
  plu: "000123",
  price: 25.75,
});

console.log("\n=== حالات لازم تترفض ===");
check("خانة تحقق غلط", parseScaleBarcode("2123456015004", WEIGHT), null);
check("باركود عادي (بيبدأ بـ 6)", parseScaleBarcode("6221031001234", WEIGHT), null);
check("طول غلط", parseScaleBarcode("21234560150", WEIGHT), null);
check("فيه حروف", parseScaleBarcode("2123456A15003", WEIGHT), null);
check("الميزان مقفول", parseScaleBarcode("2123456015003", { ...WEIGHT, enabled: false }), null);

console.log("\n=== الكمية في الفاتورة ===");
check("وزن 1.5 كجم → الكمية 1.5", scaleQty({ plu: "1", weight: 1.5 }, 30), 1.5);
// سعر 25.75 وسعر الكيلو 10.30  →  2.5 كجم بالظبط
check("سعر 25.75 وسعر الكيلو 10.30 → 2.5", scaleQty({ plu: "1", price: 25.75 }, 10.3), 2.5);
// والإجمالي لازم يرجع 25.75
check("الإجمالي بيرجع صح", Math.round(2.5 * 10.3 * 100) / 100, 25.75);

console.log();
if (failed) {
  console.log(`!! عدد الإخفاقات: ${failed}`);
  process.exit(1);
}
console.log("كل اختبارات باركود الميزان نجحت.");
