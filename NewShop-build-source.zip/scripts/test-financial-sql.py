#!/usr/bin/env python3
"""SQLite integration and v1.1 migration tests for NewShop 2.0.0."""

from __future__ import annotations

import sqlite3
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
V1 = (ROOT / "src/db/schema.sql").read_text(encoding="utf-8")
V2 = (ROOT / "src/db/schema_v2.sql").read_text(encoding="utf-8")
V3 = (ROOT / "src/db/schema_v3.sql").read_text(encoding="utf-8")


def eq(label: str, actual, expected) -> None:
    if isinstance(actual, float) or isinstance(expected, float):
        assert abs(float(actual) - float(expected)) < 0.001, (label, actual, expected)
    else:
        assert actual == expected, (label, actual, expected)
    print(f"  [OK] {label}")


def migrate_v11() -> None:
    db = sqlite3.connect(":memory:")
    db.executescript(V1)
    db.executescript(
        """
        INSERT INTO users(username,password_hash,full_name,role,permissions)
          VALUES('owner-old','hash','Old Owner','admin','[]');
        INSERT INTO products(code,name,barcode,unit,cost_price,sell_price,qty)
          VALUES('P1','Product A','111','piece',40,100,100),
                ('P2','Product B','222','piece',60,100,100);
        INSERT INTO customers(name,balance) VALUES('Customer',50);
        INSERT INTO sales(invoice_no,customer_id,user_id,subtotal,discount,total,paid,remaining,payment_type,status)
          VALUES('INV-OLD',1,1,280,28,252,100,152,'mixed','active');
        INSERT INTO sale_items(sale_id,product_id,qty,price,cost_at_sale,discount,total)
          VALUES(1,1,2,100,40,20,180),(1,2,1,100,60,0,100);
        """
    )
    db.executescript(V2)
    db.executescript(V3)
    db.execute("PRAGMA user_version=3")

    eq("v1.1 products preserved", db.execute("SELECT COUNT(*) FROM products").fetchone()[0], 2)
    eq("old admin promoted to owner", db.execute("SELECT role FROM users").fetchone()[0], "owner")
    eq("legacy payment rows reconcile", db.execute("SELECT SUM(amount) FROM sale_payments").fetchone()[0], 252.0)
    allocated = [r[0] for r in db.execute("SELECT allocated_invoice_discount FROM sale_items ORDER BY id")]
    eq("invoice discount allocated", allocated, [18.0, 10.0])
    bases = [round(r[0], 2) for r in db.execute("SELECT effective_unit_net FROM sale_items ORDER BY id")]
    eq("historical refund bases", bases, [81.0, 90.0])
    eq("opening customer ledger", db.execute("SELECT debit-credit FROM party_ledger").fetchone()[0], 50.0)
    eq("migration integrity", db.execute("PRAGMA integrity_check").fetchone()[0], "ok")
    db.close()


def fresh_and_transactions(tmp: Path) -> None:
    path = tmp / "fresh.db"
    db = sqlite3.connect(path)
    db.execute("PRAGMA foreign_keys=ON")
    db.executescript(V1)
    db.executescript(V2)
    db.executescript(V3)
    db.execute("PRAGMA user_version=3")

    eq("fresh database has no production data", db.execute("SELECT COUNT(*) FROM products").fetchone()[0], 0)
    tables = {r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    for name in ("party_ledger", "audit_log", "cash_movements", "suspended_sales", "product_barcodes"):
        assert name in tables, name
    print("  [OK] v2 tables present")

    db.execute("INSERT INTO users(username,password_hash,full_name,role,permissions) VALUES('owner','hash','Owner','owner','[]')")
    db.execute("INSERT INTO customers(name,balance) VALUES('Customer',0)")
    db.execute("INSERT INTO products(code,name,unit,cost_price,sell_price,qty) VALUES('P1','Product','piece',40,100,10)")
    db.execute("INSERT INTO shifts(user_id,opening_cash) VALUES(1,50)")

    # A posted partially-paid sale with stable snapshots and one stock movement.
    db.execute(
        """INSERT INTO sales(invoice_no,customer_id,user_id,subtotal,discount,total,paid,remaining,
                              payment_type,status,shift_id,document_state,gross_total)
             VALUES('INV-1',1,1,200,20,180,80,100,'mixed','active',1,'posted',200)"""
    )
    sale_id = db.execute("SELECT last_insert_rowid()").fetchone()[0]
    db.execute(
        """INSERT INTO sale_items(sale_id,product_id,qty,price,cost_at_sale,discount,total,
                                   product_name_snapshot,code_snapshot,unit_snapshot,original_unit_price,
                                   line_discount,allocated_invoice_discount,effective_unit_net,line_net_total)
             VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (sale_id, 1, 2, 100, 40, 0, 200, "Product", "P1", "piece", 100, 0, 20, 90, 180),
    )
    db.execute("INSERT INTO sale_payments(sale_id,method,amount) VALUES(?,'cash',80)", (sale_id,))
    db.execute("INSERT INTO sale_payments(sale_id,method,amount) VALUES(?,'credit',100)", (sale_id,))
    db.execute("UPDATE products SET qty=qty-2 WHERE id=1")
    db.execute(
        """INSERT INTO stock_moves(product_id,qty_change,type,ref_id,reference_type,reference_id,
                                    qty_before,qty_after,unit_cost,total_value,user_id,shift_id)
             VALUES(1,-2,'sale',?,'sale',?,10,8,40,-80,1,1)""",
        (sale_id, sale_id),
    )
    db.execute("UPDATE customers SET balance=balance+100 WHERE id=1")
    db.execute("INSERT INTO party_ledger(party_type,party_id,entry_type,reference_type,reference_id,document_no,debit,user_id,shift_id) VALUES('customer',1,'sale','sale',?,'INV-1',180,1,1)", (sale_id,))
    db.execute("INSERT INTO party_ledger(party_type,party_id,entry_type,reference_type,reference_id,document_no,credit,method,user_id,shift_id) VALUES('customer',1,'sale_payment','sale',?,'INV-1',80,'cash',1,1)", (sale_id,))
    db.execute("INSERT INTO cash_movements(shift_id,movement_type,direction,amount,method,reference_type,reference_id,user_id) VALUES(1,'cash_sale','in',80,'cash','sale',?,1)", (sale_id,))

    # Partial return: unit basis is 90, and it reduces receivable rather than cash.
    db.execute("INSERT INTO returns(type,ref_id,user_id,total,reason,shift_id,return_no,party_id,settlement_method,status,document_state) VALUES('sale',?,1,90,'partial',1,'SR-1',1,'reduce_receivable','posted','posted')", (sale_id,))
    ret_id = db.execute("SELECT last_insert_rowid()").fetchone()[0]
    item_id = db.execute("SELECT id FROM sale_items WHERE sale_id=?", (sale_id,)).fetchone()[0]
    db.execute("INSERT INTO return_items(return_id,product_id,qty,price,total,source_item_id,unit_refund_basis,cost_at_sale,product_name_snapshot) VALUES(?,1,1,90,90,?,90,40,'Product')", (ret_id, item_id))
    db.execute("UPDATE products SET qty=qty+1 WHERE id=1")
    db.execute("UPDATE customers SET balance=balance-90 WHERE id=1")
    db.execute("INSERT INTO party_ledger(party_type,party_id,entry_type,reference_type,reference_id,document_no,credit,user_id,shift_id) VALUES('customer',1,'sale_return','return',?,'SR-1',90,1,1)", (ret_id,))
    db.execute("INSERT INTO stock_moves(product_id,qty_change,type,ref_id,reference_type,reference_id,qty_before,qty_after,unit_cost,total_value,user_id,shift_id) VALUES(1,1,'return_sale',?,'return',?,8,9,40,40,1,1)", (ret_id, ret_id))
    db.commit()

    eq("sale and partial return stock", db.execute("SELECT qty FROM products WHERE id=1").fetchone()[0], 9.0)
    eq("customer balance reconciles", db.execute("SELECT balance FROM customers WHERE id=1").fetchone()[0], 10.0)
    eq("ledger balance reconciles", db.execute("SELECT SUM(debit-credit) FROM party_ledger WHERE party_type='customer' AND party_id=1").fetchone()[0], 10.0)
    eq("historical return COGS", db.execute("SELECT SUM(qty*cost_at_sale) FROM return_items").fetchone()[0], 40.0)
    eq("cash drawer unaffected by credit settlement", db.execute("SELECT SUM(CASE direction WHEN 'in' THEN amount ELSE -amount END) FROM cash_movements WHERE shift_id=1").fetchone()[0], 80.0)

    try:
        db.execute("UPDATE products SET qty=-1 WHERE id=1")
        raise AssertionError("negative-stock trigger did not fire")
    except sqlite3.IntegrityError:
        print("  [OK] negative stock blocked")
    db.execute("INSERT INTO audit_log(action,reason) VALUES('test','immutable')")
    try:
        db.execute("DELETE FROM audit_log")
        raise AssertionError("audit immutability trigger did not fire")
    except sqlite3.IntegrityError:
        print("  [OK] audit log immutable")
    db.execute("UPDATE shifts SET status='closed', closed_at=datetime('now'), z_report_json='{}' WHERE id=1")
    try:
        db.execute("UPDATE shifts SET counted_cash=999 WHERE id=1")
        raise AssertionError("closed-shift trigger did not fire")
    except sqlite3.IntegrityError:
        print("  [OK] closed Z report immutable")
    db.commit()

    backup = tmp / "backup.db"
    dest = sqlite3.connect(backup)
    db.backup(dest)
    dest.close()
    check = sqlite3.connect(backup)
    eq("backup integrity", check.execute("PRAGMA integrity_check").fetchone()[0], "ok")
    eq("backup preserves sale", check.execute("SELECT COUNT(*) FROM sales").fetchone()[0], 1)
    check.close()
    db.close()


def main() -> None:
    print("=== v1.1 -> v2.0 migration ===")
    migrate_v11()
    print("=== fresh DB and financial transaction integration ===")
    with tempfile.TemporaryDirectory(prefix="newshop-tests-") as d:
        fresh_and_transactions(Path(d))
    print("All SQLite integration tests passed.")


if __name__ == "__main__":
    main()
