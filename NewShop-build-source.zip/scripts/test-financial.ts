import {
  allocateInvoiceDiscount,
  capSplits,
  computeTotals,
  lineTotal,
  round2,
  type CartLine,
} from "../src/lib/sales";
import { buyTotal, newAvgCost, type BuyLine } from "../src/lib/purchases";

let failed = 0;
function check(label: string, actual: unknown, expected: unknown) {
  const ok = JSON.stringify(actual) === JSON.stringify(expected);
  console.log(`  [${ok ? "OK  " : "FAIL"}] ${label}`);
  if (!ok) {
    console.log(`         actual=${JSON.stringify(actual)} expected=${JSON.stringify(expected)}`);
    failed += 1;
  }
}

const lines: CartLine[] = [
  { product_id: 1,code: "A",name: "A",unit: "قطعة",qty: 2,price: 100,cost: 40,discount: 20,stock: 10 },
  { product_id: 2,code: "B",name: "B",unit: "قطعة",qty: 1,price: 100,cost: 60,discount: 0,stock: 10 },
];

console.log("=== NewShop 2 financial invariants ===");
check("line discount is included once", lineTotal(lines[0]), 180);
const allocated = allocateInvoiceDiscount(lines, 28);
check("invoice discount allocation", allocated, [18, 10]);
check("allocated discount reconciles", round2(allocated.reduce((a, b) => a + b, 0)), 28);
check("discounted historical refund basis", [round2((180 - 18) / 2), round2(100 - 10)], [81, 90]);

const totals = computeTotals(lines, 28, 100);
check("sale total", totals.total, 252);
check("partial payment remaining", totals.remaining, 152);
check("historical gross profit", totals.profit, 112);
const taxExclusive = computeTotals(lines, 28, 0, 14, "exclusive");
check("exclusive tax amount", taxExclusive.tax, 35.28);
check("exclusive tax total", taxExclusive.total, 287.28);
check("tax is excluded from profit", taxExclusive.profit, 112);
const taxInclusive = computeTotals(lines, 28, 0, 14, "inclusive");
check("inclusive tax extraction", taxInclusive.tax, 30.95);
check("inclusive price remains total", taxInclusive.total, 252);
check("payment cap", capSplits([{ method: "cash", amount: 200 }, { method: "card", amount: 100 }], 252), [
  { method: "cash", amount: 200 },
  { method: "card", amount: 52 },
]);

const purchase: BuyLine = {
  product_id: 1,code: "A",name: "A",unit: "قطعة",qty: 5,cost: 14,
  old_qty: 10,old_cost: 10,line_discount: 5,
};
check("purchase line discount", buyTotal(purchase), 65);
check("weighted average cost", newAvgCost(10, 10, 5, 14), 11.33);
check("weighted cost with empty old stock", newAvgCost(0, 99, 5, 14), 14);

if (failed) {
  console.log(`\nFAILED: ${failed}`);
  process.exit(1);
}
console.log("All financial invariant tests passed.");
