/**
 * اختبار قارئ الإكسل و CSV — بنولّد ملف بالكاتب اللي عندنا وبنقراه تاني،
 * وبنقارن بملف حقيقي اتعمل بـ openpyxl كمان.
 * التشغيل:  npx tsx scripts/test-xlsxread.ts
 */
import { readFileSync } from "fs";
import { buildXlsx } from "../src/lib/xlsx";
import { readCsv, readXlsx, guessDelimiter, colIndex } from "../src/lib/xlsxread";

let failed = 0;
function check(label: string, actual: unknown, expected: unknown) {
  const a = JSON.stringify(actual);
  const e = JSON.stringify(expected);
  const ok = a === e;
  if (!ok) failed++;
  console.log(`  [${ok ? "OK  " : "FAIL"}] ${label}`);
  if (!ok) console.log(`         الناتج:  ${a}\n         المتوقع: ${e}`);
}

console.log("=== تحويل مرجع الخلية لرقم عمود ===");
check("A → 0", colIndex("A1"), 0);
check("B → 1", colIndex("B7"), 1);
check("Z → 25", colIndex("Z3"), 25);
check("AA → 26", colIndex("AA12"), 26);
check("AB → 27", colIndex("AB1"), 27);

console.log("\n=== CSV ===");
check("سطر بسيط", readCsv("a,b,c\n1,2,3"), [
  ["a", "b", "c"],
  ["1", "2", "3"],
]);
check('خلية فيها فاصلة جوه علامتين تنصيص', readCsv('اسم,سعر\n"شاي, أخضر",25'), [
  ["اسم", "سعر"],
  ["شاي, أخضر", "25"],
]);
check('علامة تنصيص مضاعفة', readCsv('a\n"قال ""أهلا"""'), [["a"], ['قال "أهلا"']]);
check("فاصلة منقوطة", readCsv("a;b\n1;2"), [
  ["a", "b"],
  ["1", "2"],
]);
check("BOM من إكسل", readCsv("﻿الكود,الاسم\nP1,لبن"), [
  ["الكود", "الاسم"],
  ["P1", "لبن"],
]);
check("تخمين الفاصل", guessDelimiter("a;b;c\n1;2;3"), ";");
check("سطور فاضية في الآخر", readCsv("a,b\n1,2\n\n"), [
  ["a", "b"],
  ["1", "2"],
]);

console.log("\n=== xlsx (نكتب ونقرا) ===");
const bytes = buildXlsx([
  {
    name: "الأصناف",
    cols: [
      { key: "code", label: "الكود", width: 14 },
      { key: "name", label: "اسم الصنف", width: 30 },
      { key: "price", label: "السعر", width: 12, type: "number" },
    ],
    rows: [
      { code: "P001", name: "لبن جهينة ١ لتر", price: 32.5 },
      { code: "P002", name: 'شاي "العروسة"', price: 58 },
      { code: "P003", name: "أرز & مكرونة", price: 0 },
    ],
  },
]);
const sheets = readXlsx(bytes);
check("عدد الشيتات", sheets.length, 1);
check("اسم الشيت", sheets[0].name, "الأصناف");
check("صف العناوين", sheets[0].rows[0], ["الكود", "اسم الصنف", "السعر"]);
check("صف فيه علامات تنصيص", sheets[0].rows[2], ["P002", 'شاي "العروسة"', "58"]);
check("صف فيه علامة &", sheets[0].rows[3], ["P003", "أرز & مكرونة", "0"]);

console.log("\n=== xlsx متولّد ببرنامج تاني (openpyxl) ===");
try {
  const real = new Uint8Array(readFileSync("/tmp/openpyxl-sample.xlsx"));
  const s2 = readXlsx(real);
  check("عدد الشيتات", s2.length, 1);
  check("العناوين", s2[0].rows[0], ["الكود", "الاسم", "الكمية"]);
  check("أول صف بيانات", s2[0].rows[1], ["A-1", "صنف عربي", "12.5"]);
  check("صف فيه خانة فاضية في النص", s2[0].rows[2], ["A-2", "", "7"]);
} catch (e) {
  console.log("  (تم تخطّيه — ملف openpyxl مش موجود)", String(e).slice(0, 60));
}

console.log();
if (failed) {
  console.log(`!! عدد الإخفاقات: ${failed}`);
  process.exit(1);
}
console.log("كل اختبارات قراءة الإكسل و CSV نجحت.");
