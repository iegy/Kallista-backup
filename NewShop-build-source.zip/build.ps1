﻿# NewShop 2.0.0 — verified Windows production build
$ErrorActionPreference = "Stop"
[Console]::OutputEncoding = [Text.Encoding]::UTF8
Set-Location $PSScriptRoot

function Step($n, $text) { Write-Host "`n[$n/8] $text" -ForegroundColor Cyan }
function Require($cmd, $help) {
  if (-not (Get-Command $cmd -ErrorAction SilentlyContinue)) { throw "$cmd غير موجود. $help" }
}

Write-Host "========================================================" -ForegroundColor Yellow
Write-Host " NewShop 2.0.0 — تصميم وبرمجة: محمد حسين — iegy.net" -ForegroundColor Yellow
Write-Host "========================================================" -ForegroundColor Yellow

Step 1 "فحص أدوات البناء"
Require node "ثبّت Node.js LTS."
Require npm "يأتي مع Node.js."
Require cargo "ثبّت Rust عبر rustup."
Require rustc "ثبّت Rust عبر rustup."

Step 2 "تثبيت الحزم المقفلة"
npm ci

Step 3 "فحص TypeScript والاختبارات"
npm run typecheck
npm test
Push-Location src-tauri
cargo test --locked
Pop-Location
Push-Location license-tool
cargo test
Pop-Location

Step 4 "بناء تطبيق NewShop وNSIS x64"
npm run tauri:build

Step 5 "بناء License Manager للمالك"
Push-Location license-tool
cargo build --release
Pop-Location

Step 6 "تجميع الملفات النهائية"
$final = Join-Path $PSScriptRoot "FINAL_DELIVERY"
if (Test-Path $final) { Remove-Item $final -Recurse -Force }
New-Item -ItemType Directory -Force -Path $final | Out-Null
New-Item -ItemType Directory -Force -Path (Join-Path $final "OWNER_ONLY_DO_NOT_SHARE") | Out-Null
$ownerKey = Join-Path $PSScriptRoot "OWNER_ONLY_DO_NOT_SHARE\newshop-private.key"
if (-not (Test-Path $ownerKey)) {
  throw "المفتاح الخاص غير موجود في OWNER_ONLY_DO_NOT_SHARE. لا يمكن تسليم أداة تراخيص بلا مفتاح المالك."
}
Copy-Item $ownerKey (Join-Path $final "OWNER_ONLY_DO_NOT_SHARE\newshop-private.key")
Copy-Item "LICENSE-GUIDE-AR.md" (Join-Path $final "OWNER_ONLY_DO_NOT_SHARE\LICENSE-GUIDE-AR.md")

$setup = Get-ChildItem "src-tauri\target\release\bundle\nsis\*-setup.exe" | Select-Object -First 1
if (-not $setup) { throw "لم يتم العثور على NSIS Setup الحقيقي." }
Copy-Item $setup.FullName (Join-Path $final "NewShop-2.0.0-Setup-x64.exe")
Copy-Item "license-tool\target\release\NewShop-License-Manager.exe" (Join-Path $final "OWNER_ONLY_DO_NOT_SHARE\NewShop-License-Manager.exe")

Step 7 "إنشاء Source ZIP وPortable ZIP بدون أسرار"
$stage = Join-Path $env:TEMP "NewShop-2.0.0-Source"
if (Test-Path $stage) { Remove-Item $stage -Recurse -Force }
New-Item -ItemType Directory -Force -Path $stage | Out-Null
$exclude = @("node_modules", "target", "dist", "FINAL_DELIVERY", "release", ".git", "OWNER_ONLY_DO_NOT_SHARE")
Get-ChildItem $PSScriptRoot -Force | Where-Object { $exclude -notcontains $_.Name } | ForEach-Object {
  Copy-Item $_.FullName $stage -Recurse -Force
}
Get-ChildItem $stage -Recurse -Force -File | Where-Object {
  $_.Name -eq "newshop-private.key" -or $_.Name -eq "licenses.csv" -or $_.Extension -eq ".lic"
} | Remove-Item -Force
Compress-Archive -Path (Join-Path $stage "*") -DestinationPath (Join-Path $final "NewShop-2.0.0-Source.zip") -CompressionLevel Optimal
Remove-Item $stage -Recurse -Force

$portable = Join-Path $env:TEMP "NewShop-2.0.0-Portable-x64"
if (Test-Path $portable) { Remove-Item $portable -Recurse -Force }
New-Item -ItemType Directory -Force -Path $portable | Out-Null
Copy-Item "src-tauri\target\release\NewShop.exe" $portable
New-Item -ItemType File -Path (Join-Path $portable "portable.txt") | Out-Null
Compress-Archive -Path (Join-Path $portable "*") -DestinationPath (Join-Path $final "NewShop-2.0.0-Portable-x64.zip") -CompressionLevel Optimal
Remove-Item $portable -Recurse -Force

Step 8 "حساب SHA-256 وفحص عدم تسريب المفتاح"
$important = @("NewShop-2.0.0-Setup-x64.exe", "NewShop-2.0.0-Source.zip", "OWNER_ONLY_DO_NOT_SHARE\NewShop-License-Manager.exe", "NewShop-2.0.0-Portable-x64.zip")
$hashLines = foreach ($name in $important) {
  $h = Get-FileHash (Join-Path $final $name) -Algorithm SHA256
  "$($h.Hash.ToLower())  $name"
}
$hashLines | Set-Content (Join-Path $final "SHA256SUMS.txt") -Encoding ascii
if (Get-ChildItem $final -Recurse -File | Where-Object { $_.Name -eq "newshop-private.key" -and $_.Directory.Name -ne "OWNER_ONLY_DO_NOT_SHARE" }) {
  throw "تم اكتشاف مفتاح خاص خارج مجلد المالك."
}
Write-Host "`nBUILD OK: $final" -ForegroundColor Green
Write-Host "مهم: المفتاح الخاص ملف منفصل للمالك فقط، ولا يُنسخ إلى المثبت أو Source ZIP." -ForegroundColor Yellow
