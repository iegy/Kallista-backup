import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { fileURLToPath } from "node:url";

const r = (p: string) => fileURLToPath(new URL(p, import.meta.url));

// Tauri يعمل على منفذ ثابت
export default defineConfig(({ command }) => ({
  plugins: [react()],
  clearScreen: false,
  resolve: {
    // في نسخة الإنتاج نستبدل ملف المعاينة (sql.js) ببديل فارغ
    alias:
      command === "build"
        ? [{ find: /^\.\/devdb$/, replacement: r("./src/lib/devdb.prod.ts") }]
        : [],
  },
  server: {
    port: 1420,
    strictPort: true,
    watch: { ignored: ["**/src-tauri/**"] },
  },
  build: {
    target: "chrome110",
    outDir: "dist",
    emptyOutDir: true,
    sourcemap: false,
  },
}));
