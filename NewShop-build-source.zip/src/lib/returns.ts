// returns.ts — محرك مرتجعات NewShop 2.0
// المرتجع مستند مستقل، وقيمته مبنية على صافي السعر التاريخي بعد كل الخصومات.
import { batch, query, queryOne, type Op } from "./db";
import { n2 } from "./format";
import { round2 } from "./sales";

export type ReturnType = "sale" | "purchase";
export type SaleSettlement =
  | "cash_refund"
  | "card_refund"
  | "wallet_refund"
  | "bank_refund"
  | "reduce_receivable"
  | "customer_credit";
export type PurchaseSettlement =
  | "reduce_payable"
  | "cash_refund"
  | "card_refund"
  | "wallet_refund"
  | "bank_refund";
export type ReturnSettlement = SaleSettlement | PurchaseSettlement;

export interface ReturnLine {
  source_item_id: number;
  product_id: number;
  name: string;
  unit: string;
  max: number;
  qty: number;
  /** صافي القيمة التاريخية للوحدة، شامل أثر خصمي السطر والفاتورة. */
  price: number;
  cost_at_sale: number;
  current_stock: number;
  allocated_discount: number;
  tax_per_unit: number;
}

/** بنود الفاتورة المتبقية للمرتجع بعد جميع المرتجعات السابقة. */
export async function returnableItems(
  type: ReturnType,
  refId: number
): Promise<ReturnLine[]> {
  const rows =
    type === "sale"
      ? await query<any>(
          `SELECT si.id AS source_item_id,si.product_id,si.qty,
                  CASE WHEN si.effective_unit_net > 0 THEN si.effective_unit_net
                       WHEN si.qty <> 0 THEN si.total / si.qty ELSE si.price END AS price,
                  si.cost_at_sale,
                  CASE WHEN si.qty<>0 THEN si.tax_amount/si.qty ELSE 0 END AS tax_per_unit,
                  (si.line_discount + si.allocated_invoice_discount) AS allocated_discount,
                  COALESCE(si.product_name_snapshot,p.name,'صنف محذوف') AS name,
                  COALESCE(si.unit_snapshot,p.unit,'') AS unit,COALESCE(p.qty,0) AS current_stock,
                  COALESCE((SELECT SUM(ri.qty) FROM return_items ri
                    JOIN returns r ON r.id=ri.return_id
                   WHERE r.type='sale' AND r.ref_id=si.sale_id AND r.status='posted'
                     AND (ri.source_item_id=si.id OR
                          (ri.source_item_id IS NULL AND ri.product_id=si.product_id))),0) AS returned
             FROM sale_items si LEFT JOIN products p ON p.id=si.product_id
            WHERE si.sale_id=? AND si.product_id IS NOT NULL ORDER BY si.id`,
          [refId]
        )
      : await query<any>(
          `SELECT pi.id AS source_item_id,pi.product_id,pi.qty,
                  CASE WHEN pi.qty <> 0
                       THEN MAX(0,pi.total-pi.allocated_invoice_discount)/pi.qty
                       ELSE pi.cost END AS price,
                  0 AS cost_at_sale,
                  0 AS tax_per_unit,
                  (pi.line_discount + pi.allocated_invoice_discount) AS allocated_discount,
                  COALESCE(pi.product_name_snapshot,p.name,'صنف محذوف') AS name,
                  COALESCE(p.unit,'') AS unit,COALESCE(p.qty,0) AS current_stock,
                  COALESCE((SELECT SUM(ri.qty) FROM return_items ri
                    JOIN returns r ON r.id=ri.return_id
                   WHERE r.type='purchase' AND r.ref_id=pi.purchase_id AND r.status='posted'
                     AND (ri.source_item_id=pi.id OR
                          (ri.source_item_id IS NULL AND ri.product_id=pi.product_id))),0) AS returned
             FROM purchase_items pi LEFT JOIN products p ON p.id=pi.product_id
            WHERE pi.purchase_id=? AND pi.product_id IS NOT NULL ORDER BY pi.id`,
          [refId]
        );

  return rows
    .map((r) => ({
      source_item_id: Number(r.source_item_id),
      product_id: Number(r.product_id),
      name: String(r.name),
      unit: String(r.unit || ""),
      max: round2(n2(r.qty) - n2(r.returned)),
      qty: 0,
      price: round2(n2(r.price)),
      cost_at_sale: round2(n2(r.cost_at_sale)),
      current_stock: n2(r.current_stock),
      allocated_discount: round2(n2(r.allocated_discount)),
      tax_per_unit: round2(n2(r.tax_per_unit)),
    }))
    .filter((r) => r.max > 0);
}

export interface ReturnPayload {
  type: ReturnType;
  refId: number;
  refNo: string;
  partyId: number | null;
  lines: ReturnLine[];
  reason: string;
  settlementMethod: ReturnSettlement;
  userId?: number | null;
  shiftId?: number | null;
  approvedBy?: number | null;
}

export async function saveReturn(p: ReturnPayload): Promise<{ id: number; total: number }> {
  const lines = p.lines.filter((l) => n2(l.qty) > 0);
  if (!lines.length) throw new Error("لا توجد أصناف محددة للمرتجع");
  if (!p.reason.trim()) throw new Error("سبب المرتجع مطلوب");

  const saleMethods: ReturnSettlement[] = [
    "cash_refund", "card_refund", "wallet_refund", "bank_refund",
    "reduce_receivable", "customer_credit",
  ];
  const purchaseMethods: ReturnSettlement[] = [
    "reduce_payable", "cash_refund", "card_refund", "wallet_refund", "bank_refund",
  ];
  if (!(p.type === "sale" ? saleMethods : purchaseMethods).includes(p.settlementMethod))
    throw new Error("طريقة تسوية المرتجع لا تناسب نوع المستند");

  const source = await queryOne<{ document_state: string; status: string; party_id: number | null }>(
    p.type === "sale"
      ? `SELECT document_state,status,customer_id AS party_id FROM sales WHERE id=?`
      : `SELECT document_state,status,supplier_id AS party_id FROM purchases WHERE id=?`,
    [p.refId]
  );
  if (!source) throw new Error("الفاتورة الأصلية غير موجودة");
  if (source.document_state === "void" || source.status === "cancelled")
    throw new Error("لا يمكن إنشاء مرتجع لفاتورة ملغاة");
  const partyId = source.party_id;
  if (["reduce_receivable", "customer_credit", "reduce_payable"].includes(p.settlementMethod) && !partyId)
    throw new Error("لا يمكن تسوية المرتجع على الحساب بدون عميل أو مورد في الفاتورة الأصلية");

  // إعادة القراءة تمنع تجاوز الكمية بسبب نافذتين مفتوحتين أو مرتجع سابق.
  const fresh = await returnableItems(p.type, p.refId);
  for (const line of lines) {
    const allowed = fresh.find((x) => x.source_item_id === line.source_item_id);
    if (!allowed || n2(line.qty) > n2(allowed.max) + 0.000001)
      throw new Error(`الكمية المسموح بمرتجعها من «${line.name}» تغيّرت؛ أعد فتح الفاتورة`);
    if (p.type === "purchase" && n2(line.qty) > n2(allowed.current_stock) + 0.000001)
      throw new Error(
        `لا يمكن عمل مرتجع شراء لـ«${line.name}»: المتاح بالمخزون ${allowed.current_stock} فقط`
      );
    line.price = allowed.price;
    line.cost_at_sale = allowed.cost_at_sale;
    line.current_stock = allowed.current_stock;
  }

  const total = round2(lines.reduce((s, l) => s + n2(l.qty) * n2(l.price), 0));
  const uid = p.userId ?? null;
  const shiftId = p.shiftId ?? null;
  const isSale = p.type === "sale";
  const returnNo = `${isSale ? "SR" : "PR"}-${Date.now().toString().slice(-10)}`;
  const ops: Op[] = [
    {
      sql: `INSERT INTO returns(type,ref_id,user_id,total,reason,shift_id,return_no,party_id,
              settlement_method,status,approved_by,document_state)
            VALUES(?,?,?,?,?,?,?,?,?,'posted',?,'posted')`,
      params: [
        p.type,
        p.refId,
        uid,
        total,
        p.reason.trim(),
        shiftId,
        returnNo,
        partyId,
        p.settlementMethod,
        p.approvedBy ?? null,
      ],
    },
  ];

  for (const line of lines) {
    const lineTotal = round2(n2(line.qty) * n2(line.price));
    const delta = isSale ? n2(line.qty) : -n2(line.qty);
    ops.push({
      sql: `INSERT INTO return_items(return_id,product_id,qty,price,total,source_item_id,
              unit_refund_basis,allocated_discount,cost_at_sale,tax_amount,product_name_snapshot)
            VALUES(?,?,?,?,?,?,?,?,?,?,?)`,
      params: [
        "$LAST_ID:0",
        line.product_id,
        line.qty,
        line.price,
        lineTotal,
        line.source_item_id,
        line.price,
        line.allocated_discount,
        line.cost_at_sale,
        round2(n2(line.qty) * n2(line.tax_per_unit)),
        line.name,
      ],
    });
    ops.push({
      sql: `INSERT INTO stock_moves(product_id,qty_change,type,ref_id,note,user_id,
              reference_type,reference_id,qty_before,qty_after,unit_cost,total_value,shift_id)
            SELECT id,?,?,?,?,?,'return',?,qty,qty+?,cost_price,?*cost_price,?
              FROM products WHERE id=?`,
      params: [
        delta,
        isSale ? "return_sale" : "return_purchase",
        "$LAST_ID:0",
        `${isSale ? "مرتجع بيع" : "مرتجع شراء"} — ${p.refNo}`,
        uid,
        "$LAST_ID:0",
        delta,
        delta,
        shiftId,
        line.product_id,
      ],
    });
    ops.push({
      sql: `UPDATE products SET qty=qty+? WHERE id=?`,
      params: [delta, line.product_id],
    });
  }

  if (isSale) {
    if (partyId && ["reduce_receivable", "customer_credit"].includes(p.settlementMethod)) {
      ops.push({
        sql: `UPDATE customers SET balance=balance-? WHERE id=?`,
        params: [total, partyId],
      });
      ops.push({
        sql: `INSERT INTO party_ledger(party_type,party_id,entry_type,reference_type,
                reference_id,document_no,credit,method,user_id,shift_id,note)
              VALUES('customer',?,'sale_return','return',?,?,?, ?,?,?,?)`,
        params: [
          partyId,
          "$LAST_ID:0",
          returnNo,
          total,
          p.settlementMethod,
          uid,
          shiftId,
          p.reason.trim(),
        ],
      });
    }
    const method = p.settlementMethod.replace("_refund", "");
    if (p.settlementMethod.endsWith("_refund")) {
      if (partyId) {
        ops.push({
          sql: `INSERT INTO party_ledger(party_type,party_id,entry_type,reference_type,
                  reference_id,document_no,credit,method,user_id,shift_id,note)
                VALUES('customer',?,'sale_return','return',?,?,?, ?,?,?,?)`,
          params: [partyId,"$LAST_ID:0",returnNo,total,p.settlementMethod,uid,shiftId,p.reason.trim()],
        });
        ops.push({
          sql: `INSERT INTO party_ledger(party_type,party_id,entry_type,reference_type,
                  reference_id,document_no,debit,method,user_id,shift_id,note)
                VALUES('customer',?,'return_refund','return',?,?,?, ?,?,?,?)`,
          params: [partyId,"$LAST_ID:0",returnNo,total,method,uid,shiftId,`رد قيمة ${returnNo}`],
        });
      }
      ops.push({
        sql: `INSERT INTO payments(party_type,party_id,amount,direction,method,note,user_id,
                shift_id,source,document_no,reference_type,reference_id)
              VALUES('customer',? ,?,'out',?,?,?,?, 'return',?,'return',?)`,
        params: [partyId, total, method, p.reason.trim(), uid, shiftId, returnNo, "$LAST_ID:0"],
      });
      if (shiftId && method === "cash") {
        ops.push({
          sql: `INSERT INTO cash_movements(shift_id,movement_type,direction,amount,method,
                  reference_type,reference_id,user_id,note)
                VALUES(?,'cash_refund','out',?,'cash','return',?,?,?)`,
          params: [shiftId, total, "$LAST_ID:0", uid, p.reason.trim()],
        });
      }
    }
    ops.push({
      sql: `UPDATE sales SET document_state=CASE
              WHEN NOT EXISTS(
                SELECT 1 FROM sale_items si
                 WHERE si.sale_id=? AND si.qty > COALESCE((
                   SELECT SUM(ri.qty) FROM return_items ri JOIN returns r ON r.id=ri.return_id
                    WHERE r.type='sale' AND r.ref_id=? AND r.status='posted'
                      AND (ri.source_item_id=si.id OR
                           (ri.source_item_id IS NULL AND ri.product_id=si.product_id))
                 ),0)
              ) THEN 'returned' ELSE 'partially_returned' END,
              status=CASE WHEN NOT EXISTS(
                SELECT 1 FROM sale_items si
                 WHERE si.sale_id=? AND si.qty > COALESCE((
                   SELECT SUM(ri.qty) FROM return_items ri JOIN returns r ON r.id=ri.return_id
                    WHERE r.type='sale' AND r.ref_id=? AND r.status='posted'
                      AND (ri.source_item_id=si.id OR
                           (ri.source_item_id IS NULL AND ri.product_id=si.product_id))
                 ),0)
              ) THEN 'returned' ELSE status END
            WHERE id=?`,
      params: [p.refId, p.refId, p.refId, p.refId, p.refId],
    });
  } else {
    if (partyId && p.settlementMethod === "reduce_payable") {
      ops.push({
        sql: `UPDATE suppliers SET balance=balance-? WHERE id=?`,
        params: [total, partyId],
      });
      ops.push({
        sql: `INSERT INTO party_ledger(party_type,party_id,entry_type,reference_type,
                reference_id,document_no,credit,method,user_id,shift_id,note)
              VALUES('supplier',?,'purchase_return','return',?,?,?,'reduce_payable',?,?,?)`,
        params: [partyId, "$LAST_ID:0", returnNo, total, uid, shiftId, p.reason.trim()],
      });
    }
    if (p.settlementMethod.endsWith("_refund")) {
      const method = p.settlementMethod.replace("_refund", "");
      if (partyId) {
        ops.push({
          sql: `INSERT INTO party_ledger(party_type,party_id,entry_type,reference_type,
                  reference_id,document_no,credit,method,user_id,shift_id,note)
                VALUES('supplier',?,'purchase_return','return',?,?,?, ?,?,?,?)`,
          params: [partyId,"$LAST_ID:0",returnNo,total,p.settlementMethod,uid,shiftId,p.reason.trim()],
        });
        ops.push({
          sql: `INSERT INTO party_ledger(party_type,party_id,entry_type,reference_type,
                  reference_id,document_no,debit,method,user_id,shift_id,note)
                VALUES('supplier',?,'supplier_refund','return',?,?,?, ?,?,?,?)`,
          params: [partyId,"$LAST_ID:0",returnNo,total,method,uid,shiftId,`استرداد من المورد ${returnNo}`],
        });
        ops.push({
          sql: `INSERT INTO payments(party_type,party_id,amount,direction,method,note,user_id,
                  shift_id,source,document_no,reference_type,reference_id)
                VALUES('supplier',?,?,'in',?,?,?,?, 'return',?,'return',?)`,
          params: [partyId,total,method,p.reason.trim(),uid,shiftId,returnNo,"$LAST_ID:0"],
        });
      }
      if (shiftId && method === "cash") {
        ops.push({
          sql: `INSERT INTO cash_movements(shift_id,movement_type,direction,amount,method,
                  reference_type,reference_id,user_id,note)
                VALUES(?,'purchase_refund','in',?,'cash','return',?,?,?)`,
          params: [shiftId, total, "$LAST_ID:0", uid, p.reason.trim()],
        });
      }
    }
  }

  ops.push({
    sql: `INSERT INTO audit_log(user_id,override_user_id,action,entity_type,entity_id,
            new_values,reason)
          VALUES(?,?,?,'return',?,?,?)`,
    params: [
      uid,
      p.approvedBy ?? null,
      isSale ? "sale_return_posted" : "purchase_return_posted",
      "$LAST_ID:0",
      JSON.stringify({ return_no: returnNo, source_id: p.refId, total }),
      p.reason.trim(),
    ],
  });

  const ids = await batch(ops, isSale ? "sales_return" : "purchase_return");
  return { id: ids[0], total };
}

export async function returnSummary(returnId: number) {
  return queryOne(
    `SELECT r.*,COALESCE(c.name,s.name) AS party_name,u.full_name AS user_name
       FROM returns r
       LEFT JOIN customers c ON r.type='sale' AND c.id=r.party_id
       LEFT JOIN suppliers s ON r.type='purchase' AND s.id=r.party_id
       LEFT JOIN users u ON u.id=r.user_id
      WHERE r.id=?`,
    [returnId]
  );
}
