// purchases.ts — فاتورة الشراء + تحديث متوسط التكلفة المرجح
import { batch, query, queryOne, type Op } from "./db";
import { n2 } from "./format";
import { round2 } from "./sales";

export interface BuyLine {
  product_id: number;
  code: string;
  name: string;
  unit: string;
  qty: number;
  cost: number;
  old_qty: number;
  old_cost: number;
  line_discount?: number;
}

export const buyTotal = (l: BuyLine) =>
  Math.max(0, n2(l.qty) * n2(l.cost) - n2(l.line_discount));

/**
 * متوسط التكلفة المرجح الجديد:
 * (الكمية_القديمة × التكلفة_القديمة + الكمية_المشتراة × سعر_الشراء) ÷ (الكمية_القديمة + الكمية_المشتراة)
 * لو الرصيد القديم صفر أو سالب، بناخد سعر الشراء زي ما هو.
 */
export function newAvgCost(
  oldQty: number,
  oldCost: number,
  buyQty: number,
  buyCost: number
): number {
  const oq = Math.max(0, n2(oldQty));
  const denom = oq + n2(buyQty);
  if (denom <= 0) return round2(buyCost);
  return round2((oq * n2(oldCost) + n2(buyQty) * n2(buyCost)) / denom);
}

/** نفس المعادلة داخل SQL — بتتحسب من القيم القديمة قبل تعديل الكمية */
const AVG_COST_SQL = `
UPDATE products
   SET cost_price = CASE
         WHEN (MAX(qty, 0) + ?) > 0
           THEN (MAX(qty, 0) * cost_price + ? * ?) / (MAX(qty, 0) + ?)
         ELSE ?
       END,
       qty = qty + ?
 WHERE id = ?`;

/** رقم داخلي متسلسل لفاتورة الشراء لو المورد مالوش رقم فاتورة */
export async function nextPurchaseNo(): Promise<string> {
  const [r] = await query<{ n: number }>(`SELECT COUNT(*) AS n FROM purchases`);
  return `PUR-${String(Number(r?.n || 0) + 1).padStart(4, "0")}`;
}

export interface PurchasePayload {
  lines: BuyLine[];
  supplierId: number | null;
  invoiceNo: string;
  discount: number;
  paid: number;
  notes?: string;
  userId?: number | null;
  shiftId?: number | null;
  dueDate?: string | null;
  paymentMethod?: "cash" | "card" | "wallet" | "bank";
  additionalCosts?: number;
  landedCostMethod?: "value" | "quantity";
}

export async function savePurchase(
  p: PurchasePayload
): Promise<{ id: number; total: number; remaining: number }> {
  if (!p.lines.length) throw new Error("فاتورة الشراء فاضية");
  if (!p.supplierId) throw new Error("لازم تختار المورد");
  if (n2(p.discount) < 0 || n2(p.paid) < 0 || n2(p.additionalCosts) < 0)
    throw new Error("الخصم أو المدفوع أو المصروفات الإضافية لا يمكن أن تكون سالبة");
  for (const line of p.lines) {
    if (!Number.isInteger(Number(line.product_id)) || Number(line.product_id) <= 0)
      throw new Error("يوجد صنف غير صالح في فاتورة الشراء");
    if (n2(line.qty) <= 0) throw new Error(`كمية «${line.name}» يجب أن تكون أكبر من صفر`);
    if (n2(line.cost) < 0 || n2(line.line_discount) < 0)
      throw new Error(`التكلفة أو الخصم غير صالح للصنف «${line.name}»`);
    if (n2(line.line_discount) > n2(line.qty) * n2(line.cost))
      throw new Error(`خصم «${line.name}» أكبر من قيمة السطر`);
  }

  const subtotal = round2(p.lines.reduce((s, l) => s + buyTotal(l), 0));
  const discount = Math.min(n2(p.discount), subtotal);
  const additionalCosts = Math.max(0, n2(p.additionalCosts));
  const total = round2(subtotal - discount + additionalCosts);
  const paid = Math.min(n2(p.paid), total);
  const remaining = round2(total - paid);
  const uid = p.userId ?? null;
  const inv = p.invoiceNo.trim() || (await nextPurchaseNo());
  const landedMethod = p.landedCostMethod === "quantity" ? "quantity" : "value";
  const invoiceAllocated: number[] = [];
  const landedAllocated: number[] = [];
  let usedDiscount = 0;
  let usedLanded = 0;
  const totalQty = p.lines.reduce((s, l) => s + n2(l.qty), 0);
  for (let i = 0; i < p.lines.length; i += 1) {
    const base = buyTotal(p.lines[i]);
    const disc =
      i === p.lines.length - 1
        ? round2(discount - usedDiscount)
        : round2(subtotal > 0 ? (discount * base) / subtotal : 0);
    usedDiscount = round2(usedDiscount + disc);
    invoiceAllocated.push(disc);
    const landedWeight = landedMethod === "quantity" ? n2(p.lines[i].qty) : base;
    const landedDenom = landedMethod === "quantity" ? totalQty : subtotal;
    const landed =
      i === p.lines.length - 1
        ? round2(additionalCosts - usedLanded)
        : round2(landedDenom > 0 ? (additionalCosts * landedWeight) / landedDenom : 0);
    usedLanded = round2(usedLanded + landed);
    landedAllocated.push(landed);
  }

  const ops: Op[] = [
    {
      sql: `INSERT INTO purchases(invoice_no,supplier_id,user_id,subtotal,discount,total,
              paid,remaining,status,notes,due_date,payment_status,payment_method,
              additional_costs,landed_cost_method,document_state)
            VALUES(?,?,?,?,?,?,?,?, 'active',?,?,?,?,?,?,'posted')`,
      params: [
        inv,
        p.supplierId,
        uid,
        subtotal,
        discount,
        total,
        paid,
        remaining,
        p.notes || null,
        p.dueDate ?? null,
        remaining <= 0 ? "paid" : paid > 0 ? "partial" : "unpaid",
        p.paymentMethod ?? "cash",
        additionalCosts,
        landedMethod,
      ],
    },
  ];

  for (let i = 0; i < p.lines.length; i += 1) {
    const l = p.lines[i];
    const lineNet = round2(buyTotal(l) - invoiceAllocated[i] + landedAllocated[i]);
    const effectiveCost = l.qty ? round2(lineNet / n2(l.qty)) : n2(l.cost);
    ops.push({
      sql: `INSERT INTO purchase_items(purchase_id,product_id,qty,cost,total,
              product_name_snapshot,code_snapshot,line_discount,allocated_invoice_discount,
              allocated_landed_cost,effective_unit_cost)
            VALUES(?,?,?,?,?,?,?,?,?,?,?)`,
      params: [
        "$LAST_ID:0",
        l.product_id,
        l.qty,
        l.cost,
        buyTotal(l),
        l.name,
        l.code,
        n2(l.line_discount),
        invoiceAllocated[i],
        landedAllocated[i],
        effectiveCost,
      ],
    });
    ops.push({
      sql: `INSERT INTO stock_moves(product_id,qty_change,type,ref_id,note,user_id,
              reference_type,reference_id,qty_before,qty_after,unit_cost,total_value,shift_id)
            SELECT id,?,'purchase',?,?,?,'purchase',?,qty,qty+?, ?,?*?,?
              FROM products WHERE id=?`,
      params: [
        l.qty,
        "$LAST_ID:0",
        `فاتورة شراء ${inv}`,
        uid,
        "$LAST_ID:0",
        l.qty,
        effectiveCost,
        l.qty,
        effectiveCost,
        p.shiftId ?? null,
        l.product_id,
      ],
    });
    ops.push({
      sql: AVG_COST_SQL,
      params: [
        l.qty,
        l.qty,
        effectiveCost,
        l.qty,
        effectiveCost,
        l.qty,
        l.product_id,
      ],
    });
  }

  ops.push({
    sql: `INSERT INTO party_ledger(party_type,party_id,entry_type,reference_type,
            reference_id,document_no,debit,user_id,shift_id,note)
          VALUES('supplier',?,'purchase','purchase',?,?,?, ?,?,?)`,
    params: [p.supplierId, "$LAST_ID:0", inv, total, uid, p.shiftId ?? null, `فاتورة شراء ${inv}`],
  });

  if (remaining > 0) {
    ops.push({
      sql: `UPDATE suppliers SET balance = balance + ? WHERE id = ?`,
      params: [remaining, p.supplierId],
    });
  }
  if (paid > 0) {
    ops.push({
      sql: `INSERT INTO payments(party_type, party_id, amount, direction, method, note,
              user_id,shift_id,document_no,reference_type,reference_id)
            VALUES('supplier', ?, ?, 'out', ?, ?, ?, ?,?,'purchase',?)`,
      params: [
        p.supplierId,
        paid,
        p.paymentMethod ?? "cash",
        `دفعة مع فاتورة شراء ${inv}`,
        uid,
        p.shiftId ?? null,
        inv,
        "$LAST_ID:0",
      ],
    });
    ops.push({
      sql: `INSERT INTO party_ledger(party_type,party_id,entry_type,reference_type,
              reference_id,document_no,credit,method,user_id,shift_id,note)
            VALUES('supplier',?,'supplier_payment','purchase',?,?,?, ?,?,?,?)`,
      params: [
        p.supplierId,
        "$LAST_ID:0",
        inv,
        paid,
        p.paymentMethod ?? "cash",
        uid,
        p.shiftId ?? null,
        `دفعة على فاتورة ${inv}`,
      ],
    });
    if (p.shiftId && (p.paymentMethod ?? "cash") === "cash") {
      ops.push({
        sql: `INSERT INTO cash_movements(shift_id,movement_type,direction,amount,method,
                reference_type,reference_id,user_id,note)
              VALUES(?,'supplier_payment','out',?,'cash','purchase',?,?,?)`,
        params: [p.shiftId, paid, "$LAST_ID:0", uid, `فاتورة شراء ${inv}`],
      });
    }
  }

  ops.push({
    sql: `INSERT INTO audit_log(user_id,action,entity_type,entity_id,new_values)
          VALUES(?,'purchase_posted','purchase',?,?)`,
    params: [uid, "$LAST_ID:0", JSON.stringify({ invoice_no: inv, total, additionalCosts })],
  });

  const ids = await batch(ops, "purchases");
  return { id: ids[0], total, remaining };
}

export interface PurchaseHead {
  id: number;
  invoice_no: string;
  date: string;
  subtotal: number;
  discount: number;
  total: number;
  paid: number;
  remaining: number;
  status: string;
  notes: string | null;
  supplier_id: number | null;
  supplier_name: string | null;
}

export interface PurchaseLine {
  id: number;
  product_id: number | null;
  name: string;
  unit: string;
  qty: number;
  cost: number;
  total: number;
}

export async function getPurchase(id: number) {
  const head = await queryOne<PurchaseHead>(
    `SELECT p.*, s.name AS supplier_name FROM purchases p
       LEFT JOIN suppliers s ON s.id = p.supplier_id WHERE p.id = ?`,
    [id]
  );
  if (!head) return null;
  const lines = await query<PurchaseLine>(
    `SELECT pi.id, pi.product_id, pi.qty, pi.cost, pi.total,
            COALESCE(pr.name,'صنف محذوف') AS name, COALESCE(pr.unit,'') AS unit
       FROM purchase_items pi LEFT JOIN products pr ON pr.id = pi.product_id
      WHERE pi.purchase_id = ? ORDER BY pi.id`,
    [id]
  );
  return { head, lines };
}
