// scale.ts — قراءة باركود ميزان السوبرماركت
//
// الميزان بيطبع باركود EAN-13 جوّاه كود الصنف والوزن (أو السعر):
//
//     2   123456   01500   8
//     │      │        │    └── خانة التحقق
//     │      │        └─────── القيمة (١٫٥٠٠ كجم أو ١٥٫٠٠ جنيه)
//     │      └──────────────── كود الصنف على الميزان (PLU)
//     └─────────────────────── البادئة اللي بتقول "ده باركود ميزان"
//
// الصيغة بتختلف من ميزان للتاني، فكل الأطوال قابلة للتعديل من الإعدادات.

export interface ScaleConfig {
  enabled: boolean;
  /** البادئة اللي بيبدأ بيها باركود الميزان (حرف أو حرفين عادة) */
  prefix: string;
  /** عدد خانات كود الصنف */
  pluLen: number;
  /** عدد خانات القيمة */
  valLen: number;
  /** القيمة اللي جوه الباركود: وزن ولا سعر */
  value: "weight" | "price";
  /** المقسوم عليه: ١٠٠٠ يعني جرام→كيلو، ١٠٠ يعني قرش→جنيه */
  divisor: number;
}

export const DEFAULT_SCALE: ScaleConfig = {
  enabled: false,
  prefix: "2",
  pluLen: 6,
  valLen: 5,
  value: "weight",
  divisor: 1000,
};

/** بيقرأ الإعدادات من جدول settings */
export function scaleConfig(s: Record<string, string>): ScaleConfig {
  const num = (k: string, d: number) => {
    const v = Number(s[k]);
    return Number.isFinite(v) && v > 0 ? v : d;
  };
  return {
    enabled: s.scale_enabled === "1",
    prefix: (s.scale_prefix || "2").trim(),
    pluLen: num("scale_plu_len", DEFAULT_SCALE.pluLen),
    valLen: num("scale_val_len", DEFAULT_SCALE.valLen),
    value: s.scale_value === "price" ? "price" : "weight",
    divisor: num("scale_divisor", DEFAULT_SCALE.divisor),
  };
}

/** خانة التحقق في EAN-13 / EAN-8: مجموع مرجّح ٣ و ١ */
export function eanCheckDigit(digits: string): number {
  let sum = 0;
  // بنعدّ من الآخر: أول رقم من الشمال وزنه ٣
  for (let i = digits.length - 1, w = 3; i >= 0; i--, w = w === 3 ? 1 : 3) {
    sum += Number(digits[i]) * w;
  }
  return (10 - (sum % 10)) % 10;
}

export interface ScaleRead {
  /** كود الصنف على الميزان */
  plu: string;
  /** الوزن بالكيلو — موجود لو الباركود وزن */
  weight?: number;
  /** السعر الإجمالي — موجود لو الباركود سعر */
  price?: number;
}

/**
 * بيحاول يقرأ الكود كباركود ميزان. بيرجّع null لو مش باركود ميزان
 * أو لو خانة التحقق غلط (عشان مانخلطش بينه وبين باركود عادي).
 */
export function parseScaleBarcode(
  raw: string,
  cfg: ScaleConfig
): ScaleRead | null {
  if (!cfg.enabled) return null;

  const code = raw.trim();
  const expected = cfg.prefix.length + cfg.pluLen + cfg.valLen + 1;
  if (code.length !== expected) return null;
  if (!/^\d+$/.test(code)) return null;
  if (!code.startsWith(cfg.prefix)) return null;

  // خانة التحقق لازم تكون مظبوطة — ده اللي بيمنع القراءة الغلط
  const body = code.slice(0, -1);
  if (eanCheckDigit(body) !== Number(code[code.length - 1])) return null;

  const plu = code.slice(cfg.prefix.length, cfg.prefix.length + cfg.pluLen);
  const rawVal = Number(
    code.slice(cfg.prefix.length + cfg.pluLen, cfg.prefix.length + cfg.pluLen + cfg.valLen)
  );
  const val = rawVal / cfg.divisor;

  return cfg.value === "price" ? { plu, price: val } : { plu, weight: val };
}

/**
 * الكمية اللي تتحط في الفاتورة.
 * لو الباركود فيه سعر، بنقسّمه على سعر البيع عشان الإجمالي يطلع مظبوط.
 */
export function scaleQty(read: ScaleRead, sellPrice: number): number {
  if (read.weight !== undefined) return round3(read.weight);
  if (read.price !== undefined && sellPrice > 0)
    return round3(read.price / sellPrice);
  return 0;
}

const round3 = (x: number) => Math.round((x + Number.EPSILON) * 1000) / 1000;
