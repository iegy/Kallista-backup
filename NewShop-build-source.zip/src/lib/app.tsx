// app.tsx — حالة عامة: الإعدادات + التنبيهات
import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useState,
  type ReactNode,
} from "react";
import { execute, query } from "./db";
import { openShift, type Shift } from "./shifts";

export type Settings = Record<string, string>;

/** الثيمات المتاحة — القيمة بتتخزن في جدول الإعدادات تحت المفتاح theme */
export const THEMES = [
  { key: "olive", label: "زيتي", swatch: "#66734f" },
  { key: "blue", label: "أزرق سماوي", swatch: "#35789b" },
  { key: "dark", label: "وضع ليلي", swatch: "#1b2129" },
] as const;

export type ThemeKey = (typeof THEMES)[number]["key"];

export function isTheme(v: string): v is ThemeKey {
  return THEMES.some((t) => t.key === v);
}

interface Toast {
  id: number;
  msg: string;
  kind: "ok" | "err" | "info";
}

interface Ctx {
  settings: Settings;
  ready: boolean;
  reloadSettings: () => Promise<void>;
  saveSettings: (patch: Settings) => Promise<void>;
  toast: (msg: string, kind?: Toast["kind"]) => void;
  currency: string;
  theme: ThemeKey;
  setTheme: (t: ThemeKey) => Promise<void>;
  /** الوردية المفتوحة حاليًا — null يعني مفيش وردية */
  shift: Shift | null;
  reloadShift: () => Promise<void>;
}

const AppCtx = createContext<Ctx | null>(null);

export function useApp(): Ctx {
  const c = useContext(AppCtx);
  if (!c) throw new Error("useApp خارج AppProvider");
  return c;
}

export function AppProvider({ children }: { children: ReactNode }) {
  const [settings, setSettings] = useState<Settings>({});
  const [ready, setReady] = useState(false);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [shift, setShift] = useState<Shift | null>(null);

  const reloadSettings = useCallback(async () => {
    const rows = await query<{ key: string; value: string }>(
      "SELECT key, value FROM settings"
    );
    const o: Settings = {};
    for (const r of rows) o[r.key] = r.value ?? "";
    setSettings(o);
  }, []);

  const reloadShift = useCallback(async () => {
    setShift(await openShift());
  }, []);

  const toast = useCallback((msg: string, kind: Toast["kind"] = "ok") => {
    const id = Date.now() + Math.random();
    setToasts((t) => [...t, { id, msg, kind }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 3200);
  }, []);

  const saveSettings = useCallback(
    async (patch: Settings) => {
      for (const [k, v] of Object.entries(patch)) {
        await execute(
          "INSERT INTO settings(key,value) VALUES(?,?) " +
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
          [k, v]
        );
      }
      await reloadSettings();
    },
    [reloadSettings]
  );

  useEffect(() => {
    reloadSettings()
      .catch((e) => toast(String(e), "err"))
      .finally(() => setReady(true));
    reloadShift().catch(() => setShift(null));
  }, [reloadSettings, reloadShift, toast]);

  const theme: ThemeKey = isTheme(settings.theme || "")
    ? (settings.theme as ThemeKey)
    : "olive";

  // تطبيق الثيم على عنصر <html> — كل ألوان البرنامج متغيّرات CSS
  useEffect(() => {
    document.documentElement.dataset.theme = theme;
  }, [theme]);

  const setTheme = useCallback(
    (t: ThemeKey) => saveSettings({ theme: t }),
    [saveSettings]
  );

  return (
    <AppCtx.Provider
      value={{
        settings,
        ready,
        reloadSettings,
        saveSettings,
        toast,
        currency: settings.currency || "ج.م",
        theme,
        setTheme,
        shift,
        reloadShift,
      }}
    >
      {children}
      <div className="toasts">
        {toasts.map((t) => (
          <div key={t.id} className={`toast ${t.kind}`}>
            {t.msg}
          </div>
        ))}
      </div>
    </AppCtx.Provider>
  );
}
