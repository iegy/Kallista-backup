// code128.ts — مولّد باركود CODE128 مكتوب بالكامل داخل البرنامج.
// السبب: مكتبة bwip-js بتزوّد حجم البرنامج ١ ميجا كاملة عشان بتدعم عشرات الأنواع،
// واحنا محتاجين نوع واحد بس. الكود ده أقل من ٤ كيلوبايت وبيطلّع نفس النتيجة.

/** أنماط CODE128: كل نمط ٦ أرقام = عرض الشرائط والفراغات بالتناوب (بيبدأ بشريطة) */
const PATTERNS = [
  "212222","222122","222221","121223","121322","131222","122213","122312","132212",
  "221213","221312","231212","112232","122132","122231","113222","123122","123221",
  "223211","221132","221231","213212","223112","312131","311222","321122","321221",
  "312212","322112","322211","212123","212321","232121","111323","131123","131321",
  "112313","132113","132311","211313","231113","231311","112133","112331","132131",
  "113123","113321","133121","313121","211331","231131","213113","213311","213131",
  "311123","311321","331121","312113","312311","332111","314111","221411","431111",
  "111224","111422","121124","121421","141122","141221","112214","112412","122114",
  "122411","142112","142211","241211","221114","413111","241112","134111","111242",
  "121142","121241","114212","124112","124211","411212","421112","421211","212141",
  "214121","412121","111143","111341","131141","114113","114311","411113","411311",
  "113141","114131","311141","411131","211412","211214","211232",
];
const STOP = "2331112";

const START_B = 104;
const START_C = 105;

/** تحويل النص لقائمة أكواد CODE128 (بيستخدم Code C للأرقام عشان الباركود يطلع أقصر) */
function encodeValues(text: string): number[] {
  const digitsOnly = /^\d+$/.test(text);

  // كل النص أرقام وعددها زوجي → Code C (كل رقمين في رمز واحد)
  if (digitsOnly && text.length % 2 === 0) {
    const out = [START_C];
    for (let i = 0; i < text.length; i += 2) out.push(Number(text.slice(i, i + 2)));
    return out;
  }

  // غير كده → Code B (كل الحروف والأرقام المطبوعة)
  const out = [START_B];
  for (const ch of text) {
    const c = ch.charCodeAt(0);
    if (c < 32 || c > 126) throw new Error("حرف غير مدعوم في الباركود: " + ch);
    out.push(c - 32);
  }
  return out;
}

/** رقم التحقق = (قيمة البداية + مجموع (الموضع × القيمة)) ٪ ١٠٣ */
function checksum(values: number[]): number {
  let sum = values[0];
  for (let i = 1; i < values.length; i++) sum += i * values[i];
  return sum % 103;
}

/** أعراض الشرائط والفراغات بالوحدات، بالتناوب بادئًا بشريطة */
export function code128Modules(text: string): number[] {
  const values = encodeValues(text);
  values.push(checksum(values));
  const widths: number[] = [];
  for (const v of values) for (const d of PATTERNS[v]) widths.push(Number(d));
  for (const d of STOP) widths.push(Number(d));
  return widths;
}

export interface BarcodeOpts {
  /** عرض الوحدة الواحدة بالبكسل (كل ما زاد كل ما كان الباركود أوضح في الطباعة) */
  moduleWidth?: number;
  /** ارتفاع الشرائط بالبكسل */
  height?: number;
  /** هامش جانبي بالوحدات (الحد الأدنى المعياري ١٠ وحدات) */
  quietZone?: number;
}

/** توليد صورة SVG للباركود — بتشتغل أوفلاين تمامًا */
export function code128Svg(text: string, opts: BarcodeOpts = {}): string {
  const mw = opts.moduleWidth ?? 2;
  const h = opts.height ?? 60;
  const quiet = opts.quietZone ?? 10;

  const widths = code128Modules(text);
  const totalModules = widths.reduce((a, b) => a + b, 0) + quiet * 2;
  const w = totalModules * mw;

  let x = quiet * mw;
  let bars = "";
  for (let i = 0; i < widths.length; i++) {
    const bw = widths[i] * mw;
    if (i % 2 === 0) bars += `<rect x="${x}" y="0" width="${bw}" height="${h}"/>`;
    x += bw;
  }

  return (
    `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${w} ${h}" ` +
    `width="${w}" height="${h}" shape-rendering="crispEdges">` +
    `<rect width="${w}" height="${h}" fill="#fff"/>` +
    `<g fill="#000">${bars}</g></svg>`
  );
}
