// format.ts — أدوات تنسيق الأرقام والتواريخ

export const n2 = (v: any): number => {
  const x = Number(v);
  return Number.isFinite(x) ? x : 0;
};

/** رقم بفواصل الآلاف وحتى منزلتين عشريتين */
export function num(v: any, digits = 2): string {
  const x = n2(v);
  return x.toLocaleString("en-US", {
    minimumFractionDigits: Number.isInteger(x) ? 0 : digits,
    maximumFractionDigits: digits,
  });
}

/** كمية (بدون أصفار زائدة) */
export function qty(v: any): string {
  const x = n2(v);
  return Number.isInteger(x) ? String(x) : x.toFixed(3).replace(/0+$/, "");
}

export function money(v: any, currency = "ج.م"): string {
  return `${num(v)} ${currency}`;
}

const AR_MONTHS = [
  "يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو",
  "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر",
];

function parse(s: any): Date | null {
  if (!s) return null;
  const d = new Date(String(s).replace(" ", "T"));
  return isNaN(d.getTime()) ? null : d;
}

/** 2026-07-30 → 30 يوليو 2026 */
export function dateAr(s: any): string {
  const d = parse(s);
  if (!d) return "—";
  return `${d.getDate()} ${AR_MONTHS[d.getMonth()]} ${d.getFullYear()}`;
}

/** 2026-07-30 14:05 → 30 يوليو 2026 - 02:05 م */
export function dateTimeAr(s: any): string {
  const d = parse(s);
  if (!d) return "—";
  let h = d.getHours();
  const ap = h >= 12 ? "م" : "ص";
  h = h % 12 || 12;
  const m = String(d.getMinutes()).padStart(2, "0");
  return `${dateAr(s)} - ${String(h).padStart(2, "0")}:${m} ${ap}`;
}

/** تاريخ اليوم بصيغة YYYY-MM-DD بالتوقيت المحلي */
export function todayIso(): string {
  const d = new Date();
  const p = (x: number) => String(x).padStart(2, "0");
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}

/** توحيد النص للبحث: يشيل التشكيل ويوحّد الألف والياء والتاء المربوطة */
export function normalizeAr(s: string): string {
  return (s || "")
    .replace(/[ً-ْـ]/g, "")
    .replace(/[أإآٱ]/g, "ا")
    .replace(/ى/g, "ي")
    .replace(/ة/g, "ه")
    .replace(/[٠-٩]/g, (d) => String("٠١٢٣٤٥٦٧٨٩".indexOf(d)))
    .trim()
    .toLowerCase();
}
