// parties.ts — العملاء والموردين: كشف الحساب وتسجيل التحصيلات والمدفوعات
import { batch, query, type Op } from "./db";
import { n2 } from "./format";

export type PartyType = "customer" | "supplier";

export interface Party {
  id: number;
  name: string;
  phone: string | null;
  address: string | null;
  balance: number;
  notes: string | null;
  created_at: string;
}

export interface StmtRow {
  date: string;
  doc: string;
  up: number; // بيزوّد الرصيد
  down: number; // بيقلّل الرصيد
  balance: number; // الرصيد بعد الحركة
}

const LEDGER_SQL = `
SELECT date,
       COALESCE(document_no || ' — ','') || COALESCE(note,entry_type) AS doc,
       debit AS up,credit AS down
  FROM party_ledger
 WHERE party_type=? AND party_id=?
 ORDER BY date,id`;

const r2 = (x: number) => Math.round((x + Number.EPSILON) * 100) / 100;

/**
 * كشف الحساب. بنمرر الرصيد الحالي عشان نستنتج «الرصيد الافتتاحي» —
 * أي فرق بين الرصيد المسجّل ومجموع الحركات (زي رصيد قديم اتسجّل عند إضافة الطرف).
 */
export async function statement(
  type: PartyType,
  id: number,
  currentBalance = 0
): Promise<StmtRow[]> {
  const rows = await query<any>(LEDGER_SQL, [type, id]);

  const net = rows.reduce((s, r) => s + n2(r.up) - n2(r.down), 0);
  const opening = r2(n2(currentBalance) - net);

  const out: StmtRow[] = [];
  let bal = 0;

  if (opening !== 0) {
    bal = opening;
    out.push({
      date: "",
      doc: "رصيد افتتاحي",
      up: opening > 0 ? opening : 0,
      down: opening < 0 ? -opening : 0,
      balance: bal,
    });
  }

  for (const r of rows) {
    bal = r2(bal + n2(r.up) - n2(r.down));
    out.push({
      date: r.date,
      doc: r.doc,
      up: n2(r.up),
      down: n2(r.down),
      balance: bal,
    });
  }
  return out;
}

/** تسجيل تحصيل من عميل أو دفعة لمورد */
export async function recordPayment(
  type: PartyType,
  id: number,
  amount: number,
  method: string,
  note: string,
  userId: number | null = null,
  shiftId: number | null = null,
  allocations: { invoice_id: number; amount: number }[] = []
): Promise<void> {
  const amt = n2(amount);
  if (amt <= 0) throw new Error("المبلغ لازم يكون أكبر من صفر");

  const direction = type === "customer" ? "in" : "out";
  const table = type === "customer" ? "customers" : "suppliers";
  const documentNo = `${type === "customer" ? "RCPT" : "PAY"}-${Date.now()
    .toString()
    .slice(-10)}`;

  const ops: Op[] = [
    {
      sql: `INSERT INTO payments(party_type,party_id,amount,direction,method,note,
              user_id,shift_id,document_no,reference_type,status)
            VALUES(?,?,?,?,?,?,?,?,?,'voucher','posted')`,
      params: [type, id, amt, direction, method, note || null, userId, shiftId, documentNo],
    },
    {
      sql: `UPDATE ${table} SET balance = balance - ? WHERE id = ?`,
      params: [amt, id],
    },
    {
      sql: `INSERT INTO party_ledger(party_type,party_id,entry_type,reference_type,
              reference_id,document_no,credit,method,user_id,shift_id,note)
            VALUES(?,? ,?,'payment',?,?,?, ?,?,?,?)`,
      params: [
        type,
        id,
        type === "customer" ? "customer_receipt" : "supplier_payment",
        "$LAST_ID:0",
        documentNo,
        amt,
        method,
        userId,
        shiftId,
        note || null,
      ],
    },
  ];
  let allocated = 0;
  for (const a of allocations) {
    const value = n2(a.amount);
    if (value <= 0) continue;
    allocated += value;
    ops.push({
      sql: `INSERT INTO payment_allocations(payment_id,invoice_type,invoice_id,amount)
            VALUES(?,?,?,?)`,
      params: ["$LAST_ID:0", type === "customer" ? "sale" : "purchase", a.invoice_id, value],
    });
  }
  if (allocated > amt + 0.000001) throw new Error("توزيع الدفعة أكبر من المبلغ المستلم");

  if (shiftId && method === "cash") {
    ops.push({
      sql: `INSERT INTO cash_movements(shift_id,movement_type,direction,amount,method,
              reference_type,reference_id,user_id,note)
            VALUES(?,?,?,?, 'cash','payment',?,?,?)`,
      params: [
        shiftId,
        type === "customer" ? "customer_receipt" : "supplier_payment",
        type === "customer" ? "in" : "out",
        amt,
        "$LAST_ID:0",
        userId,
        note || null,
      ],
    });
  }
  ops.push({
    sql: `INSERT INTO audit_log(user_id,action,entity_type,entity_id,new_values)
          VALUES(?,?,?,? ,?)`,
    params: [
      userId,
      type === "customer" ? "customer_receipt_posted" : "supplier_payment_posted",
      "payment",
      "$LAST_ID:0",
      JSON.stringify({ document_no: documentNo, amount: amt, method }),
    ],
  });
  await batch(ops, type === "customer" ? "customer_receipts" : "supplier_payments");
}
