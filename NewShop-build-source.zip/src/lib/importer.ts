// importer.ts — استيراد الأصناف والعملاء والموردين من إكسل أو CSV
//
// الفكرة: نقرا الملف → نربط كل عمود بحقل في البرنامج → نعمل «معاينة»
// توضّح إيه اللي هيتضاف وإيه اللي هيتعدّل وإيه اللي فيه غلط → وبعدين ننفّذ.
// مفيش أي تعديل على قاعدة البيانات قبل ما المستخدم يشوف المعاينة ويوافق.

import { batch, query, type Op } from "./db";
import { normalizeAr } from "./format";

export type ImportKind = "products" | "customers" | "suppliers";

export interface FieldDef {
  key: string;
  label: string;
  /** كلمات بنستخدمها عشان نخمّن العمود من عنوانه */
  aliases: string[];
  kind: "text" | "number";
  required?: boolean;
}

export const FIELDS: Record<ImportKind, FieldDef[]> = {
  products: [
    { key: "name", label: "اسم الصنف", aliases: ["اسم", "الصنف", "المنتج", "name", "item", "product"], kind: "text", required: true },
    { key: "code", label: "الكود", aliases: ["كود", "الكود", "code", "sku"], kind: "text" },
    { key: "barcode", label: "الباركود", aliases: ["باركود", "barcode", "ean"], kind: "text" },
    { key: "plu", label: "كود الميزان", aliases: ["ميزان", "plu"], kind: "text" },
    { key: "category", label: "التصنيف", aliases: ["تصنيف", "القسم", "المجموعة", "category", "group"], kind: "text" },
    { key: "unit", label: "الوحدة", aliases: ["وحده", "الوحده", "unit"], kind: "text" },
    { key: "cost_price", label: "سعر الشراء", aliases: ["شراء", "التكلفه", "تكلفه", "cost", "purchase"], kind: "number" },
    { key: "sell_price", label: "سعر البيع", aliases: ["بيع", "السعر", "price", "sell", "retail"], kind: "number", required: true },
    { key: "wholesale_price", label: "سعر الجملة", aliases: ["جمله", "wholesale"], kind: "number" },
    { key: "qty", label: "الكمية", aliases: ["كميه", "الكميه", "الرصيد", "المخزون", "qty", "quantity", "stock"], kind: "number" },
    { key: "min_qty", label: "الحد الأدنى", aliases: ["حد ادني", "اقل كميه", "min"], kind: "number" },
  ],
  customers: [
    { key: "name", label: "اسم العميل", aliases: ["اسم", "العميل", "name", "customer"], kind: "text", required: true },
    { key: "phone", label: "التليفون", aliases: ["تليفون", "موبايل", "phone", "mobile", "tel"], kind: "text" },
    { key: "address", label: "العنوان", aliases: ["عنوان", "address"], kind: "text" },
    { key: "balance", label: "الرصيد (عليه)", aliases: ["رصيد", "المديونيه", "عليه", "balance", "due"], kind: "number" },
    { key: "notes", label: "ملاحظات", aliases: ["ملاحظات", "notes"], kind: "text" },
  ],
  suppliers: [
    { key: "name", label: "اسم المورد", aliases: ["اسم", "المورد", "name", "supplier", "vendor"], kind: "text", required: true },
    { key: "phone", label: "التليفون", aliases: ["تليفون", "موبايل", "phone", "mobile", "tel"], kind: "text" },
    { key: "address", label: "العنوان", aliases: ["عنوان", "address"], kind: "text" },
    { key: "balance", label: "الرصيد (له)", aliases: ["رصيد", "له", "balance"], kind: "number" },
    { key: "notes", label: "ملاحظات", aliases: ["ملاحظات", "notes"], kind: "text" },
  ],
};

export const KIND_LABEL: Record<ImportKind, string> = {
  products: "الأصناف",
  customers: "العملاء",
  suppliers: "الموردين",
};

/** رقم من نص عربي أو إنجليزي: بيشيل الفواصل والمسافات ويحوّل الأرقام العربية */
export function parseNumber(raw: string): number | null {
  const s = normalizeAr(String(raw ?? ""))
    .replace(/[,٬\s]/g, "")
    .replace(/٫/g, ".")
    .replace(/[^\d.\-]/g, "");
  if (!s || s === "-" || s === ".") return null;
  const n = Number(s);
  return Number.isFinite(n) ? n : null;
}

/** بيخمّن أي عمود يقابل أي حقل، من عناوين الصف الأول */
export function guessMapping(headers: string[], kind: ImportKind): Record<string, number> {
  const map: Record<string, number> = {};
  const used = new Set<number>();
  const norm = headers.map((h) => normalizeAr(h));

  for (const f of FIELDS[kind]) {
    let best = -1;
    for (let i = 0; i < norm.length; i++) {
      if (used.has(i) || !norm[i]) continue;
      const h = norm[i];
      const hit = f.aliases.some((a) => {
        const na = normalizeAr(a);
        return h === na || h.includes(na);
      });
      if (hit) {
        best = i;
        break;
      }
    }
    if (best >= 0) {
      map[f.key] = best;
      used.add(best);
    }
  }
  return map;
}

/* ---------------- المعاينة ---------------- */

export interface RowIssue {
  row: number; // رقم السطر في الملف (بيبدأ من ١ للعناوين)
  message: string;
}

export interface ImportPlan {
  kind: ImportKind;
  create: Record<string, any>[];
  update: { id: number; values: Record<string, any>; name: string; oldQty: number }[];
  issues: RowIssue[];
  /** تصنيفات جديدة هتتعمل تلقائيًا */
  newCategories: string[];
  skipped: number;
}

interface ExistingRow {
  id: number;
  code: string | null;
  barcode: string | null;
  name: string;
  qty: number;
}

/**
 * بيحلّل الصفوف من غير ما يلمس قاعدة البيانات.
 * المطابقة: الكود الأول، وبعدين الباركود، وبعدين الاسم بالظبط.
 */
export async function buildPlan(
  rows: string[][],
  mapping: Record<string, number>,
  kind: ImportKind,
  hasHeader: boolean
): Promise<ImportPlan> {
  const defs = FIELDS[kind];
  const body = hasHeader ? rows.slice(1) : rows;
  const startLine = hasHeader ? 2 : 1;

  const plan: ImportPlan = {
    kind,
    create: [],
    update: [],
    issues: [],
    newCategories: [],
    skipped: 0,
  };

  // البيانات الموجودة حاليًا للمطابقة
  const table = kind === "products" ? "products" : kind;
  const existing =
    kind === "products"
      ? await query<ExistingRow>(`SELECT id, code, barcode, name, qty FROM products`)
      : await query<ExistingRow>(
          `SELECT id, NULL AS code, phone AS barcode, name, 0 AS qty FROM ${table}`
        );

  const byCode = new Map<string, ExistingRow>();
  const byBarcode = new Map<string, ExistingRow>();
  const byName = new Map<string, ExistingRow>();
  for (const e of existing) {
    if (e.code) byCode.set(e.code.trim(), e);
    if (e.barcode) byBarcode.set(String(e.barcode).trim(), e);
    byName.set(normalizeAr(e.name), e);
  }

  const cats =
    kind === "products"
      ? await query<{ id: number; name: string }>(`SELECT id, name FROM categories`)
      : [];
  const catByName = new Map(cats.map((c) => [normalizeAr(c.name), c.id]));
  const newCats = new Set<string>();

  // عشان مانستوردش نفس الصنف مرتين من نفس الملف
  const seen = new Set<string>();

  body.forEach((row, i) => {
    const line = startLine + i;
    if (!row.length || row.every((c) => !String(c).trim())) {
      plan.skipped++;
      return;
    }

    const values: Record<string, any> = {};
    let bad = false;

    for (const f of defs) {
      const idx = mapping[f.key];
      const raw = idx === undefined ? "" : String(row[idx] ?? "").trim();

      if (f.kind === "number") {
        if (idx === undefined) {
          // العمود ده مش مربوط أصلًا — نسيبه null عشان مانمسحش القيمة القديمة
          values[f.key] = null;
        } else if (!raw) {
          values[f.key] = f.required ? null : 0;
        } else {
          const n = parseNumber(raw);
          if (n === null) {
            plan.issues.push({ row: line, message: `«${f.label}» مش رقم: ${raw}` });
            bad = true;
          } else values[f.key] = n;
        }
      } else {
        values[f.key] = raw || null;
      }

      if (f.required && (values[f.key] === null || values[f.key] === "")) {
        plan.issues.push({ row: line, message: `«${f.label}» ناقص` });
        bad = true;
      }
    }

    if (bad) return;

    if (kind === "products" && Number(values.sell_price) <= 0) {
      plan.issues.push({ row: line, message: "سعر البيع لازم يكون أكبر من صفر" });
      return;
    }

    const key = normalizeAr(
      String(values.code || values.barcode || values.name || "")
    );
    if (seen.has(key)) {
      plan.issues.push({ row: line, message: `مكرر في نفس الملف: ${values.name}` });
      return;
    }
    seen.add(key);

    // تصنيف جديد؟
    if (kind === "products" && values.category) {
      const nc = normalizeAr(values.category);
      if (!catByName.has(nc) && !newCats.has(values.category)) {
        newCats.add(values.category);
      }
    }

    const match =
      (values.code && byCode.get(String(values.code).trim())) ||
      (values.barcode && byBarcode.get(String(values.barcode).trim())) ||
      byName.get(normalizeAr(String(values.name)));

    if (match)
      plan.update.push({
        id: match.id,
        values,
        name: String(values.name),
        oldQty: Number(match.qty || 0),
      });
    else plan.create.push(values);
  });

  plan.newCategories = [...newCats];
  return plan;
}

/* ---------------- التنفيذ ---------------- */

export async function applyPlan(plan: ImportPlan): Promise<{ created: number; updated: number }> {
  const ops: Op[] = [];

  if (plan.kind === "products") {
    for (const name of plan.newCategories) {
      ops.push({ sql: `INSERT OR IGNORE INTO categories(name) VALUES(?)`, params: [name] });
    }

    for (const v of plan.create) {
      ops.push({
        sql: `INSERT INTO products(code, name, barcode, plu, category_id, unit,
                cost_price, sell_price, wholesale_price, qty, min_qty, is_active)
              VALUES(?,?,?,?,(SELECT id FROM categories WHERE name = ?),
                     COALESCE(NULLIF(?,''),'قطعة'),?,?,?,?,?,1)`,
        params: [
          v.code,
          v.name,
          v.barcode,
          v.plu,
          v.category,
          v.unit || "",
          v.cost_price ?? 0,
          v.sell_price ?? 0,
          v.wholesale_price || v.sell_price || 0,
          v.qty ?? 0,
          v.min_qty ?? 0,
        ],
      });
      // رصيد افتتاحي في حركة المخزن
      if (Number(v.qty) > 0) {
        ops.push({
          sql: `INSERT INTO stock_moves(product_id, qty_change, type, note)
                VALUES(?,?, 'manual', 'رصيد افتتاحي — استيراد من ملف')`,
          params: ["$LAST_ID", v.qty],
        });
      }
    }

    for (const u of plan.update) {
      const v = u.values;
      ops.push({
        sql: `UPDATE products SET
                name = ?,
                barcode = COALESCE(?, barcode),
                plu = COALESCE(?, plu),
                unit = COALESCE(NULLIF(?,''), unit),
                category_id = COALESCE((SELECT id FROM categories WHERE name = ?), category_id),
                cost_price = COALESCE(?, cost_price),
                sell_price = COALESCE(?, sell_price),
                wholesale_price = COALESCE(?, wholesale_price),
                qty = COALESCE(?, qty),
                min_qty = COALESCE(?, min_qty)
              WHERE id = ?`,
        params: [
          v.name,
          v.barcode,
          v.plu,
          v.unit || "",
          v.category,
          v.cost_price,
          v.sell_price,
          v.wholesale_price,
          v.qty,
          v.min_qty,
          u.id,
        ],
      });
      // لو الكمية اتغيّرت نسجّلها في حركة المخزن
      if (v.qty !== null && v.qty !== undefined && Number(v.qty) !== u.oldQty) {
        ops.push({
          sql: `INSERT INTO stock_moves(product_id, qty_change, type, note)
                VALUES(?,?, 'manual', 'تعديل الكمية — استيراد من ملف')`,
          params: [u.id, Number(v.qty) - u.oldQty],
        });
      }
    }
  } else {
    const table = plan.kind;
    for (const v of plan.create) {
      ops.push({
        sql: `INSERT INTO ${table}(name, phone, address, balance, notes) VALUES(?,?,?,?,?)`,
        params: [v.name, v.phone, v.address, v.balance ?? 0, v.notes],
      });
    }
    for (const u of plan.update) {
      const v = u.values;
      ops.push({
        sql: `UPDATE ${table} SET name = ?,
                phone = COALESCE(?, phone),
                address = COALESCE(?, address),
                balance = COALESCE(?, balance),
                notes = COALESCE(?, notes)
              WHERE id = ?`,
        params: [v.name, v.phone, v.address, v.balance, v.notes, u.id],
      });
    }
  }

  if (!ops.length) return { created: 0, updated: 0 };
  await batch(ops);
  return { created: plan.create.length, updated: plan.update.length };
}
