// sales.ts — منطق فاتورة البيع: الترقيم، الحفظ في معاملة واحدة، وقراءة الفاتورة للطباعة
import { batch, query, queryOne, type Op } from "./db";
import { n2 } from "./format";

export interface CartLine {
  product_id: number;
  code: string;
  name: string;
  unit: string;
  qty: number;
  price: number;
  cost: number; // تكلفة الصنف وقت البيع
  discount: number; // خصم على السطر بالقيمة
  stock: number; // الرصيد المتاح وقت الإضافة
}

export const lineTotal = (l: CartLine) =>
  Math.max(0, n2(l.qty) * n2(l.price) - n2(l.discount));

/* ---------- طرق الدفع ---------- */

export type PayMethod = "cash" | "card" | "wallet" | "credit";

export interface PaySplit {
  method: PayMethod;
  amount: number;
}

/** الطرق اللي بتدخل فلوس فعلية (الآجل مش منها) */
export const CASH_METHODS: PayMethod[] = ["cash", "card", "wallet"];

/** الطرق اللي بتدخل درج الكاش (المهمة في تقفيل الوردية) */
export const DRAWER_METHODS: PayMethod[] = ["cash"];

export const PAY_LABELS: Record<string, string> = {
  cash: "نقدي",
  card: "فيزا",
  wallet: "محفظة",
  credit: "آجل",
  mixed: "مقسّم",
};

/** مجموع المدفوع فعلًا (من غير الآجل) */
export const paidOf = (splits: PaySplit[]): number =>
  round2(
    splits
      .filter((s) => s.method !== "credit")
      .reduce((sum, s) => sum + n2(s.amount), 0)
  );

/** نوع الدفع اللي بيتخزن في عمود payment_type */
export function paymentTypeOf(splits: PaySplit[], remaining: number): string {
  const used = splits.filter((s) => s.method !== "credit" && n2(s.amount) > 0);
  if (remaining > 0) return used.length ? "mixed" : "credit";
  if (used.length === 1) return used[0].method;
  return used.length ? "mixed" : "cash";
}

export interface SalePayload {
  lines: CartLine[];
  customerId: number | null;
  invoiceDiscount: number;
  /** المدفوع — بيتحسب من splits لو موجودة */
  paid: number;
  /** تفصيل الدفع بطرق مختلفة؛ لو مش موجودة بنعتبر كله كاش */
  splits?: PaySplit[];
  notes?: string;
  userId?: number | null;
  /** الوردية المفتوحة وقت البيع */
  shiftId?: number | null;
  priceLevel?: "retail" | "wholesale" | "special";
  taxRate?: number;
  taxMode?: "disabled" | "exclusive" | "inclusive";
}

export interface SuspendedSale {
  id: number;
  label: string | null;
  customer_id: number | null;
  invoice_discount: number;
  notes: string | null;
  user_id: number | null;
  created_at: string;
  item_count: number;
  total: number;
  price_level: "retail" | "wholesale" | "special";
}

export interface SuspendedPayload {
  label?: string;
  lines: CartLine[];
  customerId: number | null;
  invoiceDiscount: number;
  notes?: string;
  userId?: number | null;
  priceLevel?: "retail" | "wholesale" | "special";
}

export interface SaleTotals {
  subtotal: number;
  discount: number;
  total: number;
  paid: number;
  remaining: number;
  paymentType: "cash" | "credit" | "mixed";
  profit: number;
  tax: number;
  netBeforeTax: number;
}

export function computeTotals(
  lines: CartLine[],
  invoiceDiscount: number,
  paid: number,
  taxRate = 0,
  taxMode: "disabled" | "exclusive" | "inclusive" = "disabled"
): SaleTotals {
  const subtotal = lines.reduce((s, l) => s + lineTotal(l), 0);
  const discount = Math.min(n2(invoiceDiscount), subtotal);
  const discounted = round2(subtotal - discount);
  const rate = Math.max(0, n2(taxRate));
  const tax =
    taxMode === "exclusive" && rate > 0
      ? round2((discounted * rate) / 100)
      : taxMode === "inclusive" && rate > 0
        ? round2((discounted * rate) / (100 + rate))
        : 0;
  const total = taxMode === "exclusive" ? round2(discounted + tax) : discounted;
  const netBeforeTax = round2(total - tax);
  const p = Math.min(n2(paid), total);
  const remaining = round2(total - p);
  const cost = lines.reduce((s, l) => s + n2(l.qty) * n2(l.cost), 0);
  return {
    subtotal: round2(subtotal),
    discount: round2(discount),
    total,
    paid: round2(p),
    remaining,
    paymentType: remaining <= 0 ? "cash" : p > 0 ? "mixed" : "credit",
    profit: round2(netBeforeTax - cost),
    tax,
    netBeforeTax,
  };
}

export const round2 = (x: number) => Math.round((n2(x) + Number.EPSILON) * 100) / 100;

/** توزيع خصم رأس الفاتورة على البنود مع تثبيت فرق التقريب في آخر بند. */
export function allocateInvoiceDiscount(lines: CartLine[], discount: number): number[] {
  const bases = lines.map(lineTotal);
  const baseTotal = round2(bases.reduce((s, x) => s + x, 0));
  const wanted = round2(Math.min(Math.max(0, n2(discount)), baseTotal));
  if (!wanted || !baseTotal) return lines.map(() => 0);
  let used = 0;
  return bases.map((base, i) => {
    const value = i === bases.length - 1 ? round2(wanted - used) : round2((wanted * base) / baseTotal);
    used = round2(used + value);
    return value;
  });
}

/**
 * بيقصّ مبالغ الدفع لو مجموعها زاد عن إجمالي الفاتورة (الباقي بيترد للعميل
 * كاش ومش بيتسجّل كدفع). بيمشي بالترتيب وبيقصّ من الآخر.
 */
export function capSplits(splits: PaySplit[], total: number): PaySplit[] {
  const out: PaySplit[] = [];
  let left = round2(total);
  for (const s of splits) {
    if (left <= 0) break;
    const amount = round2(Math.min(n2(s.amount), left));
    if (amount <= 0) continue;
    out.push({ method: s.method, amount });
    left = round2(left - amount);
  }
  return out;
}

/** رقم الفاتورة الجاي = البادئة + العداد + ١ */
export async function nextInvoiceNo(): Promise<{ no: string; counter: number }> {
  const rows = await query<{ key: string; value: string }>(
    `SELECT key, value FROM settings WHERE key IN ('invoice_prefix','invoice_counter')`
  );
  const m: Record<string, string> = {};
  for (const r of rows) m[r.key] = r.value ?? "";
  const counter = Number(m.invoice_counter || 0) + 1;
  const prefix = m.invoice_prefix ?? "INV-";
  return { no: `${prefix}${String(counter).padStart(4, "0")}`, counter };
}

/**
 * حفظ الفاتورة كاملة في معاملة واحدة:
 * الفاتورة → بنودها → خصم المخزون → حركة المخزن → رصيد العميل → التحصيل → العداد
 */
export async function saveSale(
  p: SalePayload
): Promise<{ id: number; invoiceNo: string; totals: SaleTotals }> {
  if (!p.lines.length) throw new Error("الفاتورة فاضية");
  if (n2(p.invoiceDiscount) < 0) throw new Error("خصم الفاتورة لا يمكن أن يكون سالبًا");
  for (const line of p.lines) {
    if (!Number.isInteger(Number(line.product_id)) || Number(line.product_id) <= 0)
      throw new Error("يوجد صنف غير صالح في الفاتورة");
    if (n2(line.qty) <= 0) throw new Error(`كمية «${line.name}» يجب أن تكون أكبر من صفر`);
    if (n2(line.price) < 0 || n2(line.cost) < 0 || n2(line.discount) < 0)
      throw new Error(`السعر أو الخصم غير صالح للصنف «${line.name}»`);
    if (n2(line.discount) > n2(line.qty) * n2(line.price))
      throw new Error(`خصم «${line.name}» أكبر من قيمة السطر`);
  }

  // الائتمان ليس حركة دفع فعلية؛ الباقي فقط هو الذي يُسجل كآجل.
  // التصفية هنا تحمي المحرك حتى لو أرسلت واجهة أو تكامل خارجي payload معدلًا.
  const splitsIn: PaySplit[] = p.splits?.length
    ? p.splits.filter(
        (s) => CASH_METHODS.includes(s.method) && n2(s.amount) > 0
      )
    : ([{ method: "cash", amount: n2(p.paid) }] as PaySplit[]).filter(
        (s) => s.amount > 0
      );

  const taxMode = p.taxMode === "exclusive" || p.taxMode === "inclusive" ? p.taxMode : "disabled";
  const taxRate = taxMode === "disabled" ? 0 : Math.max(0, n2(p.taxRate));
  const priceLevel = ["retail", "wholesale", "special"].includes(String(p.priceLevel))
    ? p.priceLevel!
    : "retail";
  const t = computeTotals(p.lines, p.invoiceDiscount, paidOf(splitsIn), taxRate, taxMode);
  if (t.remaining > 0 && !p.customerId)
    throw new Error("لا يمكن تسجيل بيع آجل بدون اختيار عميل");

  // بنقصّ آخر مبلغ لو المدفوع زاد عن الإجمالي، عشان مجموع الجدول يساوي الفاتورة
  const splits = capSplits(splitsIn, t.total);
  const payType = paymentTypeOf(splits, t.remaining);

  const { no, counter } = await nextInvoiceNo();
  const uid = p.userId ?? null;
  const allocated = allocateInvoiceDiscount(p.lines, t.discount);
  const grossTotal = round2(
    p.lines.reduce((s, l) => s + n2(l.qty) * n2(l.price), 0)
  );

  const ops: Op[] = [
    {
      // العملية رقم ٠ → رقم الفاتورة يتقرا بـ "$LAST_ID:0"
      sql: `INSERT INTO sales(invoice_no, customer_id, user_id, subtotal, discount,
              tax, total, paid, remaining, payment_type, status, notes, shift_id,
              document_state, gross_total, tax_rate, tax_mode,price_level)
            VALUES(?,?,?,?,?,?,?,?,?,?,'active',?,?,'posted',?,?,?,?)`,
      params: [
        no,
        p.customerId,
        uid,
        t.subtotal,
        t.discount,
        t.tax,
        t.total,
        t.paid,
        t.remaining,
        payType,
        p.notes || null,
        p.shiftId ?? null,
        grossTotal,
        taxRate,
        taxMode,
        priceLevel,
      ],
    },
  ];

  // تفصيل الدفع
  for (const s of splits) {
    ops.push({
      sql: `INSERT INTO sale_payments(sale_id, method, amount) VALUES(?,?,?)`,
      params: ["$LAST_ID:0", s.method, s.amount],
    });
  }
  if (t.remaining > 0) {
    ops.push({
      sql: `INSERT INTO sale_payments(sale_id, method, amount) VALUES(?,'credit',?)`,
      params: ["$LAST_ID:0", t.remaining],
    });
  }

  let allocatedTaxUsed = 0;
  for (let lineIndex = 0; lineIndex < p.lines.length; lineIndex += 1) {
    const l = p.lines[lineIndex];
    const allocatedDiscount = allocated[lineIndex];
    const discountedLine = round2(Math.max(0, lineTotal(l) - allocatedDiscount));
    const rawTax =
      taxMode === "exclusive"
        ? round2((discountedLine * taxRate) / 100)
        : taxMode === "inclusive" && taxRate > 0
          ? round2((discountedLine * taxRate) / (100 + taxRate))
          : 0;
    const taxAmount = lineIndex === p.lines.length - 1
      ? round2(t.tax - allocatedTaxUsed)
      : rawTax;
    allocatedTaxUsed = round2(allocatedTaxUsed + taxAmount);
    const netTotal = taxMode === "exclusive"
      ? round2(discountedLine + taxAmount)
      : discountedLine;
    const effectiveUnit = l.qty ? round2(netTotal / n2(l.qty)) : 0;
    ops.push({
      sql: `INSERT INTO sale_items(sale_id, product_id, qty, price, cost_at_sale, discount, total,
              product_name_snapshot,code_snapshot,unit_snapshot,original_unit_price,line_discount,
              allocated_invoice_discount,effective_unit_net,line_net_total,tax_rate,tax_amount)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      params: [
        "$LAST_ID:0",
        l.product_id,
        l.qty,
        l.price,
        l.cost,
        l.discount,
        lineTotal(l),
        l.name,
        l.code,
        l.unit,
        l.price,
        l.discount,
        allocatedDiscount,
        effectiveUnit,
        netTotal,
        taxRate,
        taxAmount,
      ],
    });
    ops.push({
      sql: `INSERT INTO stock_moves(product_id, qty_change, type, ref_id, note, user_id,
              reference_type,reference_id,qty_before,qty_after,unit_cost,total_value,shift_id)
            SELECT id, ?, 'sale', ?, ?, ?, 'sale', ?, qty, qty-?, cost_price, ?*cost_price, ?
              FROM products WHERE id=?`,
      params: [
        -n2(l.qty),
        "$LAST_ID:0",
        `فاتورة بيع ${no}`,
        uid,
        "$LAST_ID:0",
        l.qty,
        -n2(l.qty),
        p.shiftId ?? null,
        l.product_id,
      ],
    });
    ops.push({
      sql: `UPDATE products SET qty = qty - ? WHERE id = ?`,
      params: [l.qty, l.product_id],
    });
  }

  if (p.customerId) {
    if (t.remaining > 0) {
      ops.push({
        sql: `UPDATE customers SET balance = balance + ? WHERE id = ?`,
        params: [t.remaining, p.customerId],
      });
    }
    ops.push({
      sql: `INSERT INTO party_ledger(party_type,party_id,entry_type,reference_type,
              reference_id,document_no,debit,user_id,shift_id,note)
            VALUES('customer',?,'sale','sale',?,?,?, ?,?,?)`,
      params: [
        p.customerId,
        "$LAST_ID:0",
        no,
        t.total,
        uid,
        p.shiftId ?? null,
        `فاتورة بيع ${no}`,
      ],
    });
    for (const s of splits) {
      ops.push({
        sql: `INSERT INTO payments(party_type, party_id, amount, direction, method, note,
                user_id, shift_id, source,document_no,reference_type,reference_id)
              VALUES('customer', ?, ?, 'in', ?, ?, ?, ?, 'sale',?,'sale',?)`,
        params: [
          p.customerId,
          s.amount,
          s.method,
          `تحصيل مع فاتورة ${no}`,
          uid,
          p.shiftId ?? null,
          no,
          "$LAST_ID:0",
        ],
      });
      ops.push({
        sql: `INSERT INTO party_ledger(party_type,party_id,entry_type,reference_type,
                reference_id,document_no,credit,method,user_id,shift_id,note)
              VALUES('customer',?,'sale_payment','sale',?,?,?, ?,?,?,?)`,
        params: [
          p.customerId,
          "$LAST_ID:0",
          no,
          s.amount,
          s.method,
          uid,
          p.shiftId ?? null,
          `دفعة على فاتورة ${no}`,
        ],
      });
    }
  }

  if (p.shiftId) {
    for (const s of splits.filter((x) => x.method === "cash")) {
      ops.push({
        sql: `INSERT INTO cash_movements(shift_id,movement_type,direction,amount,method,
                reference_type,reference_id,user_id,note)
              VALUES(?,'cash_sale','in',?,'cash','sale',?,?,?)`,
        params: [p.shiftId, s.amount, "$LAST_ID:0", uid, `فاتورة بيع ${no}`],
      });
    }
  }

  ops.push({
    sql: `INSERT INTO audit_log(user_id,action,entity_type,entity_id,new_values)
          VALUES(?,'sale_posted','sale',?,?)`,
    params: [uid, "$LAST_ID:0", JSON.stringify({ invoice_no: no, total: t.total })],
  });

  ops.push({
    sql: `INSERT INTO settings(key,value) VALUES('invoice_counter',?)
          ON CONFLICT(key) DO UPDATE SET value = excluded.value`,
    params: [String(counter)],
  });

  const ids = await batch(ops, "sales_create");
  return { id: ids[0], invoiceNo: no, totals: t };
}

/** يحفظ كل حالة الفاتورة الحالية دون التأثير على المخزون أو عدّاد الفواتير. */
export async function suspendSale(p: SuspendedPayload): Promise<number> {
  if (!p.lines.length) throw new Error("الفاتورة فاضية");
  const ops: Op[] = [
    {
      sql: `INSERT INTO suspended_sales(label,customer_id,price_level,invoice_discount,notes,user_id)
            VALUES(?,?,?,?,?,?)`,
      params: [p.label?.trim() || null, p.customerId, p.priceLevel || "retail", round2(p.invoiceDiscount), p.notes || null, p.userId ?? null],
    },
  ];
  for (const line of p.lines) {
    ops.push({
      sql: `INSERT INTO suspended_sale_items(suspended_sale_id,product_id,product_name,code,
              unit,qty,price,cost_snapshot,line_discount)
            VALUES(?,?,?,?,?,?,?,?,?)`,
      params: [
        "$LAST_ID:0",
        line.product_id,
        line.name,
        line.code,
        line.unit,
        line.qty,
        line.price,
        line.cost,
        line.discount,
      ],
    });
  }
  ops.push({
    sql: `INSERT INTO audit_log(user_id,action,entity_type,entity_id,new_values)
          VALUES(?,'sale_suspended','suspended_sale',?,?)`,
    params: [p.userId ?? null, "$LAST_ID:0", JSON.stringify({ label: p.label || null, lines: p.lines.length })],
  });
  return (await batch(ops, "sales_create"))[0];
}

export async function listSuspendedSales(): Promise<SuspendedSale[]> {
  return query<SuspendedSale>(
    `SELECT s.id,s.label,s.customer_id,s.invoice_discount,s.notes,s.user_id,s.created_at,
            COUNT(i.id) AS item_count,
            ROUND(COALESCE(SUM(MAX(0,i.qty*i.price-i.line_discount)),0)-s.invoice_discount,2) AS total
       FROM suspended_sales s LEFT JOIN suspended_sale_items i ON i.suspended_sale_id=s.id
      GROUP BY s.id ORDER BY s.updated_at DESC,s.id DESC`
  );
}

export async function loadSuspendedSale(id: number): Promise<{
  head: SuspendedSale;
  lines: CartLine[];
} | null> {
  const head = await queryOne<SuspendedSale>(
    `SELECT s.*,COUNT(i.id) AS item_count,
            ROUND(COALESCE(SUM(MAX(0,i.qty*i.price-i.line_discount)),0)-s.invoice_discount,2) AS total
       FROM suspended_sales s LEFT JOIN suspended_sale_items i ON i.suspended_sale_id=s.id
      WHERE s.id=? GROUP BY s.id`,
    [id]
  );
  if (!head) return null;
  const lines = await query<CartLine>(
    `SELECT i.product_id,COALESCE(i.code,p.code,'') AS code,i.product_name AS name,
            i.unit,i.qty,i.price,i.cost_snapshot AS cost,i.line_discount AS discount,
            COALESCE(p.qty,0) AS stock
       FROM suspended_sale_items i LEFT JOIN products p ON p.id=i.product_id
      WHERE i.suspended_sale_id=? ORDER BY i.id`,
    [id]
  );
  return { head, lines };
}

export async function discardSuspendedSale(id: number, userId?: number | null): Promise<void> {
  await batch(
    [
      { sql: `DELETE FROM suspended_sale_items WHERE suspended_sale_id=?`, params: [id] },
      { sql: `DELETE FROM suspended_sales WHERE id=?`, params: [id] },
      {
        sql: `INSERT INTO audit_log(user_id,action,entity_type,entity_id)
              VALUES(?,'suspended_sale_removed','suspended_sale',?)`,
        params: [userId ?? null, id],
      },
    ],
    "sales_create"
  );
}

/* ---------- قراءة فاتورة للطباعة أو العرض ---------- */

export interface InvoiceHead {
  id: number;
  invoice_no: string;
  date: string;
  subtotal: number;
  discount: number;
  total: number;
  paid: number;
  remaining: number;
  payment_type: string;
  status: string;
  notes: string | null;
  customer_name: string | null;
  customer_phone: string | null;
  user_name: string | null;
  document_state: string;
  tax: number;
  tax_rate: number;
  tax_mode: string;
  price_level: string;
}

export interface InvoiceLine {
  id: number;
  name: string;
  code: string | null;
  unit: string;
  qty: number;
  price: number;
  discount: number;
  total: number;
  allocated_invoice_discount?: number;
  line_net_total?: number;
}

export async function getSalePayments(id: number): Promise<PaySplit[]> {
  return query<PaySplit>(
    `SELECT method, amount FROM sale_payments WHERE sale_id = ? ORDER BY id`,
    [id]
  );
}

export async function getInvoice(
  id: number
): Promise<{
  head: InvoiceHead;
  lines: InvoiceLine[];
  payments: PaySplit[];
} | null> {
  const head = await queryOne<InvoiceHead>(
    `SELECT s.*, c.name AS customer_name, c.phone AS customer_phone,
            u.full_name AS user_name
       FROM sales s
       LEFT JOIN customers c ON c.id = s.customer_id
       LEFT JOIN users u     ON u.id = s.user_id
      WHERE s.id = ?`,
    [id]
  );
  if (!head) return null;
  const lines = await query<InvoiceLine>(
    `SELECT si.id, si.qty, si.price, si.discount,
            CASE WHEN si.line_net_total>0 THEN si.line_net_total ELSE si.total END AS total,
            si.allocated_invoice_discount,si.line_net_total,
            COALESCE(si.product_name_snapshot,p.name,'صنف محذوف') AS name,
            COALESCE(si.code_snapshot,p.code) AS code,
            COALESCE(si.unit_snapshot,p.unit,'') AS unit
       FROM sale_items si LEFT JOIN products p ON p.id = si.product_id
      WHERE si.sale_id = ? ORDER BY si.id`,
    [id]
  );
  return { head, lines, payments: await getSalePayments(id) };
}

/** إلغاء فاتورة: يرجّع الأصناف للمخزن ويعدّل رصيد العميل */
export async function cancelSale(
  id: number,
  reason: string,
  userId: number | null = null,
  shiftId: number | null = null,
  overrideUserId: number | null = null
): Promise<void> {
  const inv = await getInvoice(id);
  if (!inv) throw new Error("الفاتورة غير موجودة");
  if (!reason.trim()) throw new Error("سبب الإلغاء مطلوب");
  if (inv.head.status !== "active" || (inv.head as any).document_state !== "posted")
    throw new Error("لا يمكن إلغاء الفاتورة في حالتها الحالية");

  const returned = await query<{ n: number }>(
    `SELECT COUNT(*) AS n FROM returns WHERE type='sale' AND ref_id=? AND status='posted'`,
    [id]
  );
  if (Number(returned[0]?.n || 0) > 0)
    throw new Error("لا يمكن إلغاء فاتورة لها مرتجع؛ استخدم مرتجعًا لباقي الكميات بدلًا من الإلغاء");

  const items = await query<{ product_id: number; qty: number }>(
    `SELECT product_id, qty FROM sale_items WHERE sale_id = ? AND product_id IS NOT NULL`,
    [id]
  );

  const ops: Op[] = [
    {
      sql: `UPDATE sales SET status='cancelled', document_state='void',
              voided_at=datetime('now','localtime'),voided_by=?,void_reason=?,
              notes = COALESCE(notes||' | ','') || ?
            WHERE id = ?`,
      params: [userId, reason.trim(), `ملغية: ${reason.trim()}`, id],
    },
  ];

  for (const it of items) {
    ops.push({
      sql: `INSERT INTO stock_moves(product_id,qty_change,type,ref_id,note,user_id,
              reference_type,reference_id,qty_before,qty_after,unit_cost,total_value,shift_id)
            SELECT id,?,'void',?,?,?,'sale_void',?,qty,qty+?,cost_price,?*cost_price,?
              FROM products WHERE id=?`,
      params: [
        it.qty,
        id,
        `إلغاء فاتورة ${inv.head.invoice_no}`,
        userId,
        id,
        it.qty,
        it.qty,
        shiftId,
        it.product_id,
      ],
    });
    ops.push({
      sql: `UPDATE products SET qty = qty + ? WHERE id = ?`,
      params: [it.qty, it.product_id],
    });
  }

  const [c] = await query<{ customer_id: number | null }>(
    `SELECT customer_id FROM sales WHERE id = ?`,
    [id]
  );
  if (c?.customer_id) {
    if (n2(inv.head.remaining) > 0) {
      ops.push({
        sql: `UPDATE customers SET balance = balance - ? WHERE id = ?`,
        params: [n2(inv.head.remaining), c.customer_id],
      });
    }
    ops.push({
      sql: `INSERT INTO party_ledger(party_type,party_id,entry_type,reference_type,
              reference_id,document_no,credit,user_id,shift_id,note)
            VALUES('customer',?,'sale_void','sale',?,?,?, ?,?,?)`,
      params: [
        c.customer_id,
        id,
        inv.head.invoice_no,
        inv.head.total,
        userId,
        shiftId,
        `إلغاء فاتورة ${inv.head.invoice_no}`,
      ],
    });
    if (n2(inv.head.paid) > 0) {
      ops.push({
        sql: `INSERT INTO party_ledger(party_type,party_id,entry_type,reference_type,
                reference_id,document_no,debit,user_id,shift_id,note)
              VALUES('customer',?,'payment_void','sale',?,?,?, ?,?,?)`,
        params: [
          c.customer_id,
          id,
          inv.head.invoice_no,
          inv.head.paid,
          userId,
          shiftId,
          `رد مدفوعات فاتورة ${inv.head.invoice_no}`,
        ],
      });
    }
  }

  const paymentRows = await getSalePayments(id);
  if (shiftId) {
    for (const p of paymentRows.filter((x) => x.method === "cash" && n2(x.amount) > 0)) {
      ops.push({
        sql: `INSERT INTO cash_movements(shift_id,movement_type,direction,amount,method,
                reference_type,reference_id,user_id,note)
              VALUES(?,'sale_void_refund','out',?,'cash','sale',?,?,?)`,
        params: [shiftId, p.amount, id, userId, `إلغاء فاتورة ${inv.head.invoice_no}`],
      });
    }
  }
  ops.push({
    sql: `UPDATE sale_payments SET status='void' WHERE sale_id=?`,
    params: [id],
  });
  ops.push({
    sql: `INSERT INTO audit_log(user_id,override_user_id,action,entity_type,entity_id,
            old_values,new_values,reason)
          VALUES(?,?,'sale_voided','sale',?,'posted','void',?)`,
    params: [userId, overrideUserId, id, reason.trim()],
  });

  await batch(ops, "invoices_cancel");
}
