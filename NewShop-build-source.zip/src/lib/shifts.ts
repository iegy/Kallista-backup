// shifts.ts — الورديات وتقفيل درج الكاش
//
// فكرة الوردية: الكاشير بيفتح وردية ومعاه رصيد بداية في الدرج، وكل حركة
// فلوس بتتربط بالوردية. في الآخر البرنامج بيقول «المفروض في الدرج كذا»،
// والكاشير بيعدّ اللي معاه فعلًا، والفرق بيتسجّل عجز أو زيادة.
//
// تقرير X = كشف حساب في نص الوردية من غير تقفيل (ينفع يتطبع أكتر من مرة).
// تقرير Z = التقفيل النهائي، وبعده الوردية مابتتعدّلش.

import { batch, query, queryOne, type Op } from "./db";
import { n2 } from "./format";
import { round2, type PayMethod } from "./sales";

export interface Shift {
  id: number;
  user_id: number | null;
  user_name: string | null;
  opened_at: string;
  closed_at: string | null;
  opening_cash: number;
  expected_cash: number | null;
  counted_cash: number | null;
  diff: number | null;
  status: "open" | "closed";
  notes: string | null;
  z_number: string | null;
  z_report_json: string | null;
}

/** الوردية المفتوحة حاليًا (وردية واحدة في نفس الوقت على الجهاز) */
export async function openShift(): Promise<Shift | null> {
  return queryOne<Shift>(
    `SELECT s.*, u.full_name AS user_name
       FROM shifts s LEFT JOIN users u ON u.id = s.user_id
      WHERE s.status = 'open' ORDER BY s.id DESC LIMIT 1`
  );
}

export async function listShifts(limit = 60): Promise<Shift[]> {
  return query<Shift>(
    `SELECT s.*, u.full_name AS user_name
       FROM shifts s LEFT JOIN users u ON u.id = s.user_id
      ORDER BY s.id DESC LIMIT ?`,
    [limit]
  );
}

export async function startShift(
  userId: number | null,
  openingCash: number,
  notes?: string
): Promise<number> {
  const cur = await openShift();
  if (cur) throw new Error("في وردية مفتوحة بالفعل — اقفلها الأول");
  const ids = await batch(
    [
      {
        sql: `INSERT INTO shifts(user_id,opening_cash,notes) VALUES(?,?,?)`,
        params: [userId, round2(openingCash), notes?.trim() || null],
      },
      {
        sql: `INSERT INTO audit_log(user_id,action,entity_type,entity_id,new_values)
              VALUES(?,'shift_opened','shift',?,?)`,
        params: [userId, "$LAST_ID:0", JSON.stringify({ opening_cash: round2(openingCash) })],
      },
    ],
    "shifts_open"
  );
  return ids[0];
}

/** إيداع في الدرج (موجب) أو سحب منه (سالب) */
export async function moveCash(
  shiftId: number,
  amount: number,
  reason: string,
  userId: number | null
): Promise<void> {
  const amt = round2(amount);
  if (!amt) throw new Error("المبلغ لازم يكون أكبر من صفر");
  if (!reason.trim()) throw new Error("اكتب سبب الحركة");
  await batch(
    [
      {
        sql: `INSERT INTO shift_cash(shift_id,amount,reason,user_id) VALUES(?,?,?,?)`,
        params: [shiftId, amt, reason.trim(), userId],
      },
      {
        sql: `INSERT INTO cash_movements(shift_id,movement_type,direction,amount,method,
                reference_type,reference_id,user_id,note)
              VALUES(?,?,?,?,'cash','shift_cash',?,?,?)`,
        params: [
          shiftId,
          amt > 0 ? "cash_in" : "cash_out",
          amt > 0 ? "in" : "out",
          Math.abs(amt),
          "$LAST_ID:0",
          userId,
          reason.trim(),
        ],
      },
      {
        sql: `INSERT INTO audit_log(user_id,action,entity_type,entity_id,reason,new_values)
              VALUES(?,?,'shift',?,?,?)`,
        params: [
          userId,
          amt > 0 ? "cash_in" : "cash_out",
          shiftId,
          reason.trim(),
          JSON.stringify({ amount: Math.abs(amt) }),
        ],
      },
    ],
    "shifts"
  );
}

/* ---------------- تقرير الوردية ---------------- */

export interface ShiftReport {
  shift: Shift;
  /** عدد الفواتير */
  invoices: number;
  /** إجمالي مبيعات الوردية (بالسعر النهائي) */
  salesTotal: number;
  /** المبيعات مقسّمة على طرق الدفع */
  byMethod: Record<PayMethod, number>;
  /** مرتجعات بيع اتردّت كاش (بدون عميل) */
  cashRefunds: number;
  /** مرتجعات مشتريات استُردّت نقدًا من المورد */
  purchaseRefunds: number;
  /** مرتجعات بيع اتخصمت من رصيد عميل */
  creditRefunds: number;
  /** تحصيلات من عملاء برّه الفواتير */
  collections: { cash: number; other: number };
  /** مدفوعات للموردين */
  supplierPaid: { cash: number; other: number };
  /** مصروفات اتدفعت من الدرج */
  expenses: number;
  /** إيداعات وسحوبات يدوية */
  cashIn: number;
  cashOut: number;
  /** المفروض يكون في الدرج */
  expectedCash: number;
  /** تفصيل حركات الدرج اليدوية */
  moves: { date: string; amount: number; reason: string | null }[];
}

const ZERO: Record<PayMethod, number> = { cash: 0, card: 0, wallet: 0, credit: 0 };

export async function shiftReport(shiftId: number): Promise<ShiftReport> {
  const shift = await queryOne<Shift>(
    `SELECT s.*, u.full_name AS user_name
       FROM shifts s LEFT JOIN users u ON u.id = s.user_id WHERE s.id = ?`,
    [shiftId]
  );
  if (!shift) throw new Error("الوردية غير موجودة");

  // تقرير Z مستند مالي تاريخي: بمجرد إغلاق الوردية نعيد اللقطة المعتمدة ولا
  // نعيد حسابها من فواتير أو مرتجعات قد تُسجّل في ورديات لاحقة.
  if (shift.status === "closed" && shift.z_report_json) {
    try {
      const snapshot = JSON.parse(shift.z_report_json) as Omit<ShiftReport, "shift">;
      return { ...snapshot, shift };
    } catch {
      // قواعد قديمة سبقت تخزين اللقطة: نكمل بالحساب الحي المتوافق معها.
    }
  }

  const head = await queryOne<{ n: number; total: number }>(
    `SELECT COUNT(*) AS n, COALESCE(SUM(total),0) AS total
       FROM sales WHERE shift_id = ? AND document_state <> 'void'`,
    [shiftId]
  );

  const methodRows = await query<{ method: PayMethod; amount: number }>(
    `SELECT sp.method, COALESCE(SUM(sp.amount),0) AS amount
       FROM sale_payments sp JOIN sales s ON s.id = sp.sale_id
      WHERE s.shift_id = ? AND s.document_state <> 'void'
      GROUP BY sp.method`,
    [shiftId]
  );
  const byMethod = { ...ZERO };
  for (const r of methodRows) byMethod[r.method] = round2(r.amount);

  // مرتجع بيع من غير عميل = فلوس خرجت من الدرج كاش
  const refunds = await queryOne<{ cash: number; credit: number; purchase_cash: number }>(
    `SELECT
       COALESCE(SUM(CASE WHEN r.type='sale' AND r.settlement_method='cash_refund'
                         THEN r.total ELSE 0 END),0) AS cash,
       COALESCE(SUM(CASE WHEN r.type='sale' AND r.settlement_method IN ('reduce_receivable','customer_credit')
                         THEN r.total ELSE 0 END),0) AS credit,
       COALESCE(SUM(CASE WHEN r.type='purchase' AND r.settlement_method='cash_refund'
                         THEN r.total ELSE 0 END),0) AS purchase_cash
       FROM returns r WHERE r.shift_id = ?`,
    [shiftId]
  );

  const pay = await query<{ direction: string; method: string; amount: number }>(
    `SELECT direction, COALESCE(method,'cash') AS method, COALESCE(SUM(amount),0) AS amount
       FROM payments
      WHERE shift_id = ? AND (source IS NULL OR source NOT IN ('sale','return'))
      GROUP BY direction, method`,
    [shiftId]
  );
  const collections = { cash: 0, other: 0 };
  const supplierPaid = { cash: 0, other: 0 };
  for (const r of pay) {
    const bucket = r.direction === "in" ? collections : supplierPaid;
    if (r.method === "cash") bucket.cash = round2(bucket.cash + n2(r.amount));
    else bucket.other = round2(bucket.other + n2(r.amount));
  }

  const exp = await queryOne<{ total: number }>(
    `SELECT COALESCE(SUM(amount),0) AS total FROM expenses
      WHERE shift_id = ? AND status='posted' AND payment_method='cash'`,
    [shiftId]
  );

  const moves = await query<{ date: string; amount: number; reason: string | null }>(
    `SELECT date, amount, reason FROM shift_cash WHERE shift_id = ? ORDER BY id`,
    [shiftId]
  );
  const cashIn = round2(
    moves.filter((m) => n2(m.amount) > 0).reduce((s, m) => s + n2(m.amount), 0)
  );
  const cashOut = round2(
    moves.filter((m) => n2(m.amount) < 0).reduce((s, m) => s - n2(m.amount), 0)
  );

  const expectedCash = round2(
    n2(shift.opening_cash) +
      byMethod.cash +
      collections.cash +
      n2(refunds?.purchase_cash) +
      cashIn -
      n2(refunds?.cash) -
      supplierPaid.cash -
      n2(exp?.total) -
      cashOut
  );

  return {
    shift,
    invoices: Number(head?.n || 0),
    salesTotal: round2(n2(head?.total)),
    byMethod,
    cashRefunds: round2(n2(refunds?.cash)),
    purchaseRefunds: round2(n2(refunds?.purchase_cash)),
    creditRefunds: round2(n2(refunds?.credit)),
    collections,
    supplierPaid,
    expenses: round2(n2(exp?.total)),
    cashIn,
    cashOut,
    expectedCash,
    moves,
  };
}

/** تقفيل الوردية — بيتحسب المفروض في الدرج وبيتسجّل الفرق */
export async function closeShift(
  shiftId: number,
  countedCash: number,
  notes?: string,
  userId: number | null = null
): Promise<ShiftReport> {
  const rep = await shiftReport(shiftId);
  if (rep.shift.status !== "open") throw new Error("الوردية دي مقفولة بالفعل");

  const counted = round2(countedCash);
  const diff = round2(counted - rep.expectedCash);
  if (Math.abs(diff) > 0.009 && !notes?.trim())
    throw new Error("يوجد فرق في الدرج؛ اكتب سبب العجز أو الزيادة قبل الإغلاق");
  const zNumber = `Z-${String(shiftId).padStart(6, "0")}`;
  const { shift: _openShift, ...reportSnapshot } = rep;
  const zReportJson = JSON.stringify(reportSnapshot);

  const ops: Op[] = [
    {
      sql: `UPDATE shifts SET closed_at = datetime('now','localtime'), status='closed',
              expected_cash = ?, counted_cash = ?, diff = ?,
              notes = CASE WHEN ? <> '' THEN COALESCE(notes || ' | ','') || ? ELSE notes END,
              close_reason=?,closed_by=?,z_number=COALESCE(z_number,?)
              ,z_report_json=?
            WHERE id = ?`,
      params: [
        rep.expectedCash,
        counted,
        diff,
        notes?.trim() || "",
        notes?.trim() || "",
        notes?.trim() || null,
        userId,
        zNumber,
        zReportJson,
        shiftId,
      ],
    },
    {
      sql: `INSERT INTO audit_log(user_id,action,entity_type,entity_id,new_values,reason)
            VALUES(?,'shift_closed','shift',?,?,?)`,
      params: [
        userId,
        shiftId,
        JSON.stringify({ expected_cash: rep.expectedCash, counted_cash: counted, difference: diff }),
        notes?.trim() || null,
      ],
    },
  ];
  await batch(ops, "shifts_close");

  // نقرا التقرير تاني عشان وقت التقفيل يطلع من قاعدة البيانات نفسها
  return shiftReport(shiftId);
}
