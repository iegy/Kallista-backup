// db.ts — الجسر بين الواجهة وقاعدة البيانات
// داخل البرنامج (Tauri) بيستخدم أوامر Rust.
// في المتصفح أثناء التطوير بيستخدم نسخة SQLite تعمل في الذاكرة عشان المعاينة فقط.

import { invoke } from "@tauri-apps/api/core";

export type Row = Record<string, any>;
export type Param = string | number | boolean | null;
export interface ExecResult {
  rows_affected: number;
  last_insert_id: number;
}
export interface Op {
  sql: string;
  params?: Param[];
}

let activeSessionToken: string | null = null;

export function setSessionToken(token: string | null) {
  activeSessionToken = token;
}

export function sessionToken(): string {
  if (!activeSessionToken) throw new Error("انتهت جلسة الدخول — سجّل الدخول مرة أخرى");
  return activeSessionToken;
}

export const isTauri = (): boolean =>
  typeof window !== "undefined" && "__TAURI_INTERNALS__" in window;

/* ---------- نسخة المعاينة في المتصفح (تُحذف تلقائيًا من نسخة الإنتاج) ---------- */
let devApi: any = null;
async function dev() {
  if (!devApi) devApi = await import("./devdb");
  return devApi;
}

/* ---------- الواجهة العامة ---------- */

export async function query<T = Row>(
  sql: string,
  params: Param[] = []
): Promise<T[]> {
  if (isTauri())
    return invoke<T[]>("db_query", { sql, params, sessionToken: activeSessionToken });
  if (import.meta.env.DEV) return (await dev()).devQuery(sql, params);
  throw new Error("قاعدة البيانات غير متاحة");
}

export async function queryOne<T = Row>(
  sql: string,
  params: Param[] = []
): Promise<T | null> {
  const rows = await query<T>(sql, params);
  return rows.length ? rows[0] : null;
}

export async function execute(
  sql: string,
  params: Param[] = []
): Promise<ExecResult> {
  if (isTauri())
    return invoke<ExecResult>("db_execute", { sql, params, sessionToken: activeSessionToken });
  if (import.meta.env.DEV) return (await dev()).devExecute(sql, params);
  throw new Error("قاعدة البيانات غير متاحة");
}

/** تنفيذ عدة عمليات في معاملة واحدة. يمكن استخدام "$LAST_ID" في المعاملات. */
export async function batch(ops: Op[], permission?: string): Promise<number[]> {
  const norm = ops.map((o) => ({ sql: o.sql, params: o.params ?? [] }));
  if (isTauri())
    return invoke<number[]>("db_batch", {
      ops: norm,
      sessionToken: activeSessionToken,
      permission: permission ?? null,
    });
  if (import.meta.env.DEV) return (await dev()).devBatch(norm);
  throw new Error("قاعدة البيانات غير متاحة");
}

export interface AppInfo {
  name: string;
  version: string;
  developer: string;
  phone: string;
  email: string;
  db_path: string;
  app_dir: string;
  portable: boolean;
}

export async function appInfo(): Promise<AppInfo> {
  if (isTauri()) return invoke<AppInfo>("app_info");
  return {
    name: "NewShop",
    version: "2.0.0",
    developer: "محمد حسين",
    phone: "01000220606",
    email: "egyup@outlook.com",
    db_path: "%APPDATA%\\NewShop\\newshop.db",
    app_dir: "%APPDATA%\\NewShop",
    portable: false,
  };
}
