// reports.ts — كل استعلامات التقارير في مكان واحد.
// كل الأرقام بتراعي: الفواتير الملغية مستبعدة، والمرتجعات مخصومة من الإيراد ومن التكلفة،
// وتكلفة البضاعة المباعة بتتاخد من `cost_at_sale` (التكلفة وقت البيع) مش التكلفة الحالية.

import { query, queryOne } from "./db";
import { n2 } from "./format";

export interface Range {
  from: string;
  to: string;
}

const r2 = (x: number) => Math.round((n2(x) + Number.EPSILON) * 100) / 100;

/* ================= الملخص والأرباح والخسائر ================= */

export interface PnL {
  invoices: number;
  grossSales: number; // إجمالي الفواتير قبل خصم المرتجعات
  salesDiscount: number;
  salesReturns: number;
  netSales: number;
  cogs: number; // تكلفة البضاعة المباعة (بعد خصم تكلفة المرتجعات)
  grossProfit: number;
  expenses: number;
  netProfit: number;
  purchases: number;
  purchaseReturns: number;
}

export async function profitAndLoss(r: Range): Promise<PnL> {
  const p = [r.from, r.to];

  const a = await queryOne<any>(
    `SELECT COUNT(*) AS invoices,
            COALESCE(SUM((total-tax)+discount),0) AS gross,
            COALESCE(SUM(total-tax),0) AS total,
            COALESCE(SUM(discount),0) AS disc
       FROM sales WHERE document_state<>'void' AND date(date) BETWEEN ? AND ?`,
    p
  );
  const b = await queryOne<any>(
    `SELECT COALESCE(SUM(si.qty * si.cost_at_sale),0) AS cogs
       FROM sale_items si JOIN sales s ON s.id = si.sale_id
      WHERE s.document_state<>'void' AND date(s.date) BETWEEN ? AND ?`,
    p
  );
  const c = await queryOne<any>(
    `SELECT COALESCE(SUM(r.total-COALESCE((SELECT SUM(ri.tax_amount)
              FROM return_items ri WHERE ri.return_id=r.id),0)),0) AS t FROM returns r
      WHERE type='sale' AND status='posted' AND date(date) BETWEEN ? AND ?`,
    p
  );
  const d = await queryOne<any>(
    `SELECT COALESCE(SUM(ri.qty * ri.cost_at_sale),0) AS c
       FROM return_items ri JOIN returns r ON r.id=ri.return_id
      WHERE r.type='sale' AND r.status='posted' AND date(r.date) BETWEEN ? AND ?`,
    p
  );
  const e = await queryOne<any>(
    `SELECT COALESCE(SUM(amount),0) AS t FROM expenses
      WHERE status='posted' AND date(date) BETWEEN ? AND ?`,
    p
  );
  const f = await queryOne<any>(
    `SELECT COALESCE(SUM(total),0) AS t FROM purchases
      WHERE status='active' AND date(date) BETWEEN ? AND ?`,
    p
  );
  const g = await queryOne<any>(
    `SELECT COALESCE(SUM(total),0) AS t FROM returns
      WHERE type='purchase' AND status='posted' AND date(date) BETWEEN ? AND ?`,
    p
  );

  const grossSales = n2(a?.gross);
  const salesReturns = n2(c?.t);
  const netSales = r2(n2(a?.total) - salesReturns);
  const cogs = r2(n2(b?.cogs) - n2(d?.c));
  const grossProfit = r2(netSales - cogs);
  const expenses = n2(e?.t);

  return {
    invoices: Number(a?.invoices || 0),
    grossSales: r2(grossSales),
    salesDiscount: r2(n2(a?.disc)),
    salesReturns: r2(salesReturns),
    netSales,
    cogs,
    grossProfit,
    expenses: r2(expenses),
    netProfit: r2(grossProfit - expenses),
    purchases: r2(n2(f?.t)),
    purchaseReturns: r2(n2(g?.t)),
  };
}

/* ================= تقارير المبيعات ================= */

/** المبيعات يوم بيوم */
export function salesDaily(r: Range) {
  return query<any>(
    `SELECT date(date) AS day,
            COUNT(*) AS invoices,
            COALESCE(SUM(total-tax),0) AS total,
            COALESCE(SUM(discount),0) AS discount,
            COALESCE(SUM(paid),0) AS paid,
            COALESCE(SUM(remaining),0) AS remaining,
            (SELECT COALESCE(SUM(si.qty * si.cost_at_sale),0)
               FROM sale_items si JOIN sales s2 ON s2.id = si.sale_id
              WHERE s2.document_state<>'void' AND date(s2.date) = date(sales.date)) AS cogs
       FROM sales
      WHERE document_state<>'void' AND date(date) BETWEEN ? AND ?
      GROUP BY date(date) ORDER BY day DESC`,
    [r.from, r.to]
  );
}

/** المبيعات بالصنف */
export function salesByProduct(r: Range) {
  return query<any>(
    `SELECT COALESCE(MAX(si.product_name_snapshot),p.name,'صنف محذوف') AS name,
            COALESCE(MAX(si.code_snapshot),p.code,'') AS code,
            COALESCE(MAX(si.unit_snapshot),p.unit,'') AS unit,
            COALESCE(SUM(si.qty-COALESCE(rr.returned_qty,0)),0) AS qty,
            COALESCE(SUM((si.line_net_total-si.tax_amount)-COALESCE(rr.returned_net,0)),0) AS total,
            COALESCE(SUM((si.qty-COALESCE(rr.returned_qty,0))*si.cost_at_sale),0) AS cost,
            COALESCE(SUM(((si.line_net_total-si.tax_amount)-COALESCE(rr.returned_net,0))-
              (si.qty-COALESCE(rr.returned_qty,0))*si.cost_at_sale),0) AS profit
       FROM sale_items si
       JOIN sales s ON s.id = si.sale_id
       LEFT JOIN products p ON p.id = si.product_id
       LEFT JOIN (
         SELECT ri.source_item_id,SUM(ri.qty) AS returned_qty,
                SUM(ri.total-ri.tax_amount) AS returned_net
           FROM return_items ri JOIN returns r ON r.id=ri.return_id
          WHERE r.type='sale' AND r.status='posted' GROUP BY ri.source_item_id
       ) rr ON rr.source_item_id=si.id
      WHERE s.document_state<>'void' AND date(s.date) BETWEEN ? AND ?
      GROUP BY si.product_id ORDER BY total DESC`,
    [r.from, r.to]
  );
}

/** المبيعات بالعميل */
export function salesByCustomer(r: Range) {
  return query<any>(
    `SELECT COALESCE(c.name,'عميل نقدي') AS name,
            COUNT(*) AS invoices,
            COALESCE(SUM(s.total),0) AS total,
            COALESCE(SUM(s.paid),0) AS paid,
            COALESCE(SUM(s.remaining),0) AS remaining
       FROM sales s LEFT JOIN customers c ON c.id = s.customer_id
      WHERE s.document_state<>'void' AND date(s.date) BETWEEN ? AND ?
      GROUP BY s.customer_id ORDER BY total DESC`,
    [r.from, r.to]
  );
}

/** المبيعات بالمستخدم (الكاشير) */
export function salesByUser(r: Range) {
  return query<any>(
    `SELECT COALESCE(u.full_name, u.username, 'غير محدد') AS name,
            COUNT(*) AS invoices,
            COALESCE(SUM(s.total),0) AS total,
            COALESCE(SUM(s.discount),0) AS discount
       FROM sales s LEFT JOIN users u ON u.id = s.user_id
      WHERE s.document_state<>'void' AND date(s.date) BETWEEN ? AND ?
      GROUP BY s.user_id ORDER BY total DESC`,
    [r.from, r.to]
  );
}

/* ================= تقارير المخزون ================= */

/** الأرصدة الحالية وتقييم المخزن */
export function stockBalances() {
  return query<any>(
    `SELECT p.code, p.name, COALESCE(c.name,'—') AS category, p.unit,
            p.qty, p.min_qty, p.cost_price, p.sell_price,
            (p.qty * p.cost_price) AS cost_value,
            (p.qty * p.sell_price) AS sell_value
       FROM products p LEFT JOIN categories c ON c.id = p.category_id
      WHERE p.is_active = 1
      ORDER BY cost_value DESC`
  );
}

/** الأصناف الناقصة */
export function lowStock() {
  return query<any>(
    `SELECT p.code, p.name, p.unit, p.qty, p.min_qty,
            (p.min_qty - p.qty) AS shortage, p.cost_price
       FROM products p
      WHERE p.is_active = 1 AND p.qty <= p.min_qty
      ORDER BY shortage DESC`
  );
}

/** الأصناف الراكدة: مفيش عليها بيع من كذا يوم */
export async function deadStock(days: number) {
  const rows = await query<any>(
    `SELECT p.code, p.name, p.unit, p.qty, p.cost_price,
            (p.qty * p.cost_price) AS value,
            (SELECT MAX(s.date) FROM sale_items si JOIN sales s ON s.id = si.sale_id
              WHERE si.product_id = p.id AND s.document_state<>'void') AS last_sale
       FROM products p WHERE p.is_active = 1 AND p.qty > 0`
  );
  const now = Date.now();
  return rows
    .map((r) => {
      const t = r.last_sale ? new Date(String(r.last_sale).replace(" ", "T")).getTime() : null;
      const since = t ? Math.floor((now - t) / 86400000) : null;
      return { ...r, days_since: since, last_sale_text: r.last_sale || "لم يُبع أبدًا" };
    })
    .filter((r) => r.days_since === null || r.days_since >= days)
    .sort((a, b) => n2(b.value) - n2(a.value));
}

/* ================= المديونيات ================= */

export function customerDues() {
  return query<any>(
    `SELECT name, phone, balance FROM customers WHERE balance > 0.009 ORDER BY balance DESC`
  );
}

export function supplierDues() {
  return query<any>(
    `SELECT name, phone, balance FROM suppliers WHERE balance > 0.009 ORDER BY balance DESC`
  );
}

/* ================= المصروفات ================= */

export function expensesByCategory(r: Range) {
  return query<any>(
    `SELECT COALESCE(NULLIF(TRIM(category),''),'غير مصنّف') AS category,
            COUNT(*) AS count, COALESCE(SUM(amount),0) AS total
       FROM expenses WHERE date(date) BETWEEN ? AND ?
      GROUP BY category ORDER BY total DESC`,
    [r.from, r.to]
  );
}

/* ================= التنبيهات ================= */

export interface OverdueCustomer {
  id: number;
  name: string;
  phone: string | null;
  balance: number;
  last_activity: string | null;
  days: number | null;
}

/** عملاء عليهم فلوس ومافيش منهم حركة من أكتر من كذا يوم */
export async function overdueCustomers(days: number): Promise<OverdueCustomer[]> {
  const rows = await query<any>(
    `SELECT c.id, c.name, c.phone, c.balance,
            MAX(
              COALESCE((SELECT MAX(p.date) FROM payments p
                         WHERE p.party_type='customer' AND p.party_id = c.id
                           AND p.direction='in'), '0000'),
              COALESCE((SELECT MAX(s.date) FROM sales s
                         WHERE s.customer_id = c.id AND s.document_state<>'void'), '0000')
            ) AS last_activity
       FROM customers c
      WHERE c.balance > 0.009`
  );
  const now = Date.now();
  return rows
    .map((r) => {
      const raw = r.last_activity && r.last_activity !== "0000" ? r.last_activity : null;
      const t = raw ? new Date(String(raw).replace(" ", "T")).getTime() : null;
      return {
        ...r,
        last_activity: raw,
        days: t ? Math.floor((now - t) / 86400000) : null,
      } as OverdueCustomer;
    })
    .filter((r) => r.days === null || r.days >= days)
    .sort((a, b) => n2(b.balance) - n2(a.balance));
}

export interface AlertSummary {
  /** أصناف خلصت تمامًا */
  outOfStock: { name: string; unit: string }[];
  /** أصناف قربت تخلص (وصلت الحد الأدنى) */
  lowStock: { name: string; unit: string; qty: number; min_qty: number }[];
  /** عملاء متأخرين في السداد */
  overdue: OverdueCustomer[];
  /** أصناف راكدة وقيمة الفلوس الواقفة فيها */
  dead: { count: number; value: number };
  /** وردية مفتوحة من أكتر من ١٢ ساعة */
  staleShift: { id: number; hours: number } | null;
}

export async function alerts(opts: {
  dueDays: number;
  staleDays: number;
}): Promise<AlertSummary> {
  const low = await lowStock();
  const dead = await deadStock(opts.staleDays);
  const overdue = await overdueCustomers(opts.dueDays);

  const shiftRow = await query<any>(
    `SELECT id, opened_at FROM shifts WHERE status='open' ORDER BY id DESC LIMIT 1`
  );
  let staleShift: AlertSummary["staleShift"] = null;
  if (shiftRow[0]) {
    const t = new Date(String(shiftRow[0].opened_at).replace(" ", "T")).getTime();
    const hours = Math.floor((Date.now() - t) / 3600000);
    if (hours >= 12) staleShift = { id: Number(shiftRow[0].id), hours };
  }

  return {
    outOfStock: low.filter((r) => n2(r.qty) <= 0).map((r) => ({ name: r.name, unit: r.unit })),
    lowStock: low
      .filter((r) => n2(r.qty) > 0)
      .map((r) => ({ name: r.name, unit: r.unit, qty: n2(r.qty), min_qty: n2(r.min_qty) })),
    overdue,
    dead: {
      count: dead.length,
      value: dead.reduce((s, r) => s + n2(r.value), 0),
    },
    staleShift,
  };
}
