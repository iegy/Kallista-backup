// بديل فارغ لملف المعاينة — يستبدله Vite في نسخة الإنتاج
// عشان مكتبة sql.js ما تدخلش في حجم البرنامج النهائي.
const err = () => {
  throw new Error("قاعدة البيانات غير متاحة");
};
export const devQuery = err;
export const devExecute = err;
export const devBatch = err;
