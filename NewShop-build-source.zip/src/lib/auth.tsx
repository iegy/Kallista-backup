// auth.tsx — المستخدمين والصلاحيات
import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useState,
  type ReactNode,
} from "react";
import { invoke } from "@tauri-apps/api/core";
import { execute, isTauri, queryOne, setSessionToken, sessionToken } from "./db";

/* ---------------- الصلاحيات ---------------- */

export const PERMS: { key: string; label: string; group: string }[] = [
  { key: "sales_view", label: "عرض المبيعات", group: "البيع" },
  { key: "sales_create", label: "إنشاء فاتورة بيع", group: "البيع" },
  { key: "invoices_cancel", label: "إلغاء الفواتير", group: "البيع" },
  { key: "sales_return", label: "مرتجع بيع", group: "البيع" },
  { key: "sales_reprint", label: "إعادة طباعة فاتورة", group: "البيع" },
  { key: "discount_line", label: "خصم على صنف", group: "البيع" },
  { key: "discount_invoice", label: "خصم على الفاتورة", group: "البيع" },
  { key: "shifts", label: "الورديات وتقفيل الدرج", group: "البيع" },
  { key: "shifts_open", label: "فتح وردية", group: "البيع" },
  { key: "shifts_close", label: "إغلاق وردية", group: "البيع" },
  { key: "edit_prices", label: "تعديل الأسعار وقت البيع", group: "البيع" },
  {
    key: "override_stock",
    label: "البيع بكمية أكبر من المتاح في المخزن",
    group: "البيع",
  },
  { key: "products", label: "الأصناف والتصنيفات", group: "المخزن" },
  { key: "products_edit", label: "تعديل الأصناف", group: "المخزن" },
  { key: "stock_adjust", label: "تسوية المخزون", group: "المخزن" },
  { key: "purchases", label: "المشتريات والموردين", group: "المخزن" },
  { key: "purchase_return", label: "مرتجع شراء", group: "المخزن" },
  { key: "stocktake", label: "الجرد", group: "المخزن" },
  { key: "labels", label: "ملصقات الباركود", group: "المخزن" },
  { key: "import", label: "استيراد من إكسل", group: "المخزن" },
  { key: "customers", label: "العملاء والتحصيلات", group: "الحسابات" },
  { key: "customer_receipts", label: "تحصيلات العملاء", group: "الحسابات" },
  { key: "suppliers", label: "عرض الموردين", group: "الحسابات" },
  { key: "supplier_payments", label: "مدفوعات الموردين", group: "الحسابات" },
  { key: "expenses", label: "المصروفات", group: "الحسابات" },
  { key: "reports", label: "التقارير", group: "الحسابات" },
  { key: "view_profits", label: "عرض الأرباح والتكاليف", group: "الحسابات" },
  { key: "view_cost", label: "عرض تكلفة الأصناف", group: "الحسابات" },
  { key: "settings", label: "الإعدادات", group: "النظام" },
  { key: "backup", label: "النسخ الاحتياطي والاسترجاع", group: "النظام" },
  { key: "restore", label: "استرجاع نسخة احتياطية", group: "النظام" },
  { key: "users", label: "المستخدمين والصلاحيات", group: "النظام" },
  { key: "license_info", label: "عرض معلومات الترخيص", group: "النظام" },
];

export const ALL_PERMS = PERMS.map((p) => p.key);

/** الصلاحيات الافتراضية للكاشير */
export const CASHIER_PERMS = [
  "sales_view",
  "sales_create",
  "customers",
  "products",
  "shifts",
  "shifts_open",
];

export interface User {
  id: number;
  username: string;
  full_name: string | null;
  role: "owner" | "admin" | "cashier";
  permissions: string[];
  is_active: number;
  max_line_discount: number;
  max_invoice_discount: number;
}

/* ---------------- تشفير كلمة السر ---------------- */
// داخل البرنامج: Argon2 في Rust.
// في معاينة المتصفح بس: صيغة بسيطة عشان الشاشات تشتغل للعرض.

export async function hashPassword(pw: string): Promise<string> {
  if (isTauri()) return invoke<string>("hash_password", { password: pw });
  return `dev:${pw}`;
}

export async function verifyPassword(pw: string, hash: string): Promise<boolean> {
  if (!hash) return false;
  if (isTauri()) return invoke<boolean>("verify_password", { password: pw, hash });
  return hash === `dev:${pw}`;
}

/* ---------------- موافقة المدير ---------------- */

/**
 * بيتأكد إن اسم مستخدم + كلمة سر بتاعت حد **عنده الصلاحية دي**، من غير ما
 * يغيّر المستخدم الحالي. بنستخدمها لما الكاشير يحتاج موافقة مدير على عملية
 * (زي البيع بكمية أكبر من المخزون).
 *
 * بترجّع المستخدم الموافق عشان نسجّل اسمه في سجل النشاط.
 */
export async function approveByManager(
  perm: string,
  username: string,
  password: string
): Promise<User> {
  if (isTauri()) {
    const approver = await invoke<{ id: number; username: string; full_name: string | null }>(
      "manager_approve",
      {
        sessionToken: sessionToken(),
        permission: perm,
        username: username.trim(),
        pinOrPassword: password,
        action: `manager_override_${perm}`,
        reason: `موافقة مدير على صلاحية ${perm}`,
      }
    );
    return {
      ...approver,
      role: "admin",
      permissions: [perm],
      is_active: 1,
      max_line_discount: 100,
      max_invoice_discount: 100,
    };
  }
  const u = username.trim();
  if (!u) throw new Error("اكتب اسم المستخدم");
  const row = await queryOne<any>(
    `SELECT * FROM users WHERE username = ? AND is_active = 1`,
    [u]
  );
  // نفس الرسالة في الحالتين عشان محدش يعرف الأسماء الموجودة بالتخمين
  if (!row) throw new Error("اسم المستخدم أو كلمة السر غلط");
  if (!(await verifyPassword(password, row.password_hash)))
    throw new Error("اسم المستخدم أو كلمة السر غلط");

  const approver = parseUser(row);
  const allowed =
    approver.role === "owner" || approver.role === "admin" || approver.permissions.includes(perm);
  if (!allowed) throw new Error("المستخدم ده معندوش صلاحية الموافقة على العملية دي");
  return approver;
}

/* ---------------- السياق ---------------- */

interface Ctx {
  user: User | null;
  needsSetup: boolean;
  checking: boolean;
  login: (username: string, password: string) => Promise<void>;
  logout: () => void;
  createFirstAdmin: (username: string, fullName: string, password: string) => Promise<void>;
  can: (perm: string) => boolean;
  refresh: () => Promise<void>;
}

const AuthCtx = createContext<Ctx | null>(null);

export function useAuth(): Ctx {
  const c = useContext(AuthCtx);
  if (!c) throw new Error("useAuth خارج AuthProvider");
  return c;
}

function parseUser(r: any): User {
  let perms: string[] = [];
  try {
    const p = r.permissions ? JSON.parse(r.permissions) : [];
    if (Array.isArray(p)) perms = p;
  } catch {
    perms = [];
  }
  return {
    id: Number(r.id),
    username: r.username,
    full_name: r.full_name,
    role: r.role === "owner" ? "owner" : r.role === "admin" ? "admin" : "cashier",
    permissions: perms,
    is_active: Number(r.is_active ?? 1),
    max_line_discount: Number(r.max_line_discount ?? 10),
    max_invoice_discount: Number(r.max_invoice_discount ?? 10),
  };
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [needsSetup, setNeedsSetup] = useState(false);
  const [checking, setChecking] = useState(true);

  const refresh = useCallback(async () => {
    if (isTauri()) {
      setNeedsSetup(await invoke<boolean>("auth_needs_setup"));
    } else {
      const row = await queryOne<any>(`SELECT COUNT(*) AS n FROM users WHERE is_active = 1`);
      setNeedsSetup(Number(row?.n || 0) === 0);
    }
  }, []);

  useEffect(() => {
    refresh()
      .catch(() => setNeedsSetup(true))
      .finally(() => setChecking(false));
  }, [refresh]);

  const login = useCallback(async (username: string, password: string) => {
    const u = username.trim();
    if (!u) throw new Error("اكتب اسم المستخدم");
    if (isTauri()) {
      const result = await invoke<{ session_token: string; user: User }>("auth_login", {
        username: u,
        password,
      });
      setSessionToken(result.session_token);
      setUser(parseUser(result.user));
      return;
    }
    const row = await queryOne<any>(
      `SELECT * FROM users WHERE username = ? AND is_active = 1`,
      [u]
    );
    if (!row) throw new Error("اسم المستخدم أو كلمة السر غلط");
    if (!(await verifyPassword(password, row.password_hash)))
      throw new Error("اسم المستخدم أو كلمة السر غلط");

    await execute(
      `INSERT INTO activity_log(user_id, action, details) VALUES(?, 'login', ?)`,
      [row.id, `دخول ${row.username}`]
    );
    setUser(parseUser(row));
  }, []);

  const logout = useCallback(() => {
    if (isTauri()) {
      try {
        const token = sessionToken();
        void invoke("auth_logout", { sessionToken: token });
      } catch {
        // الجلسة منتهية بالفعل
      }
    }
    setSessionToken(null);
    setUser(null);
  }, []);

  const createFirstAdmin = useCallback(
    async (username: string, fullName: string, password: string) => {
      const u = username.trim();
      if (!u) throw new Error("اكتب اسم المستخدم");
      if (password.length < 8) throw new Error("كلمة السر يجب ألا تقل عن ٨ أحرف");
      if (isTauri()) {
        await invoke("auth_create_owner", {
          username: u,
          fullName: fullName.trim() || "المالك",
          password,
        });
      } else {
        const hash = await hashPassword(password);
        await execute(
          `INSERT INTO users(username, password_hash, full_name, role, permissions, is_active,
                             max_line_discount,max_invoice_discount)
           VALUES(?,?,?,'owner',?,1,100,100)`,
          [u, hash, fullName.trim() || "المالك", JSON.stringify(ALL_PERMS)]
        );
      }
      setNeedsSetup(false);
      await login(u, password);
    },
    [login]
  );

  const can = useCallback(
    (perm: string) => {
      if (!user) return false;
      if (user.role === "owner" || user.role === "admin") return true;
      if (user.permissions.includes(perm)) return true;
      // توافق صلاحيات قواعد v1.1 عند أول ترقية.
      if ((perm === "sales_view" || perm === "sales_create") && user.permissions.includes("sales"))
        return true;
      if (perm === "sales_return" && user.permissions.includes("returns")) return true;
      return false;
    },
    [user]
  );

  return (
    <AuthCtx.Provider
      value={{ user, needsSetup, checking, login, logout, createFirstAdmin, can, refresh }}
    >
      {children}
    </AuthCtx.Provider>
  );
}
