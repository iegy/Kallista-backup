// xlsxread.ts — قراءة ملفات إكسل (.xlsx) و CSV بدون أي مكتبة خارجية
//
// ملف الإكسل في الأصل ملف ZIP جوّاه ملفات XML. اللي بيهمنا منها:
//   xl/workbook.xml        → أسماء الشيتات وترتيبها
//   xl/sharedStrings.xml   → كل النصوص المتكررة في مكان واحد
//   xl/worksheets/sheet*.xml → الخلايا نفسها
//
// بنستخدم fflate (موجودة أصلًا في المشروع لكتابة الإكسل) لفك الضغط.

import { unzipSync, strFromU8 } from "fflate";

export interface SheetData {
  name: string;
  /** الصفوف كنصوص — أول صف عادةً هو العناوين */
  rows: string[][];
}

/* ---------------- أدوات XML بسيطة ---------------- */

function decodeEntities(s: string): string {
  return s
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&#(\d+);/g, (_, d) => String.fromCodePoint(Number(d)))
    .replace(/&#x([0-9a-fA-F]+);/g, (_, h) => String.fromCodePoint(parseInt(h, 16)))
    .replace(/&amp;/g, "&");
}

/** بيجمع نص كل عناصر <t> جوه قطعة XML (الخلية ممكن تكون مقسّمة لأجزاء) */
function textOf(xml: string): string {
  let out = "";
  const re = /<t[^>]*>([\s\S]*?)<\/t>/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(xml))) out += m[1];
  return decodeEntities(out);
}

/** A1 → عمود رقم 0 */
export function colIndex(ref: string): number {
  const letters = ref.replace(/\d+/g, "").toUpperCase();
  let n = 0;
  for (const ch of letters) n = n * 26 + (ch.charCodeAt(0) - 64);
  return n - 1;
}

/* ---------------- قراءة xlsx ---------------- */

export function readXlsx(data: Uint8Array): SheetData[] {
  let files: Record<string, Uint8Array>;
  try {
    files = unzipSync(data);
  } catch {
    throw new Error("الملف مش ملف إكسل سليم");
  }

  const get = (path: string) => (files[path] ? strFromU8(files[path]) : "");

  // النصوص المشتركة
  const shared: string[] = [];
  const ss = get("xl/sharedStrings.xml");
  if (ss) {
    const re = /<si[^>]*>([\s\S]*?)<\/si>/g;
    let m: RegExpExecArray | null;
    while ((m = re.exec(ss))) shared.push(textOf(m[1]));
  }

  // أسماء الشيتات بالترتيب
  const wb = get("xl/workbook.xml");
  const names: string[] = [];
  const nameRe = /<sheet[^>]*name="([^"]*)"/g;
  let nm: RegExpExecArray | null;
  while ((nm = nameRe.exec(wb))) names.push(decodeEntities(nm[1]));

  // ملفات الشيتات مرتّبة برقمها
  const sheetPaths = Object.keys(files)
    .filter((k) => /^xl\/worksheets\/sheet\d+\.xml$/.test(k))
    .sort((a, b) => {
      const n = (x: string) => Number(x.match(/sheet(\d+)\.xml$/)![1]);
      return n(a) - n(b);
    });

  if (!sheetPaths.length) throw new Error("مفيش أي شيت في الملف");

  return sheetPaths.map((path, i) => ({
    name: names[i] || `شيت ${i + 1}`,
    rows: parseSheet(get(path), shared),
  }));
}

function parseSheet(xml: string, shared: string[]): string[][] {
  const rows: string[][] = [];
  const rowRe = /<row[^>]*>([\s\S]*?)<\/row>/g;
  let rm: RegExpExecArray | null;

  while ((rm = rowRe.exec(xml))) {
    const cells: string[] = [];
    const cellRe = /<c([^>]*)(?:\/>|>([\s\S]*?)<\/c>)/g;
    let cm: RegExpExecArray | null;

    while ((cm = cellRe.exec(rm[1]))) {
      const attrs = cm[1] || "";
      const inner = cm[2] || "";
      const ref = /r="([A-Z]+\d+)"/.exec(attrs)?.[1];
      const type = /t="([^"]+)"/.exec(attrs)?.[1] || "n";

      let value = "";
      if (type === "s") {
        const idx = Number(/<v>([\s\S]*?)<\/v>/.exec(inner)?.[1] ?? -1);
        value = shared[idx] ?? "";
      } else if (type === "inlineStr") {
        value = textOf(inner);
      } else if (type === "str") {
        value = decodeEntities(/<v>([\s\S]*?)<\/v>/.exec(inner)?.[1] ?? "");
      } else {
        value = decodeEntities(/<v>([\s\S]*?)<\/v>/.exec(inner)?.[1] ?? "");
      }

      const at = ref ? colIndex(ref) : cells.length;
      while (cells.length < at) cells.push("");
      cells[at] = value.trim();
    }
    rows.push(cells);
  }

  // نشيل الصفوف الفاضية من الآخر
  while (rows.length && rows[rows.length - 1].every((c) => !c)) rows.pop();
  return rows;
}

/* ---------------- قراءة CSV ---------------- */

/** بيخمّن الفاصل: فاصلة، فاصلة منقوطة، أو تاب */
export function guessDelimiter(text: string): string {
  const head = text.split(/\r?\n/).slice(0, 5).join("\n");
  const counts: [string, number][] = [
    [",", (head.match(/,/g) || []).length],
    [";", (head.match(/;/g) || []).length],
    ["\t", (head.match(/\t/g) || []).length],
  ];
  counts.sort((a, b) => b[1] - a[1]);
  return counts[0][1] > 0 ? counts[0][0] : ",";
}

export function readCsv(text: string, delimiter?: string): string[][] {
  // شيل علامة BOM اللي إكسل بيحطها
  let s = text.replace(/^﻿/, "");
  const d = delimiter || guessDelimiter(s);

  const rows: string[][] = [];
  let row: string[] = [];
  let cell = "";
  let quoted = false;

  for (let i = 0; i < s.length; i++) {
    const ch = s[i];

    if (quoted) {
      if (ch === '"') {
        if (s[i + 1] === '"') {
          cell += '"';
          i++;
        } else quoted = false;
      } else cell += ch;
      continue;
    }

    if (ch === '"') quoted = true;
    else if (ch === d) {
      row.push(cell.trim());
      cell = "";
    } else if (ch === "\n") {
      row.push(cell.trim());
      cell = "";
      rows.push(row);
      row = [];
    } else if (ch !== "\r") cell += ch;
  }

  if (cell || row.length) {
    row.push(cell.trim());
    rows.push(row);
  }

  while (rows.length && rows[rows.length - 1].every((c) => !c)) rows.pop();
  return rows;
}

/** بيقرأ ملف مرفوع سواء xlsx أو csv */
export async function readTable(file: File): Promise<SheetData[]> {
  const lower = file.name.toLowerCase();
  if (lower.endsWith(".csv") || lower.endsWith(".txt") || lower.endsWith(".tsv")) {
    const text = await file.text();
    return [{ name: file.name, rows: readCsv(text) }];
  }
  if (lower.endsWith(".xls")) {
    throw new Error(
      "صيغة .xls القديمة مش مدعومة — افتح الملف في إكسل واحفظه بصيغة .xlsx أو .csv"
    );
  }
  const buf = new Uint8Array(await file.arrayBuffer());
  return readXlsx(buf);
}
