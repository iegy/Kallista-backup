// devseed.ts — بيانات تجريبية لمعاينة الواجهة في المتصفح فقط
export const seedSql = `
UPDATE settings SET value='سوبر ماركت النور' WHERE key='shop_name';
UPDATE settings SET value='ش. الجمهورية — المنصورة' WHERE key='shop_address';
UPDATE settings SET value='01000220606' WHERE key='shop_phone';

INSERT INTO categories(name) VALUES ('بقالة'),('مشروبات'),('منظفات'),('ألبان');

INSERT INTO products(code,name,barcode,category_id,unit,cost_price,sell_price,wholesale_price,qty,min_qty) VALUES
 ('P001','سكر ناعم ١ كجم','6221031492015',2,'كجم',28,34,32,120,20),
 ('P002','أرز مصري ١ كجم','6221031492022',2,'كجم',24,30,28,85,20),
 ('P003','زيت عباد الشمس ١ لتر','6221031492039',2,'لتر',62,75,71,40,10),
 ('P004','شاي العروسة ٢٥٠ جم','6221031492046',2,'علبة',45,58,54,6,10),
 ('P005','بيبسي ١ لتر','6221031492053',3,'زجاجة',18,25,22,64,24),
 ('P006','مياه معدنية ١.٥ لتر','6221031492060',3,'زجاجة',5,8,7,180,48),
 ('P007','عصير مانجو ١ لتر','6221031492077',3,'كرتونة',22,30,27,3,12),
 ('P008','مسحوق غسيل ٣ كجم','6221031492084',4,'كيس',95,120,112,18,6),
 ('P009','سائل جلي ١ لتر','6221031492091',4,'زجاجة',26,35,32,27,10),
 ('P010','لبن كامل الدسم ١ لتر','6221031492107',5,'كرتونة',30,38,35,44,15),
 ('P011','جبنة بيضاء ٥٠٠ جم','6221031492114',5,'علبة',52,68,63,9,10),
 ('P012','زبادي طبيعي','6221031492121',5,'علبة',7,11,10,0,20);

INSERT INTO customers(name,phone,balance) VALUES
 ('عميل نقدي','',0),('أحمد محمود','01012345678',450),('محل الأمل','01123456789',1295);

INSERT INTO suppliers(name,phone,balance) VALUES
 ('شركة الدلتا للتوزيع','01098765432',3200),('مخازن السلام','01187654321',0);

INSERT INTO users(username,password_hash,full_name,role,permissions) VALUES
 ('admin','dev:admin','المدير','admin','[]'),
 ('cashier','dev:cashier','أحمد الكاشير','cashier','["sales","customers","products"]');

INSERT INTO sales(invoice_no,customer_id,user_id,date,subtotal,discount,total,paid,remaining,payment_type) VALUES
 ('INV-1001',1,1,datetime('now','localtime','-40 minutes'),268,0,268,268,0,'cash'),
 ('INV-1002',2,1,datetime('now','localtime','-95 minutes'),512,12,500,300,200,'mixed'),
 ('INV-1003',1,1,datetime('now','localtime','-3 hours'),96,0,96,96,0,'cash'),
 ('INV-1004',3,1,datetime('now','localtime','-5 hours'),1335,40,1295,0,1295,'credit'),
 ('INV-1005',1,1,datetime('now','localtime','-6 hours'),177,0,177,177,0,'cash');

INSERT INTO sale_items(sale_id,product_id,qty,price,cost_at_sale,total) VALUES
 (1,1,4,34,28,136),(1,5,4,25,18,100),(1,6,4,8,5,32),
 (2,3,4,75,62,300),(2,8,1,120,95,120),(2,10,2,38,30,76),(2,9,0.5,32,26,16),
 (3,6,12,8,5,96),
 (4,2,20,30,24,600),(4,1,15,34,28,510),(4,3,3,75,62,225),
 (5,10,2,38,30,76),(5,11,1,68,52,68),(5,12,3,11,7,33);

INSERT INTO expenses(date,category,amount,note) VALUES
 (datetime('now','localtime'),'كهرباء',180,'فاتورة الشهر');
`;
