// devdb.ts — SQLite في ذاكرة المتصفح، لمعاينة الواجهة أثناء التطوير فقط.
// هذا الملف لا يدخل نسخة الإنتاج (محمي بـ import.meta.env.DEV في db.ts).

// @ts-ignore — sql.js بدون تعريفات أنواع
import initSqlJs from "sql.js";
// @ts-ignore
import wasmUrl from "sql.js/dist/sql-wasm.wasm?url";
import schema from "../db/schema.sql?raw";
import schemaV2 from "../db/schema_v2.sql?raw";
import schemaV3 from "../db/schema_v3.sql?raw";
import { seedSql } from "./devseed";
import type { ExecResult, Param, Row } from "./db";

let dbPromise: Promise<any> | null = null;

async function getDb(): Promise<any> {
  if (!dbPromise) {
    dbPromise = (async () => {
      const SQL = await initSqlJs({ locateFile: () => wasmUrl });
      const db = new SQL.Database();
      db.run(schema);
      db.run(seedSql);
      // نطبّق الترقية بعد البيانات التجريبية بالظبط زي ما بتحصل عند العميل:
      // قاعدة نسخة ١٫٠ فيها بيانات ← ترقية لنسخة ١٫١
      db.run(schemaV2);
      db.run(schemaV3);
      return db;
    })();
  }
  return dbPromise;
}

export async function devQuery(sql: string, params: Param[] = []): Promise<Row[]> {
  const db = await getDb();
  const stmt = db.prepare(sql);
  stmt.bind(params as any[]);
  const out: Row[] = [];
  while (stmt.step()) out.push(stmt.getAsObject());
  stmt.free();
  return out;
}

export async function devExecute(
  sql: string,
  params: Param[] = []
): Promise<ExecResult> {
  const db = await getDb();
  db.run(sql, params as any[]);
  const id = db.exec("SELECT last_insert_rowid() AS id")[0]?.values[0][0] ?? 0;
  return { rows_affected: db.getRowsModified(), last_insert_id: Number(id) };
}

export async function devBatch(
  ops: { sql: string; params: Param[] }[]
): Promise<number[]> {
  const ids: number[] = [];
  for (const op of ops) {
    const p = op.params.map((v) => {
      if (typeof v === "string" && v === "$LAST_ID") return ids[ids.length - 1];
      if (typeof v === "string" && v.startsWith("$LAST_ID:"))
        return ids[Number(v.slice(9))];
      return v;
    });
    const r = await devExecute(op.sql, p as Param[]);
    ids.push(r.last_insert_id);
  }
  return ids;
}
