// xlsx.ts — كاتب ملفات Excel (.xlsx) صغير ومكتوب داخل البرنامج.
// ملف الـ xlsx أصلًا مجرد ZIP فيه ملفات XML، فمش محتاجين مكتبة تقيلة —
// بنستخدم fflate للضغط بس (٨ كيلوبايت).

import { zipSync, strToU8 } from "fflate";

export type CellType = "text" | "number";

export interface SheetCol {
  key: string;
  label: string;
  width?: number;
  type?: CellType;
}

export interface SheetSpec {
  name: string; // اسم التبويب
  title?: string; // عنوان فوق الجدول
  subtitle?: string; // سطر تحت العنوان (الفترة مثلًا)
  cols: SheetCol[];
  rows: Record<string, any>[];
  totalsLabel?: string;
  totals?: Record<string, number>; // مفتاح العمود → القيمة
}

const esc = (s: string) =>
  String(s)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    // Excel بيرفض حروف التحكم
    .replace(/[\x00-\x08\x0B\x0C\x0E-\x1F]/g, "");

/** رقم العمود → حرفه (1 → A، 27 → AA) */
function colName(n: number): string {
  let s = "";
  while (n > 0) {
    const m = (n - 1) % 26;
    s = String.fromCharCode(65 + m) + s;
    n = Math.floor((n - 1) / 26);
  }
  return s;
}

/* أنماط الخلايا:
   1 = عنوان كبير | 2 = سطر فرعي | 3 = رأس الجدول
   4 = نص عادي    | 5 = رقم      | 6 = رأس الإجماليات نص | 7 = رقم إجمالي */
const STYLES = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<numFmts count="1"><numFmt numFmtId="164" formatCode="#,##0.00"/></numFmts>
<fonts count="4">
<font><sz val="11"/><name val="Arial"/></font>
<font><b/><sz val="11"/><name val="Arial"/></font>
<font><b/><sz val="15"/><name val="Arial"/><color rgb="FF2F332C"/></font>
<font><sz val="10"/><name val="Arial"/><color rgb="FF8B8F83"/></font>
</fonts>
<fills count="4">
<fill><patternFill patternType="none"/></fill>
<fill><patternFill patternType="gray125"/></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FFE6E1D6"/><bgColor indexed="64"/></patternFill></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FFAFBB9C"/><bgColor indexed="64"/></patternFill></fill>
</fills>
<borders count="2">
<border><left/><right/><top/><bottom/><diagonal/></border>
<border><left style="thin"><color rgb="FFD6D0C2"/></left><right style="thin"><color rgb="FFD6D0C2"/></right><top style="thin"><color rgb="FFD6D0C2"/></top><bottom style="thin"><color rgb="FFD6D0C2"/></bottom><diagonal/></border>
</borders>
<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
<cellXfs count="8">
<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
<xf numFmtId="0" fontId="2" fillId="0" borderId="0" xfId="0" applyFont="1"/>
<xf numFmtId="0" fontId="3" fillId="0" borderId="0" xfId="0" applyFont="1"/>
<xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
<xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1"/>
<xf numFmtId="164" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyBorder="1"/>
<xf numFmtId="0" fontId="1" fillId="3" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1"/>
<xf numFmtId="164" fontId="1" fillId="3" borderId="1" xfId="0" applyNumberFormat="1" applyFont="1" applyFill="1" applyBorder="1"/>
</cellXfs>
<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>
</styleSheet>`;

function sheetXml(s: SheetSpec): string {
  const rows: string[] = [];
  let r = 0;

  const cell = (c: number, row: number, v: any, style: number, isNum: boolean) => {
    const ref = `${colName(c)}${row}`;
    if (isNum) {
      const n = Number(v);
      return `<c r="${ref}" s="${style}"><v>${Number.isFinite(n) ? n : 0}</v></c>`;
    }
    return `<c r="${ref}" s="${style}" t="inlineStr"><is><t xml:space="preserve">${esc(
      v ?? ""
    )}</t></is></c>`;
  };

  if (s.title) {
    r++;
    rows.push(`<row r="${r}">${cell(1, r, s.title, 1, false)}</row>`);
  }
  if (s.subtitle) {
    r++;
    rows.push(`<row r="${r}">${cell(1, r, s.subtitle, 2, false)}</row>`);
  }
  if (s.title || s.subtitle) r++; // سطر فاضي

  // رأس الجدول
  r++;
  rows.push(
    `<row r="${r}">${s.cols
      .map((c, i) => cell(i + 1, r, c.label, 3, false))
      .join("")}</row>`
  );

  // البيانات
  for (const data of s.rows) {
    r++;
    rows.push(
      `<row r="${r}">${s.cols
        .map((c, i) =>
          cell(i + 1, r, data[c.key], c.type === "number" ? 5 : 4, c.type === "number")
        )
        .join("")}</row>`
    );
  }

  // الإجماليات
  if (s.totals) {
    r++;
    rows.push(
      `<row r="${r}">${s.cols
        .map((c, i) => {
          if (i === 0) return cell(1, r, s.totalsLabel || "الإجمالي", 6, false);
          const has = Object.prototype.hasOwnProperty.call(s.totals!, c.key);
          return has ? cell(i + 1, r, s.totals![c.key], 7, true) : cell(i + 1, r, "", 6, false);
        })
        .join("")}</row>`
    );
  }

  const colsXml = s.cols
    .map((c, i) => `<col min="${i + 1}" max="${i + 1}" width="${c.width ?? 18}" customWidth="1"/>`)
    .join("");

  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<sheetViews><sheetView rightToLeft="1" workbookViewId="0"/></sheetViews>
<sheetFormatPr defaultRowHeight="16"/>
<cols>${colsXml}</cols>
<sheetData>${rows.join("")}</sheetData>
</worksheet>`;
}

/** بناء ملف xlsx كامل من تبويب واحد أو أكتر */
export function buildXlsx(sheets: SheetSpec[]): Uint8Array {
  const n = sheets.length;

  const contentTypes = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
${sheets
  .map(
    (_, i) =>
      `<Override PartName="/xl/worksheets/sheet${i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`
  )
  .join("")}
<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
</Types>`;

  const rels = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>`;

  const workbook = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"
 xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
<sheets>${sheets
    .map(
      (s, i) =>
        `<sheet name="${esc(s.name).slice(0, 31)}" sheetId="${i + 1}" r:id="rId${i + 1}"/>`
    )
    .join("")}</sheets>
</workbook>`;

  const wbRels = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
${sheets
  .map(
    (_, i) =>
      `<Relationship Id="rId${i + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${i + 1}.xml"/>`
  )
  .join("")}
<Relationship Id="rId${n + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>`;

  const files: Record<string, Uint8Array> = {
    "[Content_Types].xml": strToU8(contentTypes),
    "_rels/.rels": strToU8(rels),
    "xl/workbook.xml": strToU8(workbook),
    "xl/_rels/workbook.xml.rels": strToU8(wbRels),
    "xl/styles.xml": strToU8(STYLES),
  };
  sheets.forEach((s, i) => {
    files[`xl/worksheets/sheet${i + 1}.xml`] = strToU8(sheetXml(s));
  });

  return zipSync(files, { level: 6 });
}
