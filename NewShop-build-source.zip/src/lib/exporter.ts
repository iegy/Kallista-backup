// exporter.ts — حفظ الملفات المُصدَّرة
// داخل البرنامج: نافذة "حفظ باسم" من ويندوز ثم كتابة الملف عن طريق Rust.
// في معاينة المتصفح: تنزيل عادي.

import { invoke } from "@tauri-apps/api/core";
import { isTauri, sessionToken } from "./db";
import { buildXlsx, type SheetSpec } from "./xlsx";

function toBase64(bytes: Uint8Array): string {
  let bin = "";
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    bin += String.fromCharCode(...bytes.subarray(i, i + chunk));
  }
  return btoa(bin);
}

/** حفظ ملف ثنائي — بيرجّع مسار الحفظ أو null لو المستخدم لغى */
export async function saveBinary(
  suggestedName: string,
  bytes: Uint8Array,
  filterName: string,
  extensions: string[]
): Promise<string | null> {
  if (isTauri()) {
    const license = await invoke<{ activated: boolean; trial: boolean }>("license_status");
    if (!license.activated || license.trial) {
      throw new Error("تصدير البيانات متاح بعد التفعيل الرسمي فقط");
    }
    const { save } = await import("@tauri-apps/plugin-dialog");
    const path = await save({
      defaultPath: suggestedName,
      filters: [{ name: filterName, extensions }],
    });
    if (!path) return null;
    await invoke("save_file", {
      path,
      contentsB64: toBase64(bytes),
      sessionToken: sessionToken(),
    });
    return path;
  }

  // معاينة المتصفح
  const blob = new Blob([bytes as unknown as BlobPart], {
    type: "application/octet-stream",
  });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = suggestedName;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
  return suggestedName;
}

/** تصدير تقرير إلى Excel */
export async function exportExcel(
  fileName: string,
  sheets: SheetSpec[]
): Promise<string | null> {
  const bytes = buildXlsx(sheets);
  const name = fileName.endsWith(".xlsx") ? fileName : `${fileName}.xlsx`;
  return saveBinary(name, bytes, "ملف Excel", ["xlsx"]);
}
