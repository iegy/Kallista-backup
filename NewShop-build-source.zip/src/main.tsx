import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";

// خط Cairo محمّل محليًا من node_modules — مفيش أي رابط خارجي (البرنامج أوفلاين)
import "@fontsource/cairo/arabic-400.css";
import "@fontsource/cairo/arabic-600.css";
import "@fontsource/cairo/arabic-700.css";
import "@fontsource/cairo/arabic-800.css";
import "./styles/theme.css";
import "./styles/print.css";

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
