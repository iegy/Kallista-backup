/// <reference types="vite/client" />

declare module "*.sql?raw" {
  const content: string;
  export default content;
}

declare module "sql.js";
declare module "sql.js/dist/sql-wasm.wasm?url" {
  const url: string;
  export default url;
}
