-- ============================================================
-- NewShop 2.0.0 — schema v3
-- ترقية غير هادمة: تضيف السجلات التاريخية والمحاسبية والأمنية المطلوبة
-- ولا تحذف أو تعيد إنشاء أي جدول من جداول v1.1.
-- ============================================================

-- ===== حماية المستخدمين والصلاحيات =====
ALTER TABLE users ADD COLUMN max_line_discount REAL NOT NULL DEFAULT 10;
ALTER TABLE users ADD COLUMN max_invoice_discount REAL NOT NULL DEFAULT 10;
ALTER TABLE users ADD COLUMN manager_pin_hash TEXT;
ALTER TABLE users ADD COLUMN failed_login_count INTEGER NOT NULL DEFAULT 0;
ALTER TABLE users ADD COLUMN locked_until TEXT;
ALTER TABLE users ADD COLUMN last_login_at TEXT;
ALTER TABLE users ADD COLUMN updated_at TEXT;

-- أول مدير قديم يصبح المالك المحمي. بقية المديرين تظل Admin.
UPDATE users
   SET role = 'owner'
 WHERE id = (SELECT MIN(id) FROM users WHERE role = 'admin' AND is_active = 1)
   AND NOT EXISTS (SELECT 1 FROM users WHERE role = 'owner');

-- ===== لقطة البيع التاريخية وحالة المستند =====
ALTER TABLE sales ADD COLUMN document_state TEXT NOT NULL DEFAULT 'posted';
ALTER TABLE sales ADD COLUMN price_level TEXT NOT NULL DEFAULT 'retail';
ALTER TABLE sales ADD COLUMN tax_rate REAL NOT NULL DEFAULT 0;
ALTER TABLE sales ADD COLUMN tax_mode TEXT NOT NULL DEFAULT 'disabled';
ALTER TABLE sales ADD COLUMN gross_total REAL NOT NULL DEFAULT 0;
ALTER TABLE sales ADD COLUMN voided_at TEXT;
ALTER TABLE sales ADD COLUMN voided_by INTEGER;
ALTER TABLE sales ADD COLUMN void_reason TEXT;
ALTER TABLE sales ADD COLUMN updated_at TEXT;

UPDATE sales
   SET document_state = CASE status
       WHEN 'cancelled' THEN 'void'
       WHEN 'returned'  THEN 'returned'
       ELSE 'posted' END,
       gross_total = CASE WHEN gross_total = 0 THEN subtotal ELSE gross_total END;

ALTER TABLE sale_items ADD COLUMN product_name_snapshot TEXT;
ALTER TABLE sale_items ADD COLUMN code_snapshot TEXT;
ALTER TABLE sale_items ADD COLUMN barcode_snapshot TEXT;
ALTER TABLE sale_items ADD COLUMN unit_snapshot TEXT;
ALTER TABLE sale_items ADD COLUMN original_unit_price REAL NOT NULL DEFAULT 0;
ALTER TABLE sale_items ADD COLUMN line_discount REAL NOT NULL DEFAULT 0;
ALTER TABLE sale_items ADD COLUMN allocated_invoice_discount REAL NOT NULL DEFAULT 0;
ALTER TABLE sale_items ADD COLUMN effective_unit_net REAL NOT NULL DEFAULT 0;
ALTER TABLE sale_items ADD COLUMN tax_rate REAL NOT NULL DEFAULT 0;
ALTER TABLE sale_items ADD COLUMN tax_amount REAL NOT NULL DEFAULT 0;
ALTER TABLE sale_items ADD COLUMN line_net_total REAL NOT NULL DEFAULT 0;

UPDATE sale_items
   SET product_name_snapshot = COALESCE(
         product_name_snapshot,
         (SELECT name FROM products WHERE products.id = sale_items.product_id),
         'صنف محذوف'),
       code_snapshot = COALESCE(code_snapshot,
         (SELECT code FROM products WHERE products.id = sale_items.product_id)),
       barcode_snapshot = COALESCE(barcode_snapshot,
         (SELECT barcode FROM products WHERE products.id = sale_items.product_id)),
       unit_snapshot = COALESCE(unit_snapshot,
         (SELECT unit FROM products WHERE products.id = sale_items.product_id), ''),
       original_unit_price = CASE WHEN original_unit_price = 0 THEN price ELSE original_unit_price END,
       line_discount = CASE WHEN line_discount = 0 THEN discount ELSE line_discount END,
       line_net_total = CASE WHEN line_net_total = 0 THEN total ELSE line_net_total END,
       effective_unit_net = CASE
         WHEN effective_unit_net = 0 AND qty <> 0 THEN total / qty
         ELSE effective_unit_net END;

-- توزيع خصم رأس الفاتورة تاريخيًا على البنود بنسبة صافي كل بند.
UPDATE sale_items
   SET allocated_invoice_discount = ROUND(
         (SELECT s.discount FROM sales s WHERE s.id = sale_items.sale_id) *
         CASE WHEN (SELECT SUM(x.total) FROM sale_items x WHERE x.sale_id = sale_items.sale_id) > 0
              THEN total / (SELECT SUM(x.total) FROM sale_items x WHERE x.sale_id = sale_items.sale_id)
              ELSE 0 END, 2)
 WHERE allocated_invoice_discount = 0;

UPDATE sale_items
   SET line_net_total = MAX(0, total - allocated_invoice_discount),
       effective_unit_net = CASE WHEN qty <> 0
         THEN MAX(0, total - allocated_invoice_discount) / qty ELSE 0 END;

-- ===== الدفع والدفاتر المحاسبية =====
ALTER TABLE sale_payments ADD COLUMN reference_no TEXT;
ALTER TABLE sale_payments ADD COLUMN status TEXT NOT NULL DEFAULT 'posted';
ALTER TABLE sale_payments ADD COLUMN refunded_amount REAL NOT NULL DEFAULT 0;

ALTER TABLE payments ADD COLUMN document_no TEXT;
ALTER TABLE payments ADD COLUMN reference_type TEXT;
ALTER TABLE payments ADD COLUMN reference_id INTEGER;
ALTER TABLE payments ADD COLUMN status TEXT NOT NULL DEFAULT 'posted';

CREATE TABLE IF NOT EXISTS party_ledger (
  id             INTEGER PRIMARY KEY AUTOINCREMENT,
  party_type     TEXT NOT NULL CHECK(party_type IN ('customer','supplier')),
  party_id       INTEGER NOT NULL,
  date           TEXT NOT NULL DEFAULT (datetime('now','localtime')),
  entry_type     TEXT NOT NULL,
  reference_type TEXT,
  reference_id   INTEGER,
  document_no    TEXT,
  debit          REAL NOT NULL DEFAULT 0,
  credit         REAL NOT NULL DEFAULT 0,
  method         TEXT,
  user_id        INTEGER,
  shift_id       INTEGER,
  note           TEXT,
  created_at     TEXT NOT NULL DEFAULT (datetime('now','localtime')),
  CHECK(debit >= 0 AND credit >= 0),
  CHECK(NOT (debit > 0 AND credit > 0))
);

-- الرصيد الحالي القديم يصبح قيد افتتاحي واحد؛ الحركات الجديدة تسجل تفصيليًا.
INSERT INTO party_ledger(party_type, party_id, entry_type, debit, credit, note)
SELECT 'customer', id, 'migration_opening', MAX(balance,0), MAX(-balance,0),
       'رصيد افتتاحي مرحّل تلقائيًا من NewShop v1.1'
  FROM customers WHERE ABS(balance) > 0.00001;
INSERT INTO party_ledger(party_type, party_id, entry_type, debit, credit, note)
SELECT 'supplier', id, 'migration_opening', MAX(balance,0), MAX(-balance,0),
       'رصيد افتتاحي مرحّل تلقائيًا من NewShop v1.1'
  FROM suppliers WHERE ABS(balance) > 0.00001;

CREATE TABLE IF NOT EXISTS payment_allocations (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  payment_id  INTEGER NOT NULL REFERENCES payments(id) ON DELETE RESTRICT,
  invoice_type TEXT NOT NULL CHECK(invoice_type IN ('sale','purchase')),
  invoice_id  INTEGER NOT NULL,
  amount      REAL NOT NULL CHECK(amount > 0),
  created_at  TEXT NOT NULL DEFAULT (datetime('now','localtime')),
  UNIQUE(payment_id, invoice_type, invoice_id)
);

-- ===== المرتجعات المستقلة والتسوية =====
ALTER TABLE returns ADD COLUMN return_no TEXT;
ALTER TABLE returns ADD COLUMN party_id INTEGER;
ALTER TABLE returns ADD COLUMN settlement_method TEXT NOT NULL DEFAULT 'cash_refund';
ALTER TABLE returns ADD COLUMN status TEXT NOT NULL DEFAULT 'posted';
ALTER TABLE returns ADD COLUMN tax REAL NOT NULL DEFAULT 0;
ALTER TABLE returns ADD COLUMN approved_by INTEGER;
ALTER TABLE returns ADD COLUMN document_state TEXT NOT NULL DEFAULT 'posted';

UPDATE returns
   SET return_no = COALESCE(return_no, 'RET-' || printf('%06d', id)),
       party_id = COALESCE(party_id,
         CASE type
           WHEN 'sale' THEN (SELECT customer_id FROM sales WHERE sales.id = returns.ref_id)
           ELSE (SELECT supplier_id FROM purchases WHERE purchases.id = returns.ref_id)
         END),
       settlement_method = CASE
         WHEN type = 'sale' AND (SELECT customer_id FROM sales WHERE sales.id = returns.ref_id) IS NOT NULL
           THEN 'reduce_receivable'
         WHEN type = 'purchase' THEN 'reduce_payable'
         ELSE 'cash_refund' END;

ALTER TABLE return_items ADD COLUMN source_item_id INTEGER;
ALTER TABLE return_items ADD COLUMN unit_refund_basis REAL NOT NULL DEFAULT 0;
ALTER TABLE return_items ADD COLUMN allocated_discount REAL NOT NULL DEFAULT 0;
ALTER TABLE return_items ADD COLUMN tax_amount REAL NOT NULL DEFAULT 0;
ALTER TABLE return_items ADD COLUMN cost_at_sale REAL NOT NULL DEFAULT 0;
ALTER TABLE return_items ADD COLUMN product_name_snapshot TEXT;

UPDATE return_items
   SET unit_refund_basis = CASE WHEN unit_refund_basis = 0 THEN price ELSE unit_refund_basis END,
       source_item_id = COALESCE(source_item_id,
         CASE WHEN (SELECT type FROM returns WHERE returns.id=return_items.return_id)='sale'
              THEN (SELECT MIN(si.id) FROM sale_items si
                     WHERE si.sale_id=(SELECT ref_id FROM returns WHERE returns.id=return_items.return_id)
                       AND si.product_id=return_items.product_id)
              ELSE (SELECT MIN(pi.id) FROM purchase_items pi
                     WHERE pi.purchase_id=(SELECT ref_id FROM returns WHERE returns.id=return_items.return_id)
                       AND pi.product_id=return_items.product_id) END),
       cost_at_sale = CASE WHEN cost_at_sale=0 THEN COALESCE((
         SELECT si.cost_at_sale FROM sale_items si
          WHERE si.id=(SELECT MIN(si2.id) FROM sale_items si2
             WHERE si2.sale_id=(SELECT ref_id FROM returns WHERE returns.id=return_items.return_id)
               AND si2.product_id=return_items.product_id)),0) ELSE cost_at_sale END,
       product_name_snapshot = COALESCE(product_name_snapshot,
         (SELECT name FROM products WHERE products.id = return_items.product_id), 'صنف محذوف');

-- ===== المشتريات والتكلفة الفعلية =====
ALTER TABLE purchases ADD COLUMN due_date TEXT;
ALTER TABLE purchases ADD COLUMN payment_status TEXT NOT NULL DEFAULT 'unpaid';
ALTER TABLE purchases ADD COLUMN payment_method TEXT NOT NULL DEFAULT 'cash';
ALTER TABLE purchases ADD COLUMN additional_costs REAL NOT NULL DEFAULT 0;
ALTER TABLE purchases ADD COLUMN landed_cost_method TEXT NOT NULL DEFAULT 'value';
ALTER TABLE purchases ADD COLUMN document_state TEXT NOT NULL DEFAULT 'posted';
ALTER TABLE purchases ADD COLUMN tax REAL NOT NULL DEFAULT 0;

UPDATE purchases SET payment_status = CASE
  WHEN remaining <= 0 THEN 'paid'
  WHEN paid > 0 THEN 'partial'
  ELSE 'unpaid' END;

ALTER TABLE purchase_items ADD COLUMN product_name_snapshot TEXT;
ALTER TABLE purchase_items ADD COLUMN code_snapshot TEXT;
ALTER TABLE purchase_items ADD COLUMN line_discount REAL NOT NULL DEFAULT 0;
ALTER TABLE purchase_items ADD COLUMN allocated_invoice_discount REAL NOT NULL DEFAULT 0;
ALTER TABLE purchase_items ADD COLUMN allocated_landed_cost REAL NOT NULL DEFAULT 0;
ALTER TABLE purchase_items ADD COLUMN effective_unit_cost REAL NOT NULL DEFAULT 0;

UPDATE purchase_items
   SET product_name_snapshot = COALESCE(product_name_snapshot,
         (SELECT name FROM products WHERE products.id = purchase_items.product_id), 'صنف محذوف'),
       code_snapshot = COALESCE(code_snapshot,
         (SELECT code FROM products WHERE products.id = purchase_items.product_id)),
       effective_unit_cost = CASE WHEN effective_unit_cost = 0 THEN cost ELSE effective_unit_cost END;

-- ===== دفتر المخزون الكامل =====
ALTER TABLE stock_moves ADD COLUMN reference_type TEXT;
ALTER TABLE stock_moves ADD COLUMN reference_id INTEGER;
ALTER TABLE stock_moves ADD COLUMN qty_before REAL;
ALTER TABLE stock_moves ADD COLUMN qty_after REAL;
ALTER TABLE stock_moves ADD COLUMN unit_cost REAL;
ALTER TABLE stock_moves ADD COLUMN total_value REAL;
ALTER TABLE stock_moves ADD COLUMN shift_id INTEGER;
ALTER TABLE stock_moves ADD COLUMN reversal_of INTEGER;

UPDATE stock_moves
   SET reference_type = COALESCE(reference_type, type),
       reference_id = COALESCE(reference_id, ref_id);

-- ===== منتجات متقدمة اختيارية =====
ALTER TABLE products ADD COLUMN secondary_name TEXT;
ALTER TABLE products ADD COLUMN max_qty REAL;
ALTER TABLE products ADD COLUMN preferred_supplier_id INTEGER;
ALTER TABLE products ADD COLUMN image_path TEXT;
ALTER TABLE products ADD COLUMN price_level_special REAL;

CREATE TABLE IF NOT EXISTS product_barcodes (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  product_id  INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  barcode     TEXT NOT NULL UNIQUE,
  label       TEXT,
  multiplier  REAL NOT NULL DEFAULT 1 CHECK(multiplier > 0),
  is_primary  INTEGER NOT NULL DEFAULT 0
);
INSERT OR IGNORE INTO product_barcodes(product_id, barcode, label, multiplier, is_primary)
SELECT id, barcode, 'أساسي', 1, 1 FROM products WHERE barcode IS NOT NULL AND TRIM(barcode) <> '';

CREATE TABLE IF NOT EXISTS product_variants (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  product_id  INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  name        TEXT NOT NULL,
  sku         TEXT,
  barcode     TEXT UNIQUE,
  price_delta REAL NOT NULL DEFAULT 0,
  qty         REAL NOT NULL DEFAULT 0,
  is_active   INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS favorite_products (
  user_id    INTEGER NOT NULL,
  product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  sort_order INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY(user_id, product_id)
);

-- ===== الفواتير المعلقة =====
CREATE TABLE IF NOT EXISTS suspended_sales (
  id               INTEGER PRIMARY KEY AUTOINCREMENT,
  label            TEXT,
  customer_id      INTEGER REFERENCES customers(id) ON DELETE SET NULL,
  price_level      TEXT NOT NULL DEFAULT 'retail',
  invoice_discount REAL NOT NULL DEFAULT 0,
  notes            TEXT,
  user_id           INTEGER,
  created_at        TEXT NOT NULL DEFAULT (datetime('now','localtime')),
  updated_at        TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE TABLE IF NOT EXISTS suspended_sale_items (
  id                INTEGER PRIMARY KEY AUTOINCREMENT,
  suspended_sale_id INTEGER NOT NULL REFERENCES suspended_sales(id) ON DELETE CASCADE,
  product_id        INTEGER REFERENCES products(id) ON DELETE SET NULL,
  product_name      TEXT NOT NULL,
  code              TEXT,
  unit              TEXT,
  qty               REAL NOT NULL,
  price             REAL NOT NULL,
  cost_snapshot     REAL NOT NULL DEFAULT 0,
  line_discount     REAL NOT NULL DEFAULT 0
);

-- ===== الجرد والمصروفات والورديات =====
ALTER TABLE stocktakes ADD COLUMN stocktake_no TEXT;
ALTER TABLE stocktakes ADD COLUMN posted_at TEXT;
ALTER TABLE stocktakes ADD COLUMN posted_by INTEGER;
ALTER TABLE stocktakes ADD COLUMN reason TEXT;
ALTER TABLE stocktake_items ADD COLUMN cost_snapshot REAL NOT NULL DEFAULT 0;
ALTER TABLE stocktake_items ADD COLUMN value_difference REAL NOT NULL DEFAULT 0;

ALTER TABLE expenses ADD COLUMN payment_method TEXT NOT NULL DEFAULT 'cash';
ALTER TABLE expenses ADD COLUMN attachment_path TEXT;
ALTER TABLE expenses ADD COLUMN status TEXT NOT NULL DEFAULT 'posted';

ALTER TABLE shifts ADD COLUMN z_number TEXT;
ALTER TABLE shifts ADD COLUMN close_reason TEXT;
ALTER TABLE shifts ADD COLUMN closed_by INTEGER;
-- لقطة تقرير Z النهائية. بعد الإغلاق نعرض هذه اللقطة بدل إعادة الحساب من
-- مستندات قد تُنشأ لاحقًا (مثل مرتجع لفاتورة وردية قديمة).
ALTER TABLE shifts ADD COLUMN z_report_json TEXT;

CREATE TABLE IF NOT EXISTS cash_movements (
  id             INTEGER PRIMARY KEY AUTOINCREMENT,
  shift_id       INTEGER NOT NULL REFERENCES shifts(id) ON DELETE RESTRICT,
  date           TEXT NOT NULL DEFAULT (datetime('now','localtime')),
  movement_type  TEXT NOT NULL,
  direction      TEXT NOT NULL CHECK(direction IN ('in','out')),
  amount         REAL NOT NULL CHECK(amount >= 0),
  method         TEXT NOT NULL DEFAULT 'cash',
  reference_type TEXT,
  reference_id   INTEGER,
  user_id        INTEGER,
  note           TEXT
);

-- ===== سجل تدقيق غير قابل للتعديل =====
CREATE TABLE IF NOT EXISTS audit_log (
  id               INTEGER PRIMARY KEY AUTOINCREMENT,
  timestamp        TEXT NOT NULL DEFAULT (datetime('now','localtime')),
  user_id          INTEGER,
  override_user_id INTEGER,
  action           TEXT NOT NULL,
  entity_type      TEXT,
  entity_id        INTEGER,
  old_values       TEXT,
  new_values       TEXT,
  reason           TEXT,
  metadata         TEXT
);

CREATE TRIGGER IF NOT EXISTS audit_log_no_update
BEFORE UPDATE ON audit_log BEGIN
  SELECT RAISE(ABORT, 'سجل التدقيق غير قابل للتعديل');
END;
CREATE TRIGGER IF NOT EXISTS audit_log_no_delete
BEFORE DELETE ON audit_log BEGIN
  SELECT RAISE(ABORT, 'سجل التدقيق غير قابل للحذف');
END;

-- حماية السجلات التاريخية من الحذف العرضي عبر الواجهة.
CREATE TRIGGER IF NOT EXISTS stock_moves_no_delete
BEFORE DELETE ON stock_moves BEGIN
  SELECT RAISE(ABORT, 'حركات المخزون التاريخية لا تُحذف');
END;
CREATE TRIGGER IF NOT EXISTS party_ledger_no_update
BEFORE UPDATE ON party_ledger BEGIN
  SELECT RAISE(ABORT, 'قيود دفتر الأطراف غير قابلة للتعديل');
END;
CREATE TRIGGER IF NOT EXISTS party_ledger_no_delete
BEFORE DELETE ON party_ledger BEGIN
  SELECT RAISE(ABORT, 'قيود دفتر الأطراف غير قابلة للحذف');
END;

CREATE TRIGGER IF NOT EXISTS closed_shift_no_update
BEFORE UPDATE ON shifts
WHEN OLD.status = 'closed'
BEGIN
  SELECT RAISE(ABORT, 'تقرير Z لوردية مغلقة غير قابل للتعديل');
END;

CREATE TRIGGER IF NOT EXISTS products_no_negative_stock
BEFORE UPDATE OF qty ON products
WHEN NEW.qty < -0.000001
 AND COALESCE((SELECT value FROM settings WHERE key='allow_negative_stock'),'0') <> '1'
BEGIN
  SELECT RAISE(ABORT, 'الكمية المطلوبة غير متاحة بالمخزون');
END;

-- ===== الفهارس للأحجام الكبيرة =====
CREATE INDEX IF NOT EXISTS idx_sales_state_date ON sales(document_state, date);
CREATE INDEX IF NOT EXISTS idx_sales_invoice_date ON sales(invoice_no, date);
CREATE INDEX IF NOT EXISTS idx_sale_items_product_sale ON sale_items(product_id, sale_id);
CREATE INDEX IF NOT EXISTS idx_returns_ref_type ON returns(type, ref_id, date);
CREATE INDEX IF NOT EXISTS idx_return_items_source ON return_items(source_item_id);
CREATE INDEX IF NOT EXISTS idx_purchase_items_product ON purchase_items(product_id, purchase_id);
CREATE INDEX IF NOT EXISTS idx_party_ledger_party_date ON party_ledger(party_type, party_id, date, id);
CREATE INDEX IF NOT EXISTS idx_party_ledger_ref ON party_ledger(reference_type, reference_id);
CREATE INDEX IF NOT EXISTS idx_stock_moves_reference ON stock_moves(reference_type, reference_id);
CREATE INDEX IF NOT EXISTS idx_stock_moves_product_date ON stock_moves(product_id, date, id);
CREATE INDEX IF NOT EXISTS idx_cash_movements_shift ON cash_movements(shift_id, date, id);
CREATE INDEX IF NOT EXISTS idx_audit_log_entity ON audit_log(entity_type, entity_id, timestamp);
CREATE INDEX IF NOT EXISTS idx_audit_log_user ON audit_log(user_id, timestamp);
CREATE INDEX IF NOT EXISTS idx_product_barcodes_product ON product_barcodes(product_id);
CREATE INDEX IF NOT EXISTS idx_variants_product ON product_variants(product_id, is_active);
CREATE INDEX IF NOT EXISTS idx_suspended_sales_user ON suspended_sales(user_id, updated_at);
CREATE INDEX IF NOT EXISTS idx_payments_reference ON payments(reference_type, reference_id);

-- ===== إعدادات 2.0 الافتراضية =====
INSERT OR IGNORE INTO settings(key, value) VALUES
  ('tax_enabled', '0'),
  ('tax_rate', '0'),
  ('tax_mode', 'exclusive'),
  ('allow_negative_override', '0'),
  ('variants_enabled', '0'),
  ('landed_cost_enabled', '0'),
  ('price_levels_enabled', '1'),
  ('show_reprint_copy', '1'),
  ('auto_backup_daily', '1'),
  ('auto_backup_on_close', '1'),
  ('backup_keep_daily', '7'),
  ('backup_keep_weekly', '4'),
  ('backup_keep_monthly', '6'),
  ('admin_session_minutes', '30'),
  ('failed_login_limit', '5'),
  ('failed_login_lock_minutes', '15'),
  ('invoice_return_policy', ''),
  ('receipt_show_tax_no', '1'),
  ('portable_mode_seen', '0');
