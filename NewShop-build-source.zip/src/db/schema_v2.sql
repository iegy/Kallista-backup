-- ============================================================
--  ترقية V2 — النسخة ١٫١
--  الورديات + الدرج + الدفع المقسّم + باركود الميزان + الثيمات
--  الملف ده بيتنفذ مرة واحدة بس على قواعد بيانات نسخة ١٫٠،
--  وبعد ما البرنامج ياخد نسخة احتياطية تلقائية.
-- ============================================================

-- ===== الورديات =====
CREATE TABLE IF NOT EXISTS shifts (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id       INTEGER,
  opened_at     TEXT NOT NULL DEFAULT (datetime('now','localtime')),
  closed_at     TEXT,
  opening_cash  REAL NOT NULL DEFAULT 0,   -- رصيد الدرج أول الوردية
  expected_cash REAL,                      -- المفروض في الدرج وقت التقفيل
  counted_cash  REAL,                      -- اللي اتعدّ فعليًا
  diff          REAL,                      -- الفعلي − المفروض (سالب = عجز)
  status        TEXT NOT NULL DEFAULT 'open',  -- open | closed
  notes         TEXT
);

-- حركات الدرج اليدوية (إيداع / سحب)
CREATE TABLE IF NOT EXISTS shift_cash (
  id       INTEGER PRIMARY KEY AUTOINCREMENT,
  shift_id INTEGER NOT NULL REFERENCES shifts(id) ON DELETE CASCADE,
  date     TEXT NOT NULL DEFAULT (datetime('now','localtime')),
  amount   REAL NOT NULL,          -- موجب = إيداع في الدرج، سالب = سحب منه
  reason   TEXT,
  user_id  INTEGER
);

-- ===== الدفع المقسّم =====
-- الفاتورة الواحدة ممكن تتدفع بأكتر من طريقة
CREATE TABLE IF NOT EXISTS sale_payments (
  id      INTEGER PRIMARY KEY AUTOINCREMENT,
  sale_id INTEGER NOT NULL REFERENCES sales(id) ON DELETE CASCADE,
  method  TEXT NOT NULL,            -- cash | card | wallet | credit
  amount  REAL NOT NULL DEFAULT 0
);

-- ===== أعمدة جديدة =====
ALTER TABLE sales    ADD COLUMN shift_id INTEGER;
ALTER TABLE expenses ADD COLUMN shift_id INTEGER;
ALTER TABLE payments ADD COLUMN shift_id INTEGER;
ALTER TABLE returns  ADD COLUMN shift_id INTEGER;

-- مصدر حركة الدفع: 'sale' يعني اتسجّلت تلقائيًا مع فاتورة بيع.
-- بنستخدمها عشان مانحسبش نفس الفلوس مرتين في تقفيل الوردية.
ALTER TABLE payments ADD COLUMN source TEXT;
UPDATE payments SET source = 'sale' WHERE note LIKE 'تحصيل مع فاتورة%';

-- كود الصنف على الميزان (PLU) — بيتقرا من باركود الميزان
ALTER TABLE products ADD COLUMN plu TEXT;

-- ===== الفهارس =====
CREATE INDEX IF NOT EXISTS idx_sale_payments_sale ON sale_payments(sale_id);
CREATE INDEX IF NOT EXISTS idx_shift_cash_shift   ON shift_cash(shift_id);
CREATE INDEX IF NOT EXISTS idx_shifts_status      ON shifts(status);
CREATE INDEX IF NOT EXISTS idx_sales_shift        ON sales(shift_id);
CREATE INDEX IF NOT EXISTS idx_products_plu       ON products(plu);

-- ===== ترحيل بيانات النسخة القديمة =====
-- كل فاتورة قديمة بندخّل مدفوعاتها في الجدول الجديد عشان التقارير تفضل مظبوطة
INSERT INTO sale_payments(sale_id, method, amount)
  SELECT id, 'cash', paid FROM sales WHERE paid > 0;
INSERT INTO sale_payments(sale_id, method, amount)
  SELECT id, 'credit', remaining FROM sales WHERE remaining > 0;

-- ===== الإعدادات الجديدة =====
INSERT OR IGNORE INTO settings(key, value) VALUES
  -- المظهر
  ('theme',            'olive'),   -- olive | blue | dark
  -- الطباعة
  ('print_mode',       'a4'),      -- a4 | t80 | t58
  ('receipt_footer',   'شكرًا لتعاملكم معنا'),
  -- طرق الدفع المتاحة في شاشة الكاشير
  ('pay_cash',         '1'),
  ('pay_card',         '0'),
  ('pay_wallet',       '0'),
  ('pay_credit',       '1'),
  ('pay_card_label',   'فيزا'),
  ('pay_wallet_label', 'محفظة / انستاباي'),
  -- باركود الميزان
  ('scale_enabled',    '0'),
  ('scale_prefix',     '2'),       -- الرقم اللي بيبدأ بيه باركود الميزان
  ('scale_value',      'weight'),  -- weight = الوزن جوه الباركود | price = السعر
  ('scale_plu_len',    '6'),       -- عدد خانات كود الصنف
  ('scale_val_len',    '5'),       -- عدد خانات القيمة
  ('scale_divisor',    '1000'),    -- 1000 = جرام→كيلو | 100 = قرش→جنيه
  -- الورديات
  ('shift_required',   '0'),       -- 1 = ممنوع البيع من غير وردية مفتوحة
  -- التنبيهات
  ('alert_due_days',   '30'),      -- عميل عليه فلوس من أكتر من كام يوم
  ('stale_days',       '60');      -- صنف مباعش من كام يوم يعتبر راكد
