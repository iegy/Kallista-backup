-- ===== الإعدادات (مفتاح / قيمة) =====
CREATE TABLE IF NOT EXISTS settings (
  key   TEXT PRIMARY KEY,
  value TEXT
);

-- ===== التصنيفات =====
CREATE TABLE IF NOT EXISTS categories (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  name       TEXT NOT NULL UNIQUE,
  created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

-- ===== الأصناف =====
CREATE TABLE IF NOT EXISTS products (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  code            TEXT UNIQUE,
  name            TEXT NOT NULL,
  barcode         TEXT,
  category_id     INTEGER REFERENCES categories(id) ON DELETE SET NULL,
  unit            TEXT NOT NULL DEFAULT 'قطعة',
  cost_price      REAL NOT NULL DEFAULT 0,   -- متوسط التكلفة المرجح
  sell_price      REAL NOT NULL DEFAULT 0,
  wholesale_price REAL NOT NULL DEFAULT 0,
  qty             REAL NOT NULL DEFAULT 0,
  min_qty         REAL NOT NULL DEFAULT 0,
  is_active       INTEGER NOT NULL DEFAULT 1,
  notes           TEXT,
  created_at      TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

-- ===== العملاء والموردين =====
CREATE TABLE IF NOT EXISTS customers (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  name       TEXT NOT NULL,
  phone      TEXT,
  address    TEXT,
  balance    REAL NOT NULL DEFAULT 0,
  notes      TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

CREATE TABLE IF NOT EXISTS suppliers (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  name       TEXT NOT NULL,
  phone      TEXT,
  address    TEXT,
  balance    REAL NOT NULL DEFAULT 0,
  notes      TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

-- ===== فواتير البيع =====
CREATE TABLE IF NOT EXISTS sales (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  invoice_no   TEXT NOT NULL UNIQUE,
  customer_id  INTEGER REFERENCES customers(id) ON DELETE SET NULL,
  user_id      INTEGER,
  date         TEXT NOT NULL DEFAULT (datetime('now','localtime')),
  subtotal     REAL NOT NULL DEFAULT 0,
  discount     REAL NOT NULL DEFAULT 0,
  tax          REAL NOT NULL DEFAULT 0,
  total        REAL NOT NULL DEFAULT 0,
  paid         REAL NOT NULL DEFAULT 0,
  remaining    REAL NOT NULL DEFAULT 0,
  payment_type TEXT NOT NULL DEFAULT 'cash',   -- cash | credit | mixed
  status       TEXT NOT NULL DEFAULT 'active', -- active | returned | cancelled
  notes        TEXT
);

CREATE TABLE IF NOT EXISTS sale_items (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  sale_id      INTEGER NOT NULL REFERENCES sales(id) ON DELETE CASCADE,
  product_id   INTEGER REFERENCES products(id) ON DELETE SET NULL,
  qty          REAL NOT NULL,
  price        REAL NOT NULL,
  cost_at_sale REAL NOT NULL DEFAULT 0,
  discount     REAL NOT NULL DEFAULT 0,
  total        REAL NOT NULL DEFAULT 0
);

-- ===== فواتير الشراء =====
CREATE TABLE IF NOT EXISTS purchases (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  invoice_no  TEXT NOT NULL,
  supplier_id INTEGER REFERENCES suppliers(id) ON DELETE SET NULL,
  user_id     INTEGER,
  date        TEXT NOT NULL DEFAULT (datetime('now','localtime')),
  subtotal    REAL NOT NULL DEFAULT 0,
  discount    REAL NOT NULL DEFAULT 0,
  total       REAL NOT NULL DEFAULT 0,
  paid        REAL NOT NULL DEFAULT 0,
  remaining   REAL NOT NULL DEFAULT 0,
  status      TEXT NOT NULL DEFAULT 'active',
  notes       TEXT
);

CREATE TABLE IF NOT EXISTS purchase_items (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  purchase_id INTEGER NOT NULL REFERENCES purchases(id) ON DELETE CASCADE,
  product_id  INTEGER REFERENCES products(id) ON DELETE SET NULL,
  qty         REAL NOT NULL,
  cost        REAL NOT NULL,
  total       REAL NOT NULL DEFAULT 0
);

-- ===== المرتجعات =====
CREATE TABLE IF NOT EXISTS returns (
  id      INTEGER PRIMARY KEY AUTOINCREMENT,
  type    TEXT NOT NULL,               -- sale | purchase
  ref_id  INTEGER,
  date    TEXT NOT NULL DEFAULT (datetime('now','localtime')),
  user_id INTEGER,
  total   REAL NOT NULL DEFAULT 0,
  reason  TEXT
);

CREATE TABLE IF NOT EXISTS return_items (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  return_id  INTEGER NOT NULL REFERENCES returns(id) ON DELETE CASCADE,
  product_id INTEGER REFERENCES products(id) ON DELETE SET NULL,
  qty        REAL NOT NULL,
  price      REAL NOT NULL DEFAULT 0,
  total      REAL NOT NULL DEFAULT 0
);

-- ===== حركة المخزن =====
CREATE TABLE IF NOT EXISTS stock_moves (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  date       TEXT NOT NULL DEFAULT (datetime('now','localtime')),
  qty_change REAL NOT NULL,
  type       TEXT NOT NULL,  -- sale|purchase|return_sale|return_purchase|stocktake|manual
  ref_id     INTEGER,
  note       TEXT,
  user_id    INTEGER
);

-- ===== الجرد =====
CREATE TABLE IF NOT EXISTS stocktakes (
  id      INTEGER PRIMARY KEY AUTOINCREMENT,
  date    TEXT NOT NULL DEFAULT (datetime('now','localtime')),
  user_id INTEGER,
  status  TEXT NOT NULL DEFAULT 'draft',  -- draft | applied
  notes   TEXT
);

CREATE TABLE IF NOT EXISTS stocktake_items (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  stocktake_id INTEGER NOT NULL REFERENCES stocktakes(id) ON DELETE CASCADE,
  product_id   INTEGER REFERENCES products(id) ON DELETE SET NULL,
  system_qty   REAL NOT NULL DEFAULT 0,
  counted_qty  REAL NOT NULL DEFAULT 0,
  diff         REAL NOT NULL DEFAULT 0
);

-- ===== المصروفات =====
CREATE TABLE IF NOT EXISTS expenses (
  id       INTEGER PRIMARY KEY AUTOINCREMENT,
  date     TEXT NOT NULL DEFAULT (datetime('now','localtime')),
  category TEXT,
  amount   REAL NOT NULL DEFAULT 0,
  note     TEXT,
  user_id  INTEGER
);

-- ===== المدفوعات والتحصيلات =====
CREATE TABLE IF NOT EXISTS payments (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  date       TEXT NOT NULL DEFAULT (datetime('now','localtime')),
  party_type TEXT NOT NULL,   -- customer | supplier
  party_id   INTEGER,
  amount     REAL NOT NULL DEFAULT 0,
  direction  TEXT NOT NULL,   -- in | out
  method     TEXT DEFAULT 'cash',
  note       TEXT,
  user_id    INTEGER
);

-- ===== المستخدمين =====
CREATE TABLE IF NOT EXISTS users (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  username      TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL DEFAULT '',
  full_name     TEXT,
  role          TEXT NOT NULL DEFAULT 'cashier',  -- admin | cashier
  permissions   TEXT,
  is_active     INTEGER NOT NULL DEFAULT 1,
  created_at    TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

-- ===== سجل النشاط =====
CREATE TABLE IF NOT EXISTS activity_log (
  id      INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER,
  action  TEXT,
  details TEXT,
  date    TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

-- ===== الفهارس (للأداء) =====
CREATE INDEX IF NOT EXISTS idx_products_barcode  ON products(barcode);
CREATE INDEX IF NOT EXISTS idx_products_name     ON products(name);
CREATE INDEX IF NOT EXISTS idx_products_code     ON products(code);
CREATE INDEX IF NOT EXISTS idx_products_category ON products(category_id);
CREATE INDEX IF NOT EXISTS idx_sales_date        ON sales(date);
CREATE INDEX IF NOT EXISTS idx_sales_customer    ON sales(customer_id);
CREATE INDEX IF NOT EXISTS idx_sale_items_sale   ON sale_items(sale_id);
CREATE INDEX IF NOT EXISTS idx_purchases_date    ON purchases(date);
CREATE INDEX IF NOT EXISTS idx_stock_moves_prod  ON stock_moves(product_id);
CREATE INDEX IF NOT EXISTS idx_stock_moves_date  ON stock_moves(date);
CREATE INDEX IF NOT EXISTS idx_payments_party    ON payments(party_type, party_id);
CREATE INDEX IF NOT EXISTS idx_expenses_date     ON expenses(date);

-- ===== القيم الافتراضية =====
INSERT OR IGNORE INTO settings(key, value) VALUES
  ('shop_name',        'اسم النشاط التجاري'),
  ('shop_address',     ''),
  ('shop_phone',       ''),
  ('shop_tax_no',      ''),
  ('shop_logo',        ''),
  ('currency',         'ج.م'),
  ('invoice_footer',   'شكرًا لتعاملكم معنا'),
  ('default_min_qty',  '5'),
  ('invoice_prefix',   'INV-'),
  ('invoice_counter',  '0'),
  ('allow_negative_stock', '0');

INSERT OR IGNORE INTO categories(name) VALUES ('عام');
