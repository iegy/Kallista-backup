import { useEffect, useState, type ReactNode } from "react";
import { HashRouter, Navigate, Route, Routes } from "react-router-dom";
import { invoke } from "@tauri-apps/api/core";
import Layout from "./components/Layout";
import { AppProvider, useApp } from "./lib/app";
import { AuthProvider, useAuth } from "./lib/auth";
import { isTauri } from "./lib/db";
import About from "./pages/About";
import Activate, { getLicense, type LicenseStatus } from "./pages/Activate";
import Backup from "./pages/Backup";
import Categories from "./pages/Categories";
import Dashboard from "./pages/Dashboard";
import Expenses from "./pages/Expenses";
import Import from "./pages/Import";
import Invoices from "./pages/Invoices";
import Labels from "./pages/Labels";
import Login from "./pages/Login";
import Parties from "./pages/Parties";
import Products from "./pages/Products";
import Purchases from "./pages/Purchases";
import Reports from "./pages/Reports";
import Returns from "./pages/Returns";
import Sales from "./pages/Sales";
import Settings from "./pages/Settings";
import Shifts from "./pages/Shifts";
import Stocktake from "./pages/Stocktake";
import Users from "./pages/Users";

function Splash({ text = "جارٍ تجهيز البرنامج…" }: { text?: string }) {
  return (
    <div style={{ display: "grid", placeItems: "center", height: "100vh" }}>
      <div style={{ textAlign: "center", color: "var(--ink-3)" }}>
        <div style={{ fontSize: 34, marginBottom: 8 }}>🛍️</div>
        {text}
      </div>
    </div>
  );
}

/** حارس الصلاحيات — بيمنع فتح الشاشة لو المستخدم مش مصرّح له */
function Guard({ perm, children }: { perm: string; children: ReactNode }) {
  const { can } = useAuth();
  if (can(perm)) return <>{children}</>;
  return (
    <div className="card" style={{ maxWidth: 520, margin: "40px auto", textAlign: "center" }}>
      <div style={{ fontSize: 42, marginBottom: 10 }}>🔒</div>
      <h2 style={{ margin: "0 0 8px" }}>مالكش صلاحية للشاشة دي</h2>
      <p style={{ color: "var(--ink-2)", lineHeight: 1.9, margin: 0 }}>
        كلّم المدير عشان يفتحلك الصلاحية من شاشة «المستخدمين والصلاحيات».
      </p>
    </div>
  );
}

function GuardAny({ perms, children }: { perms: string[]; children: ReactNode }) {
  const { can } = useAuth();
  if (perms.some(can)) return <>{children}</>;
  return (
    <div className="card" style={{ maxWidth: 520, margin: "40px auto", textAlign: "center" }}>
      <div style={{ fontSize: 42, marginBottom: 10 }}>🔒</div>
      <h2 style={{ margin: 0 }}>مالكش صلاحية للشاشة دي</h2>
    </div>
  );
}

function Shell() {
  const { ready, settings, reloadSettings, reloadShift } = useApp();
  const { user, checking } = useAuth();
  const [lic, setLic] = useState<LicenseStatus | null>(null);

  useEffect(() => {
    const refreshLicense = () => getLicense()
      .then(setLic)
      .catch(() =>
        setLic({
          activated: false,
          trial: false,
          trial_days_remaining: null,
          trial_started_at: null,
          trial_expires_at: null,
          device_code: "—",
          key: null,
          since: null,
          format_version: 0,
          license_id: null,
          customer_name: null,
          license_type: null,
          expires_at: null,
          edition: null,
          features: [],
          legacy: false,
          message: "تعذّر قراءة الترخيص",
        })
      );
    void refreshLicense();
    const timer = window.setInterval(() => void refreshLicense(), 60 * 60 * 1000);
    window.addEventListener("focus", refreshLicense);
    return () => {
      window.clearInterval(timer);
      window.removeEventListener("focus", refreshLicense);
    };
  }, []);

  useEffect(() => {
    if (!user) return;
    void reloadSettings();
    void reloadShift();
  }, [user, reloadSettings, reloadShift]);

  useEffect(() => {
    if (!isTauri() || !user || settings.auto_backup_daily !== "1") return;
    void invoke("auto_backup", { daily: true });
  }, [user, settings.auto_backup_daily]);

  // نسخة احتياطية تلقائية عند قفل البرنامج
  useEffect(() => {
    if (!isTauri() || !user) return;
    let unlisten: (() => void) | undefined;
    (async () => {
      const { getCurrentWindow } = await import("@tauri-apps/api/window");
      const w = getCurrentWindow();
      unlisten = await w.onCloseRequested(async (e) => {
        e.preventDefault();
        try {
          if (settings.auto_backup_on_close !== "0")
            await invoke("auto_backup", { daily: false });
        } catch {
          /* لو فشلت النسخة ما نمنعش القفل */
        }
        await w.destroy();
      });
    })();
    return () => unlisten?.();
  }, [user, settings.auto_backup_on_close]);

  if (!ready || checking || !lic) return <Splash />;
  if (!lic.activated) return <Activate status={lic} onActivated={setLic} />;
  if (!user) return <Login />;

  return (
    <Routes>
      <Route
        element={
          <Layout
            trialDaysRemaining={lic.trial ? (lic.trial_days_remaining ?? 0) : undefined}
          />
        }
      >
        <Route index element={<Dashboard />} />
        <Route path="/sales" element={<Guard perm="sales_create"><Sales /></Guard>} />
        <Route path="/invoices" element={<Guard perm="sales_view"><Invoices /></Guard>} />
        <Route path="/shifts" element={<Guard perm="shifts"><Shifts /></Guard>} />
        <Route path="/products" element={<Guard perm="products"><Products /></Guard>} />
        <Route path="/categories" element={<Guard perm="products"><Categories /></Guard>} />
        <Route path="/import" element={<Guard perm="import"><Import /></Guard>} />
        <Route path="/purchases" element={<Guard perm="purchases"><Purchases /></Guard>} />
        <Route path="/returns" element={<GuardAny perms={["sales_return", "purchase_return"]}><Returns /></GuardAny>} />
        <Route path="/stocktake" element={<Guard perm="stocktake"><Stocktake /></Guard>} />
        <Route path="/labels" element={<Guard perm="labels"><Labels /></Guard>} />
        <Route
          path="/customers"
          element={<Guard perm="customers"><Parties type="customer" /></Guard>}
        />
        <Route
          path="/suppliers"
          element={<GuardAny perms={["suppliers", "purchases"]}><Parties type="supplier" /></GuardAny>}
        />
        <Route path="/expenses" element={<Guard perm="expenses"><Expenses /></Guard>} />
        <Route path="/reports" element={<Guard perm="reports"><Reports /></Guard>} />
        <Route path="/users" element={<Guard perm="users"><Users /></Guard>} />
        <Route path="/backup" element={<Guard perm="backup"><Backup /></Guard>} />
        <Route path="/settings" element={<Guard perm="settings"><Settings /></Guard>} />
        <Route path="/about" element={<About />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Route>
    </Routes>
  );
}

export default function App() {
  return (
    <HashRouter>
      <AppProvider>
        <AuthProvider>
          <Shell />
        </AuthProvider>
      </AppProvider>
    </HashRouter>
  );
}
