// ui.tsx — مكونات واجهة صغيرة مشتركة
import { useEffect, useRef, useState, type ReactNode } from "react";
import { approveByManager, type User } from "../lib/auth";

export function Modal({
  title,
  onClose,
  children,
  footer,
  wide,
}: {
  title: string;
  onClose: () => void;
  children: ReactNode;
  footer?: ReactNode;
  wide?: boolean;
}) {
  useEffect(() => {
    const h = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [onClose]);

  return (
    <div className="modal-back" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className={`modal${wide ? " wide" : ""}`}>
        <div className="head">
          <h3>{title}</h3>
          <button className="x-btn" onClick={onClose} title="إغلاق">
            ✕
          </button>
        </div>
        <div className="body">{children}</div>
        {footer && <div className="foot">{footer}</div>}
      </div>
    </div>
  );
}

export function Field({
  label,
  hint,
  children,
}: {
  label: string;
  hint?: string;
  children: ReactNode;
}) {
  return (
    <div className="field">
      <label>{label}</label>
      {children}
      {hint && <span className="hint">{hint}</span>}
    </div>
  );
}

export function Empty({ icon = "📭", text }: { icon?: string; text: string }) {
  return (
    <div className="empty">
      <div className="big">{icon}</div>
      <div>{text}</div>
    </div>
  );
}

export function Confirm({
  title,
  message,
  confirmText = "تأكيد",
  danger,
  onConfirm,
  onClose,
}: {
  title: string;
  message: string;
  confirmText?: string;
  danger?: boolean;
  onConfirm: () => void;
  onClose: () => void;
}) {
  return (
    <Modal
      title={title}
      onClose={onClose}
      footer={
        <>
          <button
            className={`btn ${danger ? "danger" : ""}`}
            onClick={() => {
              onConfirm();
              onClose();
            }}
          >
            {confirmText}
          </button>
          <button className="btn ghost" onClick={onClose}>
            إلغاء
          </button>
        </>
      }
    >
      <p style={{ margin: 0, lineHeight: 1.9 }}>{message}</p>
    </Modal>
  );
}

/**
 * موافقة مدير على عملية محظورة على المستخدم الحالي.
 * بيطلب اسم مستخدم وكلمة سر لحد **عنده الصلاحية**، ولما يتأكد بينادي
 * onApprove ومعاه بيانات الموافق عشان نسجّلها في سجل النشاط.
 */
export function ManagerApprove({
  perm,
  title,
  message,
  confirmText = "موافقة وتنفيذ",
  onApprove,
  onClose,
}: {
  perm: string;
  title: string;
  message: string;
  confirmText?: string;
  onApprove: (approver: User) => void;
  onClose: () => void;
}) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const first = useRef<HTMLInputElement>(null);

  useEffect(() => first.current?.focus(), []);

  async function submit() {
    if (busy) return;
    setBusy(true);
    setErr("");
    try {
      const approver = await approveByManager(perm, username, password);
      onApprove(approver);
      onClose();
    } catch (e) {
      setErr(e instanceof Error ? e.message : String(e));
      setPassword("");
    } finally {
      setBusy(false);
    }
  }

  return (
    <Modal
      title={title}
      onClose={onClose}
      footer={
        <>
          <button className="btn" disabled={busy} onClick={() => void submit()}>
            {confirmText}
          </button>
          <button className="btn ghost" onClick={onClose}>
            إلغاء
          </button>
        </>
      }
    >
      <p style={{ margin: "0 0 14px", lineHeight: 1.9 }}>{message}</p>
      <div
        onKeyDown={(e) => {
          if (e.key === "Enter") {
            e.preventDefault();
            void submit();
          }
        }}
      >
        <Field label="اسم مستخدم المدير">
          <input
            ref={first}
            value={username}
            autoComplete="off"
            onChange={(e) => setUsername(e.target.value)}
          />
        </Field>
        <div style={{ marginTop: 12 }}>
          <Field label="كلمة السر">
            <input
              type="password"
              value={password}
              autoComplete="new-password"
              onChange={(e) => setPassword(e.target.value)}
            />
          </Field>
        </div>
      </div>
      {err && <div className="gate-err">{err}</div>}
    </Modal>
  );
}

export function Stat({
  icon,
  label,
  value,
  accent,
}: {
  icon: string;
  label: string;
  value: string;
  accent?: boolean;
}) {
  return (
    <div className={`stat${accent ? " accent" : ""}`}>
      <div className="ic">{icon}</div>
      <div>
        <div className="lbl">{label}</div>
        <div className="val">{value}</div>
      </div>
    </div>
  );
}
