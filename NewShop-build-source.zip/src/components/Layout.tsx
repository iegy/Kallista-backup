import { NavLink, Outlet, useLocation } from "react-router-dom";
import { THEMES, useApp } from "../lib/app";
import { useAuth } from "../lib/auth";
import { isTauri } from "../lib/db";

interface NavItem {
  to: string;
  icon: string;
  label: string;
  perm?: string; // الصلاحية المطلوبة لعرض البند
  perms?: string[];
}

const GROUPS: { title: string; items: NavItem[] }[] = [
  {
    title: "الرئيسية",
    items: [
      { to: "/", icon: "🏠", label: "لوحة التحكم" },
      { to: "/sales", icon: "🛒", label: "البيع (كاشير)", perm: "sales_create" },
      { to: "/invoices", icon: "🧾", label: "الفواتير", perm: "sales_view" },
      { to: "/shifts", icon: "🕒", label: "الورديات والدرج", perm: "shifts" },
    ],
  },
  {
    title: "المخزن",
    items: [
      { to: "/products", icon: "📦", label: "الأصناف والمخزون", perm: "products" },
      { to: "/categories", icon: "🏷️", label: "التصنيفات", perm: "products" },
      { to: "/purchases", icon: "🚚", label: "المشتريات", perm: "purchases" },
      { to: "/returns", icon: "↩️", label: "المرتجعات", perms: ["sales_return", "purchase_return"] },
      { to: "/stocktake", icon: "📋", label: "الجرد", perm: "stocktake" },
      { to: "/labels", icon: "🔖", label: "ملصقات الباركود", perm: "labels" },
      { to: "/import", icon: "📥", label: "استيراد من إكسل", perm: "import" },
    ],
  },
  {
    title: "الحسابات",
    items: [
      { to: "/customers", icon: "👥", label: "العملاء", perm: "customers" },
      { to: "/suppliers", icon: "🏭", label: "الموردين", perms: ["suppliers", "purchases"] },
      { to: "/expenses", icon: "💸", label: "المصروفات", perm: "expenses" },
      { to: "/reports", icon: "📊", label: "التقارير", perm: "reports" },
    ],
  },
  {
    title: "النظام",
    items: [
      { to: "/users", icon: "👤", label: "المستخدمين", perm: "users" },
      { to: "/backup", icon: "💾", label: "النسخ الاحتياطي", perm: "backup" },
      { to: "/settings", icon: "⚙️", label: "الإعدادات", perm: "settings" },
      { to: "/about", icon: "ℹ️", label: "عن البرنامج" },
    ],
  },
];

const TITLES: Record<string, string> = {
  "/": "لوحة التحكم",
  "/sales": "البيع (كاشير)",
  "/invoices": "الفواتير",
  "/shifts": "الورديات وتقفيل الدرج",
  "/products": "الأصناف والمخزون",
  "/categories": "التصنيفات",
  "/purchases": "المشتريات",
  "/returns": "المرتجعات",
  "/stocktake": "الجرد",
  "/labels": "ملصقات الباركود",
  "/import": "استيراد الأصناف والعملاء من إكسل",
  "/customers": "العملاء",
  "/suppliers": "الموردين",
  "/expenses": "المصروفات",
  "/reports": "التقارير",
  "/users": "المستخدمين والصلاحيات",
  "/backup": "النسخ الاحتياطي",
  "/settings": "الإعدادات",
  "/about": "عن البرنامج",
};

export default function Layout({ trialDaysRemaining }: { trialDaysRemaining?: number }) {
  const { settings, theme, setTheme } = useApp();
  const { user, can, logout } = useAuth();
  const loc = useLocation();
  const shop = settings.shop_name || "NewShop";
  const logo = settings.shop_logo;

  const initials = (user?.full_name || user?.username || "?").trim().charAt(0);

  return (
    <div className="app">
      <aside className="sidebar">
        <div className="brand">
          <div className="logo">{logo ? <img src={logo} alt="" /> : "NS"}</div>
          <div>
            <div className="t1" title={shop}>
              {shop}
            </div>
            <div className="t2">NewShop v2.0.0</div>
          </div>
        </div>

        {GROUPS.map((g) => {
          const items = g.items.filter(
            (it) => (!it.perm || can(it.perm)) && (!it.perms || it.perms.some(can))
          );
          if (!items.length) return null;
          return (
            <div key={g.title}>
              <div className="nav-group">{g.title}</div>
              {items.map((it) => (
                <NavLink
                  key={it.to}
                  to={it.to}
                  end={it.to === "/"}
                  className={({ isActive }) => `navlink${isActive ? " active" : ""}`}
                >
                  <span className="ic">{it.icon}</span>
                  <span>{it.label}</span>
                </NavLink>
              ))}
            </div>
          );
        })}

        <div className="spacer" />
        <div className="foot">
          تصميم وبرمجة: محمد حسين
          <br />
          iegy.net
        </div>
      </aside>

      <div className="main">
        {trialDaysRemaining !== undefined && (
          <div className="trial-banner">
            نسخة تجريبية — متبقي {trialDaysRemaining} يوم من أصل 15 يومًا. تصدير Excel
            والنسخ الاحتياطي الخارجي يفتحان بعد التفعيل الرسمي، وستظل بياناتك محفوظة.
          </div>
        )}
        {!isTauri() && (
          <div className="dev-banner">
            وضع المعاينة في المتصفح — البيانات تجريبية ولا تُحفظ. البرنامج الحقيقي
            يشتغل من نافذة NewShop على ويندوز.
          </div>
        )}
        <header className="topbar">
          <h1>{TITLES[loc.pathname] || "NewShop"}</h1>
          <span className="sub">{shop}</span>

          <div className="theme-pick" role="group" aria-label="مظهر البرنامج">
            {THEMES.map((t) => (
              <button
                key={t.key}
                type="button"
                title={t.label}
                aria-label={t.label}
                aria-pressed={theme === t.key}
                className={`sw${theme === t.key ? " on" : ""}`}
                style={{ background: t.swatch }}
                onClick={() => void setTheme(t.key)}
              />
            ))}
          </div>

          <div className="userchip">
            <div className="av">{initials}</div>
            <div>
              <div style={{ fontWeight: 700 }}>{user?.full_name || user?.username}</div>
              <div style={{ fontSize: 11, color: "var(--ink-3)" }}>
                {user?.role === "owner" ? "المالك" : user?.role === "admin" ? "مدير" : "كاشير"}
              </div>
            </div>
            <button className="btn ghost sm" onClick={logout} title="تسجيل الخروج">
              خروج
            </button>
          </div>
        </header>
        <div className="content">
          <Outlet />
        </div>
      </div>
    </div>
  );
}
