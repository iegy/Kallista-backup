// ShiftReportPrint.tsx — تقرير الوردية للطباعة (X أثناء الوردية، Z بعد التقفيل)
// بيتطبع على الطابعة الحرارية لو مختارة، وإلا على A4.
import { createPortal } from "react-dom";
import { useApp } from "../lib/app";
import { dateTimeAr, num } from "../lib/format";
import { PAY_LABELS } from "../lib/sales";
import type { ShiftReport } from "../lib/shifts";
import { ROLLS, type RollKey } from "./Receipt";

export default function ShiftReportPrint({
  rep,
  kind,
}: {
  rep: ShiftReport;
  /** X = كشف أثناء الوردية · Z = التقفيل النهائي */
  kind: "X" | "Z";
}) {
  const { settings, currency } = useApp();
  const mode = settings.print_mode || "a4";
  const thermal = mode === "t80" || mode === "t58";
  const roll = thermal ? ROLLS[mode as RollKey] : null;

  const s = rep.shift;
  const money = (v: number) => num(v);

  const rows: [string, number, string?][] = [
    ["رصيد بداية الوردية", Number(s.opening_cash)],
    ["مبيعات نقدي", rep.byMethod.cash],
    ["تحصيلات نقدي من عملاء", rep.collections.cash],
    ["مبالغ مستردة من موردين", rep.purchaseRefunds],
    ["إيداع في الدرج", rep.cashIn],
    ["مرتجعات مردودة كاش", -rep.cashRefunds],
    ["مدفوعات نقدي لموردين", -rep.supplierPaid.cash],
    ["مصروفات من الدرج", -rep.expenses],
    ["سحب من الدرج", -rep.cashOut],
  ];

  return createPortal(
    <div id="print-root">
      {thermal && roll && (
        <style>{`@page { size: ${roll.page} auto; margin: 2mm 0; }`}</style>
      )}

      <div className={thermal ? "rcpt" : "inv"} style={roll ? { width: roll.body } : undefined}>
        <div className={thermal ? "r-head" : "sr-head"}>
          <div className={thermal ? "r-shop" : "sr-shop"}>
            {settings.shop_name || "NewShop"}
          </div>
          <div className="sr-title">
            {kind === "Z" ? "تقرير تقفيل وردية (Z)" : "كشف وردية (X)"}
          </div>
        </div>

        <div className="r-sep" />

        <div className="r-meta">
          <div>
            <span>رقم الوردية</span>
            <b>#{s.id}</b>
          </div>
          <div>
            <span>الكاشير</span>
            <b>{s.user_name || "—"}</b>
          </div>
          <div>
            <span>فتحت</span>
            <b>{dateTimeAr(s.opened_at)}</b>
          </div>
          <div>
            <span>{s.closed_at ? "قفلت" : "الطباعة"}</span>
            <b>{dateTimeAr(s.closed_at || new Date().toISOString())}</b>
          </div>
        </div>

        <div className="r-sep" />

        <div className="r-tot">
          <div>
            <span>عدد الفواتير</span>
            <b>{rep.invoices}</b>
          </div>
          <div>
            <span>إجمالي المبيعات</span>
            <b>{money(rep.salesTotal)}</b>
          </div>
        </div>

        <div className="r-sep" />
        <div className="sr-sub">تفصيل المبيعات حسب طريقة الدفع</div>
        <div className="r-tot">
          {(["cash", "card", "wallet", "credit"] as const).map((m) =>
            rep.byMethod[m] ? (
              <div key={m}>
                <span>{PAY_LABELS[m]}</span>
                <b>{money(rep.byMethod[m])}</b>
              </div>
            ) : null
          )}
        </div>

        <div className="r-sep" />
        <div className="sr-sub">حركة الدرج</div>
        <div className="r-tot">
          {rows.map(([label, v]) =>
            v ? (
              <div key={label}>
                <span>{label}</span>
                <b>{money(v)}</b>
              </div>
            ) : null
          )}
          <div className="r-grand">
            <span>المفروض في الدرج</span>
            <b>
              {money(rep.expectedCash)} {currency}
            </b>
          </div>

          {s.counted_cash !== null && (
            <>
              <div>
                <span>المعدود فعليًا</span>
                <b>{money(Number(s.counted_cash))}</b>
              </div>
              <div className={Number(s.diff) < 0 ? "r-due" : ""}>
                <span>{Number(s.diff) < 0 ? "عجز" : Number(s.diff) > 0 ? "زيادة" : "الفرق"}</span>
                <b>{money(Math.abs(Number(s.diff)))}</b>
              </div>
            </>
          )}
        </div>

        {rep.creditRefunds > 0 && (
          <div className="sr-note">
            مرتجعات بقيمة {money(rep.creditRefunds)} اتخصمت من أرصدة العملاء ومالهاش
            علاقة بالدرج.
          </div>
        )}

        <div className="r-sep" />

        <div className="sr-sign">
          <div>
            توقيع الكاشير
            <div className="line" />
          </div>
          <div>
            توقيع المستلم
            <div className="line" />
          </div>
        </div>

        <div className={thermal ? "r-foot" : "sr-foot"}>
          <div className="r-tiny">NewShop 2.0.0 — محمد حسين — iegy.net</div>
        </div>
      </div>
    </div>,
    document.body
  );
}
