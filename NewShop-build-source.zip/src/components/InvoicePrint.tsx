// InvoicePrint.tsx — الطباعة: بيختار بين فاتورة A4 وإيصال الطابعة الحرارية
// حسب إعداد print_mode. حفظ PDF بيتم باختيار "Microsoft Print to PDF".
import { createPortal } from "react-dom";
import { useApp } from "../lib/app";
import { dateTimeAr, num, qty as fq } from "../lib/format";
import { PAY_LABELS, type InvoiceHead, type InvoiceLine, type PaySplit } from "../lib/sales";
import Receipt, { type RollKey } from "./Receipt";

export function printInvoice() {
  window.print();
}

export default function InvoicePrint({
  head,
  lines,
  payments = [],
  copy = false,
}: {
  head: InvoiceHead;
  lines: InvoiceLine[];
  payments?: PaySplit[];
  copy?: boolean;
}) {
  const { settings } = useApp();
  const mode = settings.print_mode || "a4";

  // نطبعها خارج شجرة التطبيق عشان تفضل ظاهرة لما نخفي .app وقت الطباعة
  return createPortal(
    <div id="print-root">
      {mode === "t80" || mode === "t58" ? (
        <Receipt head={head} lines={lines} payments={payments} roll={mode as RollKey} copy={copy} />
      ) : (
        <InvoiceA4 head={head} lines={lines} payments={payments} copy={copy} />
      )}
    </div>,
    document.body
  );
}

/* ---------------- فاتورة A4 ---------------- */

function InvoiceA4({
  head,
  lines,
  payments,
  copy,
}: {
  head: InvoiceHead;
  lines: InvoiceLine[];
  payments: PaySplit[];
  copy: boolean;
}) {
  const { settings, currency } = useApp();
  const s = settings;
  const shown = payments.filter((p) => Number(p.amount) > 0 && p.method !== "credit");

  return (
    <>
      <div className="inv">
        <header className="inv-head">
          <div className="inv-shop">
            {s.shop_logo && <img className="inv-logo" src={s.shop_logo} alt="" />}
            <div>
              <h1>{s.shop_name || "NewShop"}</h1>
              {s.shop_address && <div>{s.shop_address}</div>}
              {s.shop_phone && <div>تليفون: {s.shop_phone}</div>}
              {s.shop_tax_no && <div>الرقم الضريبي: {s.shop_tax_no}</div>}
            </div>
          </div>
          <div className="inv-meta">
            <div className="inv-title">فاتورة بيع {copy ? "— نسخة" : ""}</div>
            <table>
              <tbody>
                <tr>
                  <td>رقم الفاتورة</td>
                  <th>{head.invoice_no}</th>
                </tr>
                <tr>
                  <td>التاريخ</td>
                  <th>{dateTimeAr(head.date)}</th>
                </tr>
                <tr>
                  <td>العميل</td>
                  <th>{head.customer_name || "عميل نقدي"}</th>
                </tr>
                {head.customer_phone && (
                  <tr>
                    <td>تليفون العميل</td>
                    <th>{head.customer_phone}</th>
                  </tr>
                )}
                <tr>
                  <td>طريقة الدفع</td>
                  <th>{PAY_LABELS[head.payment_type] || head.payment_type}</th>
                </tr>
              </tbody>
            </table>
          </div>
        </header>

        {head.status === "cancelled" && <div className="inv-void">فاتورة ملغية</div>}

        <table className="inv-items">
          <thead>
            <tr>
              <th style={{ width: "6%" }}>م</th>
              <th>الصنف</th>
              <th style={{ width: "12%" }}>الكمية</th>
              <th style={{ width: "13%" }}>السعر</th>
              <th style={{ width: "12%" }}>خصم</th>
              <th style={{ width: "16%" }}>الإجمالي</th>
            </tr>
          </thead>
          <tbody>
            {lines.map((l, i) => (
              <tr key={l.id}>
                <td className="c">{i + 1}</td>
                <td>{l.name}</td>
                <td className="c">
                  {fq(l.qty)} {l.unit}
                </td>
                <td className="c">{num(l.price)}</td>
                <td className="c">{l.discount ? num(l.discount) : "—"}</td>
                <td className="c b">{num(l.total)}</td>
              </tr>
            ))}
          </tbody>
        </table>

        <div className="inv-bottom">
          <div className="inv-note">
            {head.notes && <div className="inv-notes">ملاحظات: {head.notes}</div>}
            <div className="inv-sign">
              <div>توقيع المستلم</div>
              <div className="line" />
            </div>
          </div>

          <table className="inv-totals">
            <tbody>
              <tr>
                <td>المجموع</td>
                <th>{num(head.subtotal)}</th>
              </tr>
              <tr>
                <td>الخصم</td>
                <th>{num(head.discount)}</th>
              </tr>
              {Number(head.tax) > 0 && (
                <tr>
                  <td>الضريبة ({num(head.tax_rate)}%)</td>
                  <th>{num(head.tax)}</th>
                </tr>
              )}
              <tr className="grand">
                <td>الإجمالي</td>
                <th>
                  {num(head.total)} {currency}
                </th>
              </tr>
              {shown.length > 1 &&
                shown.map((p, i) => (
                  <tr key={i}>
                    <td>{PAY_LABELS[p.method] || p.method}</td>
                    <th>{num(p.amount)}</th>
                  </tr>
                ))}
              <tr>
                <td>المدفوع</td>
                <th>{num(head.paid)}</th>
              </tr>
              <tr className={Number(head.remaining) > 0 ? "due" : ""}>
                <td>المتبقي</td>
                <th>{num(head.remaining)}</th>
              </tr>
            </tbody>
          </table>
        </div>

        <footer className="inv-foot">
          <div>{s.invoice_footer || "شكرًا لتعاملكم معنا"}</div>
          <div className="tiny">
            NewShop 2.0.0 — تصميم وبرمجة: محمد حسين — iegy.net
            {head.user_name ? ` — الكاشير: ${head.user_name}` : ""}
          </div>
        </footer>
      </div>
    </>
  );
}
