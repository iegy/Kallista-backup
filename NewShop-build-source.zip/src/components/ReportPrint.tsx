// ReportPrint.tsx — قالب طباعة أي تقرير على A4
import { createPortal } from "react-dom";
import { useApp } from "../lib/app";
import { dateAr, dateTimeAr, num, qty as fq } from "../lib/format";

export interface RepCol {
  key: string;
  label: string;
  type?: "number" | "qty";
  width?: number;
}

export interface RepData {
  title: string;
  from: string;
  to: string;
  cols: RepCol[];
  rows: Record<string, any>[];
  totals?: Record<string, number>;
  totalsLabel?: string;
}

export default function ReportPrint({ data }: { data: RepData }) {
  const { settings } = useApp();

  const cellVal = (c: RepCol, row: Record<string, any>) => {
    if (c.type === "number") return num(row[c.key]);
    if (c.type === "qty") return fq(row[c.key]);
    return row[c.key] ?? "—";
  };

  return createPortal(
    <div id="print-root">
      <div className="rep">
        <header className="rep-head">
          <div>
            <h1>{data.title}</h1>
            <div className="shop">
              {settings.shop_name || "NewShop"}
              {settings.shop_phone ? ` — ${settings.shop_phone}` : ""}
              {settings.shop_address ? (
                <>
                  <br />
                  {settings.shop_address}
                </>
              ) : null}
            </div>
          </div>
          <div className="period">
            الفترة: من {dateAr(data.from)} إلى {dateAr(data.to)}
            <br />
            تاريخ الطباعة: {dateTimeAr(new Date().toISOString())}
            <br />
            عدد السطور: {data.rows.length}
          </div>
        </header>

        <table>
          <thead>
            <tr>
              <th className="c" style={{ width: "5%" }}>
                م
              </th>
              {data.cols.map((c) => (
                <th key={c.key} style={c.width ? { width: `${c.width}%` } : undefined}>
                  {c.label}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {data.rows.map((row, i) => (
              <tr key={i}>
                <td className="c">{i + 1}</td>
                {data.cols.map((c) => (
                  <td key={c.key} className={c.type ? "c" : undefined}>
                    {cellVal(c, row)}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
          {data.totals && (
            <tfoot>
              <tr>
                <td className="c"></td>
                {data.cols.map((c, i) => (
                  <td key={c.key} className={c.type ? "c" : undefined}>
                    {i === 0
                      ? data.totalsLabel || "الإجمالي"
                      : data.totals![c.key] !== undefined
                      ? num(data.totals![c.key])
                      : ""}
                  </td>
                ))}
              </tr>
            </tfoot>
          )}
        </table>

        <div className="rep-foot">
          {settings.shop_name || "NewShop"} — NewShop 2.0.0 — تصميم وبرمجة: محمد حسين — iegy.net
        </div>
      </div>
    </div>,
    document.body
  );
}
