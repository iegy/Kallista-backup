// Receipt.tsx — إيصال طابعة حرارية (٨٠مم أو ٥٨مم)
// بيتطبع بنفس نافذة الطباعة العادية؛ الفرق إن مقاس الصفحة بيتظبط
// على عرض الرول وطول تلقائي، من غير هوامش تقريبًا.
import { useApp } from "../lib/app";
import { code128Svg } from "../lib/code128";
import { dateTimeAr, num, qty as fq } from "../lib/format";
import { PAY_LABELS, type InvoiceHead, type InvoiceLine, type PaySplit } from "../lib/sales";

/** مقاسات الرول: العرض الكلي، والعرض المطبوع فعليًا */
export const ROLLS = {
  t80: { page: "80mm", body: "72mm", cols: 42 },
  t58: { page: "58mm", body: "50mm", cols: 32 },
} as const;

export type RollKey = keyof typeof ROLLS;

export default function Receipt({
  head,
  lines,
  payments = [],
  roll,
  copy = false,
}: {
  head: InvoiceHead;
  lines: InvoiceLine[];
  payments?: PaySplit[];
  roll: RollKey;
  copy?: boolean;
}) {
  const { settings, currency } = useApp();
  const s = settings;
  const r = ROLLS[roll];
  const narrow = roll === "t58";

  // الآجل بيظهر في سطر «المتبقي» تحت، فمش بنكرّره هنا
  const shown = payments.filter(
    (p) => Number(p.amount) > 0 && p.method !== "credit"
  );

  return (
    <>
      {/* مقاس الرول — بيتحقن هنا عشان يغلب قاعدة A4 اللي في ملف الطباعة */}
      <style>{`@page { size: ${r.page} auto; margin: 2mm 0; }`}</style>

      <div className="rcpt" style={{ width: r.body }}>
        <div className="r-head">
          {s.shop_logo && <img className="r-logo" src={s.shop_logo} alt="" />}
          <div className="r-shop">{s.shop_name || "NewShop"}</div>
          {s.shop_address && <div>{s.shop_address}</div>}
          {s.shop_phone && <div>ت: {s.shop_phone}</div>}
          {s.shop_tax_no && <div>ض: {s.shop_tax_no}</div>}
        </div>

        <div className="r-sep" />

        <div className="r-meta">
          <div>
            <span>{copy ? "فاتورة — نسخة" : "فاتورة"}</span>
            <b>{head.invoice_no}</b>
          </div>
          <div>
            <span>التاريخ</span>
            <b>{dateTimeAr(head.date)}</b>
          </div>
          {head.user_name && (
            <div>
              <span>الكاشير</span>
              <b>{head.user_name}</b>
            </div>
          )}
          <div>
            <span>العميل</span>
            <b>{head.customer_name || "عميل نقدي"}</b>
          </div>
        </div>

        {head.status === "cancelled" && <div className="r-void">فاتورة ملغية</div>}

        <div className="r-sep" />

        <table className="r-items">
          <tbody>
            {lines.map((l) => (
              <tr key={l.id}>
                <td colSpan={2} className="r-name">
                  {l.name}
                  <div className="r-calc">
                    {fq(l.qty)}
                    {l.unit ? ` ${l.unit}` : ""} × {num(l.price)}
                    {l.discount ? ` − خصم ${num(l.discount)}` : ""}
                    <span className="r-lt">{num(l.total)}</span>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        <div className="r-sep" />

        <div className="r-tot">
          <div>
            <span>المجموع</span>
            <b>{num(head.subtotal)}</b>
          </div>
          {Number(head.discount) > 0 && (
            <div>
              <span>الخصم</span>
              <b>− {num(head.discount)}</b>
            </div>
          )}
          {Number(head.tax) > 0 && (
            <div>
              <span>الضريبة ({num(head.tax_rate)}%)</span>
              <b>{num(head.tax)}</b>
            </div>
          )}
          <div className="r-grand">
            <span>الإجمالي</span>
            <b>
              {num(head.total)} {currency}
            </b>
          </div>

          {shown.map((p, i) => (
            <div key={i}>
              <span>{PAY_LABELS[p.method] || p.method}</span>
              <b>{num(p.amount)}</b>
            </div>
          ))}

          {Number(head.remaining) > 0 && (
            <div className="r-due">
              <span>المتبقي</span>
              <b>{num(head.remaining)}</b>
            </div>
          )}
        </div>

        <div className="r-sep" />

        <div className="r-barcode">
          <div
            dangerouslySetInnerHTML={{
              __html: code128Svg(head.invoice_no, {
                moduleWidth: narrow ? 1 : 2,
                height: 34,
                quietZone: 8,
              }),
            }}
          />
          <div className="r-num">{head.invoice_no}</div>
        </div>

        <div className="r-foot">
          <div>{s.receipt_footer || s.invoice_footer || "شكرًا لتعاملكم معنا"}</div>
          <div className="r-tiny">NewShop 2.0.0 — محمد حسين — iegy.net</div>
        </div>
      </div>
    </>
  );
}
