// Alerts.tsx — لوحة تنبيهات: الحاجات اللي محتاجة تصرّف النهاردة
import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useApp } from "../lib/app";
import { n2, num } from "../lib/format";
import { alerts, type AlertSummary } from "../lib/reports";

interface Item {
  icon: string;
  tone: "danger" | "warn" | "info";
  title: string;
  detail: string;
  to: string;
  action: string;
}

export default function Alerts() {
  const { settings, currency, toast } = useApp();
  const [data, setData] = useState<AlertSummary | null>(null);

  useEffect(() => {
    alerts({
      dueDays: n2(settings.alert_due_days) || 30,
      staleDays: n2(settings.stale_days) || 60,
    })
      .then(setData)
      .catch((e) => toast(String(e), "err"));
  }, [settings.alert_due_days, settings.stale_days, toast]);

  if (!data) return null;

  const items: Item[] = [];

  if (data.outOfStock.length)
    items.push({
      icon: "🚫",
      tone: "danger",
      title: `${data.outOfStock.length} صنف خلص تمامًا`,
      detail: data.outOfStock
        .slice(0, 4)
        .map((p) => p.name)
        .join("، ") + (data.outOfStock.length > 4 ? "…" : ""),
      to: "/products",
      action: "اطلبهم",
    });

  if (data.lowStock.length)
    items.push({
      icon: "📉",
      tone: "warn",
      title: `${data.lowStock.length} صنف قرّب يخلص`,
      detail: data.lowStock
        .slice(0, 4)
        .map((p) => `${p.name} (${num(p.qty, 0)} ${p.unit})`)
        .join("، ") + (data.lowStock.length > 4 ? "…" : ""),
      to: "/products",
      action: "شوف النواقص",
    });

  if (data.overdue.length) {
    const total = data.overdue.reduce((s, c) => s + n2(c.balance), 0);
    items.push({
      icon: "⏰",
      tone: "warn",
      title: `${data.overdue.length} عميل متأخر في السداد`,
      detail: `إجمالي ${num(total)} ${currency} — أقدمهم ${
        data.overdue[0]?.name
      }${data.overdue[0]?.days ? ` من ${data.overdue[0].days} يوم` : ""}`,
      to: "/customers",
      action: "حصّل منهم",
    });
  }

  if (data.dead.count)
    items.push({
      icon: "🧊",
      tone: "info",
      title: `${data.dead.count} صنف راكد`,
      detail: `فلوس واقفة في المخزن بقيمة ${num(data.dead.value)} ${currency}`,
      to: "/reports",
      action: "التقرير",
    });

  if (data.staleShift)
    items.push({
      icon: "🕒",
      tone: "warn",
      title: `وردية #${data.staleShift.id} مفتوحة من ${data.staleShift.hours} ساعة`,
      detail: "الورديات المفتوحة من زمان بتخلّي تقفيل الدرج مش دقيق",
      to: "/shifts",
      action: "اقفلها",
    });

  if (!items.length)
    return (
      <div className="card alerts-ok">
        <span className="ic">✅</span>
        <div>
          <b>مفيش تنبيهات دلوقتي</b>
          <div className="hint">المخزون مظبوط، ومفيش عملاء متأخرين.</div>
        </div>
      </div>
    );

  return (
    <div className="card">
      <h3>محتاج انتباهك</h3>
      <div className="alerts">
        {items.map((it, i) => (
          <div key={i} className={`alert ${it.tone}`}>
            <span className="ic">{it.icon}</span>
            <div className="txt">
              <b>{it.title}</b>
              <div className="hint">{it.detail}</div>
            </div>
            <Link className="btn ghost sm" to={it.to}>
              {it.action}
            </Link>
          </div>
        ))}
      </div>
    </div>
  );
}
