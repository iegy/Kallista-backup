import { useEffect, useState } from "react";
import { invoke } from "@tauri-apps/api/core";
import { isTauri } from "../lib/db";
import { Field } from "../components/ui";

export interface LicenseStatus {
  activated: boolean;
  trial: boolean;
  trial_days_remaining: number | null;
  trial_started_at: string | null;
  trial_expires_at: string | null;
  device_code: string;
  key: string | null;
  since: string | null;
  format_version: number;
  license_id: string | null;
  customer_name: string | null;
  license_type: "lifetime" | "expiring" | string | null;
  expires_at: string | null;
  edition: string | null;
  features: string[];
  legacy: boolean;
  message: string | null;
}

export async function getLicense(): Promise<LicenseStatus> {
  if (isTauri()) return invoke<LicenseStatus>("license_status");
  // معاينة المتصفح: نعتبره مفعّل عشان نقدر نستعرض باقي الشاشات
  return {
    activated: true,
    trial: false,
    trial_days_remaining: null,
    trial_started_at: null,
    trial_expires_at: null,
    device_code: "DEMO-PREV-IEW0-0000",
    key: null,
    since: "وضع المعاينة",
    format_version: 2,
    license_id: "DEMO-LICENSE",
    customer_name: "نسخة المعاينة",
    license_type: "lifetime",
    expires_at: null,
    edition: "Professional",
    features: [],
    legacy: false,
    message: null,
  };
}

export default function Activate({
  status,
  onActivated,
}: {
  status: LicenseStatus;
  onActivated: (s: LicenseStatus) => void;
}) {
  const [key, setKey] = useState("");
  const [err, setErr] = useState("");
  const [ok, setOk] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => setErr(""), [key]);

  async function activate() {
    setBusy(true);
    setErr("");
    try {
      const s = await invoke<LicenseStatus>("activate", { key });
      setOk("تم التفعيل بنجاح 🎉");
      setTimeout(() => onActivated(s), 700);
    } catch (e: any) {
      setErr(String(e?.message ?? e));
    } finally {
      setBusy(false);
    }
  }

  async function paste() {
    try {
      const t = await navigator.clipboard.readText();
      if (t) setKey(t.trim());
    } catch {
      setErr("متقدرش تلزق تلقائيًا — الزق الكود بنفسك في الخانة");
    }
  }

  async function fromFile() {
    try {
      const { open } = await import("@tauri-apps/plugin-dialog");
      const p = await open({
        multiple: false,
        filters: [{ name: "ملف ترخيص", extensions: ["lic", "txt"] }],
      });
      if (typeof p === "string") {
        const txt = await invoke<string>("read_text_file", { path: p });
        setKey(txt.trim());
      }
    } catch (e: any) {
      setErr(String(e?.message ?? e));
    }
  }

  return (
    <div className="gate">
      <div className="gate-card wide">
        <div className="gate-logo">🔐</div>
        <h2>{status.trial ? "انتهت الفترة التجريبية" : "تفعيل NewShop"}</h2>
        <div className="sub">
          {status.trial
            ? "انتهت مدة الاستخدام المجاني البالغة 15 يومًا. بياناتك محفوظة ولن تُحذف؛ فعّل البرنامج رسميًا للمتابعة."
            : "البرنامج مرخّص لجهاز واحد. ابعت كود الجهاز ده لصاحب البرنامج، وهو هيبعتلك كود التفعيل."}
        </div>

        {status.trial && status.message && <div className="gate-err">{status.message}</div>}

        <label style={{ fontSize: 12.5, fontWeight: 600, color: "var(--ink-2)" }}>
          كود الجهاز (ابعته لصاحب البرنامج)
        </label>
        <div className="code-box" style={{ margin: "6px 0 10px" }}>
          {status.device_code}
        </div>
        <div style={{ display: "flex", gap: 8, marginBottom: 18 }}>
          <button
            className="btn ghost sm"
            onClick={() => navigator.clipboard?.writeText(status.device_code)}
          >
            📋 نسخ الكود
          </button>
          <div
            style={{
              fontSize: 12,
              color: "var(--ink-3)",
              alignSelf: "center",
              lineHeight: 1.7,
            }}
          >
            واتساب: 01000220606 — إيميل: egyup@outlook.com
          </div>
        </div>

        <Field label="كود التفعيل" hint="الزقه زي ما هو — الشرطات والمسافات مش مشكلة">
          <textarea
            className="key-input"
            value={key}
            placeholder="XXXXXXXX-XXXXXXXX-XXXXXXXX-…"
            onChange={(e) => setKey(e.target.value)}
          />
        </Field>

        <div style={{ display: "flex", gap: 8, marginTop: 8 }}>
          <button className="btn ghost sm" onClick={() => void paste()}>
            📥 لصق
          </button>
          <button className="btn ghost sm" onClick={() => void fromFile()}>
            📄 تحميل من ملف .lic
          </button>
        </div>

        <button className="btn" disabled={busy || !key.trim()} onClick={() => void activate()}>
          {busy ? "جارٍ التحقق…" : "تفعيل البرنامج"}
        </button>

        {err && <div className="gate-err">{err}</div>}
        {ok && (
          <div className="gate-err" style={{ background: "var(--ok-soft)", color: "var(--ok)" }}>
            {ok}
          </div>
        )}

        <div className="gate-foot">
          التفعيل يعمل بالكامل بدون إنترنت ويرتبط بهذا الجهاز.
          <br />
          NewShop 2.0.0 — تصميم وبرمجة: محمد حسين — iegy.net
        </div>
      </div>
    </div>
  );
}
