import { useEffect, useMemo, useRef, useState } from "react";
import { THEMES, useApp } from "../lib/app";
import { Field } from "../components/ui";
import { parseScaleBarcode, scaleConfig } from "../lib/scale";
import { appInfo, type AppInfo } from "../lib/db";
import { getLicense, type LicenseStatus } from "./Activate";

/** تصغير الصورة قبل تخزينها كـ data URL */
function shrink(file: File, max = 300): Promise<string> {
  return new Promise((resolve, reject) => {
    const fr = new FileReader();
    fr.onerror = () => reject(new Error("تعذّر قراءة الصورة"));
    fr.onload = () => {
      const img = new Image();
      img.onerror = () => reject(new Error("ملف الصورة غير صالح"));
      img.onload = () => {
        const s = Math.min(1, max / Math.max(img.width, img.height));
        const c = document.createElement("canvas");
        c.width = Math.round(img.width * s);
        c.height = Math.round(img.height * s);
        c.getContext("2d")!.drawImage(img, 0, 0, c.width, c.height);
        resolve(c.toDataURL("image/png"));
      };
      img.src = String(fr.result);
    };
    fr.readAsDataURL(file);
  });
}

const TABS = [
  { key: "shop", label: "عام والنشاط" },
  { key: "pay", label: "نقطة البيع" },
  { key: "print", label: "الفاتورة والطابعة" },
  { key: "scale", label: "الباركود والميزان" },
  { key: "inventory", label: "المخزون" },
  { key: "tax", label: "الضرائب" },
  { key: "security", label: "المستخدمون والأمان" },
  { key: "backup", label: "النسخ الاحتياطي" },
  { key: "license", label: "الترخيص" },
  { key: "ops", label: "الوردية والتنبيهات" },
  { key: "look", label: "المظهر" },
  { key: "advanced", label: "متقدم" },
] as const;

export default function Settings() {
  const { settings, saveSettings, toast, theme, setTheme } = useApp();
  const [f, setF] = useState<Record<string, string>>({});
  const [tab, setTab] = useState<(typeof TABS)[number]["key"]>("shop");
  const [busy, setBusy] = useState(false);
  const [test, setTest] = useState("");
  const [license, setLicense] = useState<LicenseStatus | null>(null);
  const [info, setInfo] = useState<AppInfo | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => setF({ ...settings }), [settings]);
  useEffect(() => {
    void getLicense().then(setLicense).catch(() => setLicense(null));
    void appInfo().then(setInfo).catch(() => setInfo(null));
  }, []);

  const set = (k: string, v: string) => setF((x) => ({ ...x, [k]: v }));
  const bool = (k: string, on: string, off: string, dflt = "1") => (
    <select
      value={f[k] ?? dflt}
      onChange={(e) => set(k, e.target.value)}
      style={{ maxWidth: 280 }}
    >
      <option value="1">{on}</option>
      <option value="0">{off}</option>
    </select>
  );

  // معاينة حيّة لقراءة باركود الميزان بالإعدادات الحالية
  const testRead = useMemo(() => {
    if (!test.trim()) return null;
    return parseScaleBarcode(test.trim(), { ...scaleConfig(f), enabled: true });
  }, [test, f]);

  async function onLogo(file?: File) {
    if (!file) return;
    if (!file.type.startsWith("image/")) return toast("اختر ملف صورة", "err");
    try {
      set("shop_logo", await shrink(file));
      toast("تم تحميل اللوجو — اضغط حفظ", "info");
    } catch (e) {
      toast(String(e), "err");
    }
  }

  async function save() {
    setBusy(true);
    try {
      await saveSettings(f);
      toast("تم حفظ الإعدادات");
    } catch (e) {
      toast(String(e), "err");
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
      <div className="tabs">
        {TABS.map((t) => (
          <button
            key={t.key}
            className={`tab${tab === t.key ? " active" : ""}`}
            onClick={() => setTab(t.key)}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* ===== النشاط ===== */}
      {tab === "shop" && (
        <div className="card">
          <h3>هوية النشاط</h3>
          <div style={{ display: "flex", gap: 20, alignItems: "flex-start" }}>
            <div style={{ textAlign: "center" }}>
              <div className="logo-preview">
                {f.shop_logo ? <img src={f.shop_logo} alt="اللوجو" /> : "لا يوجد لوجو"}
              </div>
              <input
                ref={fileRef}
                type="file"
                accept="image/*"
                style={{ display: "none" }}
                onChange={(e) => void onLogo(e.target.files?.[0])}
              />
              <div style={{ display: "flex", gap: 6, marginTop: 8 }}>
                <button className="btn sm ghost" onClick={() => fileRef.current?.click()}>
                  رفع صورة
                </button>
                {f.shop_logo && (
                  <button className="btn sm ghost" onClick={() => set("shop_logo", "")}>
                    إزالة
                  </button>
                )}
              </div>
            </div>

            <div className="grid c2" style={{ flex: 1 }}>
              <Field label="اسم النشاط التجاري">
                <input
                  value={f.shop_name ?? ""}
                  onChange={(e) => set("shop_name", e.target.value)}
                />
              </Field>
              <Field label="التليفون">
                <input
                  value={f.shop_phone ?? ""}
                  onChange={(e) => set("shop_phone", e.target.value)}
                />
              </Field>
              <Field label="العنوان">
                <input
                  value={f.shop_address ?? ""}
                  onChange={(e) => set("shop_address", e.target.value)}
                />
              </Field>
              <Field label="الرقم الضريبي">
                <input
                  value={f.shop_tax_no ?? ""}
                  onChange={(e) => set("shop_tax_no", e.target.value)}
                />
              </Field>
              <Field label="العملة" hint="مثال: ج.م — ر.س — د.إ">
                <input
                  value={f.currency ?? ""}
                  onChange={(e) => set("currency", e.target.value)}
                />
              </Field>
              <Field label="حد النواقص الافتراضي">
                <input
                  value={f.default_min_qty ?? ""}
                  onChange={(e) => set("default_min_qty", e.target.value)}
                />
              </Field>
            </div>
          </div>
        </div>
      )}

      {/* ===== الفاتورة والطباعة ===== */}
      {tab === "print" && (
        <>
          <div className="card">
            <h3>الطباعة</h3>
            <div className="grid c2">
              <Field
                label="مقاس الطباعة"
                hint="الطابعة الحرارية بتطلع إيصال صغير، وA4 بتطلع فاتورة كاملة"
              >
                <select
                  value={f.print_mode ?? "a4"}
                  onChange={(e) => set("print_mode", e.target.value)}
                >
                  <option value="a4">فاتورة A4</option>
                  <option value="t80">إيصال حراري ٨٠ مم</option>
                  <option value="t58">إيصال حراري ٥٨ مم</option>
                </select>
              </Field>
              <Field label="بادئة ترقيم الفواتير" hint="مثال: INV-">
                <input
                  value={f.invoice_prefix ?? ""}
                  onChange={(e) => set("invoice_prefix", e.target.value)}
                />
              </Field>
            </div>

            <div className="hint" style={{ marginTop: 10, lineHeight: 1.9 }}>
              بعد ما تختار الحراري، من نافذة الطباعة في ويندوز اختار الطابعة الحرارية
              وخلّي «الهوامش» على <b>بدون</b> و«المقاس» على الرول. لو الإيصال طلع
              مقصوص من الجنب، جرّب مقاس ٥٨ بدل ٨٠ (أو العكس).
            </div>
          </div>

          <div className="card">
            <h3>نصوص الفاتورة</h3>
            <Field label="تذييل فاتورة A4">
              <textarea
                value={f.invoice_footer ?? ""}
                onChange={(e) => set("invoice_footer", e.target.value)}
              />
            </Field>
            <div style={{ marginTop: 12 }}>
              <Field label="تذييل الإيصال الحراري" hint="سيبه فاضي عشان يستخدم نفس تذييل A4">
                <textarea
                  value={f.receipt_footer ?? ""}
                  onChange={(e) => set("receipt_footer", e.target.value)}
                />
              </Field>
            </div>
          </div>
        </>
      )}

      {/* ===== طرق الدفع ===== */}
      {tab === "pay" && (
        <div className="card">
          <h3>طرق الدفع في شاشة الكاشير</h3>
          <p className="hint" style={{ marginTop: -6, marginBottom: 14 }}>
            اقفل اللي مش بتستخدمه عشان شاشة التحصيل تفضل بسيطة. الفاتورة الواحدة
            ممكن تتدفع بأكتر من طريقة مع بعض.
          </p>
          <div className="grid c2">
            <Field label="نقدي">{bool("pay_cash", "مفعّل", "مقفول")}</Field>
            <Field label="آجل (على الحساب)">{bool("pay_credit", "مفعّل", "مقفول")}</Field>
            <Field label="كارت / ماكينة">{bool("pay_card", "مفعّل", "مقفول", "0")}</Field>
            <Field label="اسم الكارت في الشاشة" hint="مثال: فيزا — ميزة — ماكينة">
              <input
                value={f.pay_card_label ?? ""}
                onChange={(e) => set("pay_card_label", e.target.value)}
              />
            </Field>
            <Field label="محفظة إلكترونية">{bool("pay_wallet", "مفعّل", "مقفول", "0")}</Field>
            <Field label="اسم المحفظة في الشاشة" hint="مثال: انستاباي — فودافون كاش">
              <input
                value={f.pay_wallet_label ?? ""}
                onChange={(e) => set("pay_wallet_label", e.target.value)}
              />
            </Field>
          </div>
        </div>
      )}

      {/* ===== الميزان ===== */}
      {tab === "scale" && (
        <div className="card">
          <h3>باركود الميزان</h3>
          <p className="hint" style={{ marginTop: -6, marginBottom: 14, lineHeight: 1.9 }}>
            ميزان السوبرماركت بيطبع باركود جوّاه كود الصنف والوزن (أو السعر). لما
            تفعّل الميزة دي، الكاشير هيمسح الباركود والكمية هتتحط لوحدها. لازم تحط
            «كود الميزان» لكل صنف بيتوزن من شاشة الأصناف.
          </p>
          <div className="grid c2">
            <Field label="تفعيل قراءة باركود الميزان">
              {bool("scale_enabled", "مفعّل", "مقفول", "0")}
            </Field>
            <Field label="البادئة" hint="الرقم اللي بيبدأ بيه باركود الميزان — غالبًا 2">
              <input
                value={f.scale_prefix ?? "2"}
                onChange={(e) => set("scale_prefix", e.target.value.replace(/\D/g, ""))}
              />
            </Field>
            <Field label="اللي جوه الباركود">
              <select
                value={f.scale_value ?? "weight"}
                onChange={(e) => set("scale_value", e.target.value)}
              >
                <option value="weight">الوزن</option>
                <option value="price">السعر الإجمالي</option>
              </select>
            </Field>
            <Field
              label="المقسوم عليه"
              hint="1000 = الوزن بالجرام · 100 = السعر بالقرش"
            >
              <input
                value={f.scale_divisor ?? "1000"}
                onChange={(e) => set("scale_divisor", e.target.value.replace(/\D/g, ""))}
              />
            </Field>
            <Field label="عدد خانات كود الصنف">
              <input
                value={f.scale_plu_len ?? "6"}
                onChange={(e) => set("scale_plu_len", e.target.value.replace(/\D/g, ""))}
              />
            </Field>
            <Field label="عدد خانات القيمة">
              <input
                value={f.scale_val_len ?? "5"}
                onChange={(e) => set("scale_val_len", e.target.value.replace(/\D/g, ""))}
              />
            </Field>
          </div>

          <div style={{ marginTop: 16 }}>
            <Field
              label="جرّب باركود من الميزان"
              hint="امسح باركود حقيقي هنا واتأكد إن البرنامج بيقراه صح قبل ما تشتغل بيه"
            >
              <input
                value={test}
                placeholder="مثال: 2123456015003"
                onChange={(e) => setTest(e.target.value)}
                style={{ direction: "ltr", textAlign: "left" }}
              />
            </Field>
            {test.trim() &&
              (testRead ? (
                <div
                  className="gate-err"
                  style={{ background: "var(--ok-soft)", color: "var(--ok)" }}
                >
                  اتقرا صح ← كود الصنف: <b>{testRead.plu}</b>
                  {testRead.weight !== undefined && <> · الوزن: <b>{testRead.weight}</b></>}
                  {testRead.price !== undefined && <> · السعر: <b>{testRead.price}</b></>}
                </div>
              ) : (
                <div className="gate-err">
                  مش متقري بالإعدادات دي — راجع البادئة وعدد الخانات، والباركود لازم
                  يكون كامل بخانة التحقق.
                </div>
              ))}
          </div>
        </div>
      )}

      {/* ===== الوردية والتنبيهات ===== */}
      {tab === "ops" && (
        <>
          <div className="card">
            <h3>الوردية</h3>
            <Field
              label="لازم وردية مفتوحة قبل البيع"
              hint="لو مفعّل، الكاشير مايقدرش يبيع غير لما يفتح وردية ويحط رصيد الدرج"
            >
              {bool("shift_required", "إجباري", "اختياري", "0")}
            </Field>
          </div>

          <div className="card">
            <h3>المخزون والتنبيهات</h3>
            <div className="grid c2">
              <Field
                label="السماح بالبيع بكمية أكبر من المخزون"
                hint="لو مقفول، الكاشير هيتمنع ولازم موافقة مدير"
              >
                {bool("allow_negative_stock", "مسموح", "ممنوع", "0")}
              </Field>
              <Field
                label="تنبيه العملاء المتأخرين بعد (يوم)"
                hint="عميل عليه فلوس من أكتر من المدة دي بيظهر في التنبيهات"
              >
                <input
                  value={f.alert_due_days ?? "30"}
                  onChange={(e) => set("alert_due_days", e.target.value.replace(/\D/g, ""))}
                />
              </Field>
              <Field
                label="الصنف يعتبر راكد بعد (يوم)"
                hint="من غير أي بيع خلال المدة دي"
              >
                <input
                  value={f.stale_days ?? "60"}
                  onChange={(e) => set("stale_days", e.target.value.replace(/\D/g, ""))}
                />
              </Field>
            </div>
          </div>
        </>
      )}

      {tab === "inventory" && (
        <div className="card">
          <h3>سياسة المخزون والتكلفة</h3>
          <div className="grid c2">
            <Field label="السماح بالمخزون السالب" hint="الأكثر أمانًا إبقاؤه ممنوعًا">
              {bool("allow_negative_stock", "مسموح", "ممنوع", "0")}
            </Field>
            <Field label="تفعيل موافقة المدير على التجاوز">
              {bool("allow_negative_override", "مفعّل", "مقفول", "0")}
            </Field>
            <Field label="حد النواقص الافتراضي">
              <input value={f.default_min_qty ?? "5"} onChange={(e) => set("default_min_qty", e.target.value)} />
            </Field>
            <Field label="مستويات الأسعار">
              {bool("price_levels_enabled", "مفعّلة", "مقفولة", "1")}
            </Field>
            <Field label="تكاليف الشحن الموزعة في المشتريات">
              {bool("landed_cost_enabled", "مفعّلة", "مقفولة", "0")}
            </Field>
            <Field label="متغيرات الصنف">
              {bool("variants_enabled", "مفعّلة", "مقفولة", "0")}
            </Field>
          </div>
        </div>
      )}

      {tab === "tax" && (
        <div className="card">
          <h3>إعدادات الضرائب</h3>
          <div className="grid c2">
            <Field label="تفعيل الضريبة">{bool("tax_enabled", "مفعّلة", "معطّلة", "0")}</Field>
            <Field label="نسبة الضريبة %">
              <input type="number" step="0.01" min="0" value={f.tax_rate ?? "0"} onChange={(e) => set("tax_rate", e.target.value)} />
            </Field>
            <Field label="طريقة احتساب السعر">
              <select value={f.tax_mode ?? "exclusive"} onChange={(e) => set("tax_mode", e.target.value)}>
                <option value="exclusive">الضريبة تضاف إلى السعر</option>
                <option value="inclusive">السعر شامل الضريبة</option>
              </select>
            </Field>
            <Field label="إظهار الرقم الضريبي في الإيصال">
              {bool("receipt_show_tax_no", "يظهر", "مخفي", "1")}
            </Field>
          </div>
          <div className="hint" style={{ marginTop: 12 }}>
            يتم تثبيت نسبة وطريقة الضريبة داخل كل مستند عند ترحيله حتى لا تتغير الفواتير القديمة.
          </div>
        </div>
      )}

      {tab === "security" && (
        <div className="card">
          <h3>الجلسات ومحاولات الدخول</h3>
          <div className="grid c2">
            <Field label="انتهاء الجلسة بعد (دقيقة)">
              <input inputMode="numeric" value={f.admin_session_minutes ?? "30"} onChange={(e) => set("admin_session_minutes", e.target.value.replace(/\D/g, ""))} />
            </Field>
            <Field label="عدد المحاولات قبل القفل">
              <input inputMode="numeric" value={f.failed_login_limit ?? "5"} onChange={(e) => set("failed_login_limit", e.target.value.replace(/\D/g, ""))} />
            </Field>
            <Field label="مدة القفل (دقيقة)">
              <input inputMode="numeric" value={f.failed_login_lock_minutes ?? "15"} onChange={(e) => set("failed_login_lock_minutes", e.target.value.replace(/\D/g, ""))} />
            </Field>
          </div>
          <div className="hint" style={{ marginTop: 12 }}>
            كلمات المرور محفوظة بـArgon2، والصلاحيات الحساسة تُفحص في طبقة Rust وليست واجهة فقط.
          </div>
        </div>
      )}

      {tab === "backup" && (
        <div className="card">
          <h3>سياسة النسخ الاحتياطي</h3>
          <div className="grid c2">
            <Field label="نسخة يومية تلقائية">{bool("auto_backup_daily", "مفعّلة", "مقفولة", "1")}</Field>
            <Field label="نسخة عند إغلاق البرنامج">{bool("auto_backup_on_close", "مفعّلة", "مقفولة", "1")}</Field>
            <Field label="الاحتفاظ بالنسخ اليومية">
              <input value={f.backup_keep_daily ?? "7"} onChange={(e) => set("backup_keep_daily", e.target.value.replace(/\D/g, ""))} />
            </Field>
            <Field label="الاحتفاظ بالنسخ الأسبوعية">
              <input value={f.backup_keep_weekly ?? "4"} onChange={(e) => set("backup_keep_weekly", e.target.value.replace(/\D/g, ""))} />
            </Field>
            <Field label="الاحتفاظ بالنسخ الشهرية">
              <input value={f.backup_keep_monthly ?? "6"} onChange={(e) => set("backup_keep_monthly", e.target.value.replace(/\D/g, ""))} />
            </Field>
          </div>
          <p className="hint">إنشاء النسخ واسترجاعها يتم من شاشة «النسخ الاحتياطي» مع فحص سلامة SQLite ونسخة أمان إلزامية قبل الاسترجاع.</p>
        </div>
      )}

      {tab === "license" && (
        <div className="card">
          <h3>الترخيص</h3>
          <div className="grid c2">
            <Field label="الحالة"><input disabled value={license?.trial ? license.activated ? "نسخة تجريبية فعّالة" : "انتهت الفترة التجريبية" : license?.activated ? "مفعّل رسميًا" : "غير مفعّل"} /></Field>
            <Field label="صيغة الترخيص"><input disabled value={license?.trial ? "Demo 15 Days" : license?.legacy ? "Legacy Lifetime License" : license?.format_version ? `V${license.format_version}` : "—"} /></Field>
            <Field label="اسم العميل"><input disabled value={license?.customer_name ?? "—"} /></Field>
            <Field label="رقم الترخيص"><input disabled value={license?.license_id ?? "—"} /></Field>
            <Field label="كود الجهاز"><input disabled value={license?.device_code ?? "—"} /></Field>
            <Field label="المدة"><input disabled value={license?.trial ? `متبقي ${license.trial_days_remaining ?? 0} يوم — تنتهي ${license.trial_expires_at ?? "—"}` : license?.license_type === "expiring" ? `حتى ${license.expires_at}` : "مدى الحياة"} /></Field>
          </div>
        </div>
      )}

      {tab === "advanced" && (
        <div className="card">
          <h3>معلومات متقدمة</h3>
          <div className="grid c2">
            <Field label="نسخة البرنامج"><input disabled value={info?.version ?? "2.0.0"} /></Field>
            <Field label="وضع البيانات"><input disabled value={info?.portable ? "Portable" : "AppData"} /></Field>
            <Field label="مسار قاعدة البيانات"><input disabled value={info?.db_path ?? "—"} /></Field>
            <Field label="المطور"><input disabled value="تصميم وبرمجة: محمد حسين — iegy.net" /></Field>
          </div>
          <div className="hint" style={{ marginTop: 12 }}>
            لتفعيل Portable Mode ضع ملفًا فارغًا باسم portable.txt بجوار NewShop.exe قبل أول تشغيل. البيانات والتراخيص التجريبية لا تُضمّن في الحزمة المحمولة.
          </div>
        </div>
      )}

      {/* ===== المظهر ===== */}
      {tab === "look" && (
        <div className="card">
          <h3>مظهر البرنامج</h3>
          <p className="hint" style={{ marginTop: -6, marginBottom: 12 }}>
            الاختيار بيتطبّق على طول ومش محتاج حفظ.
          </p>
          <div className="theme-cards">
            {THEMES.map((t) => (
              <button
                key={t.key}
                type="button"
                className={`theme-card${theme === t.key ? " on" : ""}`}
                aria-pressed={theme === t.key}
                onClick={() => void setTheme(t.key)}
              >
                <span className="prev" data-theme={t.key}>
                  <span className="side" />
                  <span className="body">
                    <span className="bar" />
                    <span className="ln" />
                    <span className="ln short" />
                  </span>
                </span>
                <span className="nm">{t.label}</span>
              </button>
            ))}
          </div>
        </div>
      )}

      {!(["look", "license", "advanced"] as string[]).includes(tab) && (
        <div style={{ marginTop: 14, display: "flex", gap: 10 }}>
          <button className="btn" disabled={busy} onClick={() => void save()}>
            💾 حفظ الإعدادات
          </button>
          <button className="btn ghost" onClick={() => setF({ ...settings })}>
            تراجع
          </button>
        </div>
      )}
    </>
  );
}
