import { useCallback, useEffect, useState } from "react";
import { query } from "../lib/db";
import { useApp } from "../lib/app";
import { useAuth } from "../lib/auth";
import { dateTimeAr, n2, num, qty as fq } from "../lib/format";
import {
  returnableItems,
  saveReturn,
  type ReturnLine,
  type ReturnSettlement,
  type ReturnType,
} from "../lib/returns";
import { Empty, Field, Modal } from "../components/ui";

export default function Returns() {
  const { toast, currency, shift } = useApp();
  const { user, can } = useAuth();
  const [tab, setTab] = useState<ReturnType>("sale");
  const [invoices, setInvoices] = useState<any[]>([]);
  const [history, setHistory] = useState<any[]>([]);
  const [search, setSearch] = useState("");

  const [picked, setPicked] = useState<any | null>(null);
  const [lines, setLines] = useState<ReturnLine[]>([]);
  const [reason, setReason] = useState("");
  const [settlement, setSettlement] = useState<ReturnSettlement>("cash_refund");

  const load = useCallback(async () => {
    if (tab === "sale") {
      setInvoices(
        await query(
          `SELECT s.id, s.invoice_no, s.date, s.total, s.customer_id,
                  COALESCE(c.name,'عميل نقدي') AS party
             FROM sales s LEFT JOIN customers c ON c.id = s.customer_id
            WHERE s.status = 'active' ORDER BY s.id DESC LIMIT 300`
        )
      );
    } else {
      setInvoices(
        await query(
          `SELECT p.id, p.invoice_no, p.date, p.total, p.supplier_id,
                  COALESCE(s.name,'—') AS party
             FROM purchases p LEFT JOIN suppliers s ON s.id = p.supplier_id
            WHERE p.status = 'active' ORDER BY p.id DESC LIMIT 300`
        )
      );
    }
    setHistory(
      await query(
        `SELECT r.*, (SELECT COUNT(*) FROM return_items ri WHERE ri.return_id = r.id) AS items
           FROM returns r WHERE r.type = ? ORDER BY r.id DESC LIMIT 200`,
        [tab]
      )
    );
  }, [tab]);

  useEffect(() => {
    setPicked(null);
    setLines([]);
    setSearch("");
    load().catch((e) => toast(String(e), "err"));
  }, [load, toast]);

  async function pick(inv: any) {
    const items = await returnableItems(tab, inv.id);
    if (!items.length) return toast("كل أصناف الفاتورة دي اترجعت بالفعل", "err");
    setPicked(inv);
    setLines(items);
    setReason("");
    setSettlement(
      tab === "sale"
        ? inv.customer_id
          ? "reduce_receivable"
          : "cash_refund"
        : "reduce_payable"
    );
  }

  const total = lines.reduce((s, l) => s + n2(l.qty) * n2(l.price), 0);

  async function save() {
    if (!picked) return;
    if (tab === "purchase" && !can("purchase_return"))
      return toast("ليس لديك صلاحية مرتجع الشراء", "err");
    try {
      const r = await saveReturn({
        type: tab,
        refId: picked.id,
        refNo: picked.invoice_no,
        partyId: tab === "sale" ? picked.customer_id : picked.supplier_id,
        lines,
        reason,
        settlementMethod: settlement,
        userId: user?.id ?? null,
        shiftId: shift?.id ?? null,
      });
      toast(`اتسجّل المرتجع بقيمة ${num(r.total)} ${currency}`);
      setPicked(null);
      setLines([]);
      await load();
    } catch (e) {
      toast(String(e), "err");
    }
  }

  const view = invoices.filter(
    (i) =>
      !search.trim() ||
      String(i.invoice_no).includes(search.trim()) ||
      String(i.party).includes(search.trim())
  );

  return (
    <>
      <div className="tabs">
        <button
          className={`tab${tab === "sale" ? " active" : ""}`}
          onClick={() => setTab("sale")}
        >
          ↩️ مرتجع بيع
        </button>
        <button
          className={`tab${tab === "purchase" ? " active" : ""}`}
          onClick={() => setTab("purchase")}
        >
          ↪️ مرتجع شراء
        </button>
      </div>

      <div className="grid c2">
        <div className="card">
          <h3>
            {tab === "sale"
              ? "اختر فاتورة البيع المطلوب الارتجاع منها"
              : "اختر فاتورة الشراء المطلوب الارتجاع منها"}
          </h3>
          <div className="search-wrap" style={{ marginBottom: 10 }}>
            <input
              placeholder="ابحث برقم الفاتورة أو الاسم…"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
            <span className="ic">🔍</span>
          </div>
          <div className="table-wrap" style={{ maxHeight: 420, boxShadow: "none" }}>
            {view.length === 0 ? (
              <Empty icon="🧾" text="مفيش فواتير" />
            ) : (
              <table>
                <thead>
                  <tr>
                    <th>الفاتورة</th>
                    <th>{tab === "sale" ? "العميل" : "المورد"}</th>
                    <th>التاريخ</th>
                    <th className="num">الإجمالي</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                  {view.map((i) => (
                    <tr key={i.id}>
                      <td style={{ fontWeight: 700 }}>{i.invoice_no}</td>
                      <td>{i.party}</td>
                      <td style={{ fontSize: 11.5, color: "var(--ink-3)" }}>
                        {dateTimeAr(i.date)}
                      </td>
                      <td className="num">{num(i.total)}</td>
                      <td>
                        <button className="btn sm ghost" onClick={() => void pick(i)}>
                          اختيار
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>

        <div className="card">
          <h3>المرتجعات المسجّلة</h3>
          <div className="table-wrap" style={{ maxHeight: 470, boxShadow: "none" }}>
            {history.length === 0 ? (
              <Empty icon="↩️" text="مفيش مرتجعات" />
            ) : (
              <table>
                <thead>
                  <tr>
                    <th>التاريخ</th>
                    <th className="num">عدد الأصناف</th>
                    <th className="num">القيمة</th>
                    <th>السبب</th>
                  </tr>
                </thead>
                <tbody>
                  {history.map((r) => (
                    <tr key={r.id}>
                      <td style={{ fontSize: 12 }}>{dateTimeAr(r.date)}</td>
                      <td className="num">{num(r.items, 0)}</td>
                      <td className="num" style={{ fontWeight: 700 }}>
                        {num(r.total)}
                      </td>
                      <td style={{ fontSize: 12, color: "var(--ink-3)" }}>
                        {r.reason || "—"}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>
      </div>

      {picked && (
        <Modal
          wide
          title={`${tab === "sale" ? "مرتجع بيع" : "مرتجع شراء"} — فاتورة ${
            picked.invoice_no
          }`}
          onClose={() => setPicked(null)}
          footer={
            <>
              <button className="btn" disabled={total <= 0} onClick={() => void save()}>
                💾 تسجيل المرتجع
              </button>
              <button className="btn ghost" onClick={() => setPicked(null)}>
                إلغاء
              </button>
            </>
          }
        >
          <p style={{ marginTop: 0, color: "var(--ink-2)", lineHeight: 1.9 }}>
            {tab === "sale"
              ? "قيمة كل صنف محسوبة من صافي سعره التاريخي بعد خصومات الصنف والفاتورة. اختر طريقة التسوية بدقة."
              : "لن يسمح البرنامج بمرتجع شراء يتجاوز الكمية الموجودة فعليًا بالمخزن."}
          </p>

          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>الصنف</th>
                  <th className="num">المتاح للمرتجع</th>
                  <th className="num">الكمية المرتجعة</th>
                  <th className="num">السعر</th>
                  <th className="num">الإجمالي</th>
                </tr>
              </thead>
              <tbody>
                {lines.map((l, i) => (
                  <tr key={l.source_item_id}>
                    <td style={{ fontWeight: 600 }}>{l.name}</td>
                    <td className="num">
                      {fq(l.max)} {l.unit}
                    </td>
                    <td className="num">
                      <input
                        type="number"
                        step="0.001"
                        max={l.max}
                        value={l.qty}
                        style={{ width: 90 }}
                        onChange={(e) =>
                          setLines((c) => {
                            const x = [...c];
                            x[i] = {
                              ...x[i],
                              qty: Math.min(Math.max(0, Number(e.target.value)), l.max),
                            };
                            return x;
                          })
                        }
                      />
                    </td>
                    <td className="num">{num(l.price)}</td>
                    <td className="num" style={{ fontWeight: 700 }}>
                      {num(n2(l.qty) * n2(l.price))}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div style={{ display: "flex", gap: 14, marginTop: 14, alignItems: "flex-end" }}>
            <Field label="سبب المرتجع">
              <input
                value={reason}
                placeholder="مثال: الصنف تالف / العميل غيّر رأيه"
                onChange={(e) => setReason(e.target.value)}
              />
            </Field>
            <Field label="طريقة تسوية المرتجع">
              <select
                value={settlement}
                onChange={(e) => setSettlement(e.target.value as ReturnSettlement)}
              >
                {tab === "sale" ? (
                  <>
                    <option value="cash_refund">رد نقدي</option>
                    <option value="card_refund">رد إلى البطاقة</option>
                    <option value="wallet_refund">رد إلى المحفظة</option>
                    <option value="bank_refund">رد بنكي</option>
                    {picked.customer_id && (
                      <>
                        <option value="reduce_receivable">خصم من مديونية العميل</option>
                        <option value="customer_credit">رصيد دائن للعميل</option>
                      </>
                    )}
                  </>
                ) : (
                  <>
                    <option value="reduce_payable">خصم من مستحق المورد</option>
                    <option value="cash_refund">استرداد نقدي من المورد</option>
                    <option value="card_refund">استرداد إلى البطاقة</option>
                    <option value="wallet_refund">استرداد إلى المحفظة</option>
                    <option value="bank_refund">استرداد بنكي</option>
                  </>
                )}
              </select>
            </Field>
            <div className="tot-grand" style={{ minWidth: 230 }}>
              <span>قيمة المرتجع</span>
              <span className="v">{num(total)}</span>
            </div>
          </div>
          <div style={{ marginTop: 8 }}>
            <button
              className="btn ghost sm"
              onClick={() => setLines((c) => c.map((l) => ({ ...l, qty: l.max })))}
            >
              ارتجاع الفاتورة بالكامل
            </button>
          </div>
        </Modal>
      )}
    </>
  );
}
