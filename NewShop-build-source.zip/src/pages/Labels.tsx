import { useCallback, useEffect, useMemo, useState } from "react";
import { createPortal } from "react-dom";
import { code128Svg } from "../lib/code128";
import { execute, query } from "../lib/db";
import { useApp } from "../lib/app";
import { n2, normalizeAr, num } from "../lib/format";
import { Empty, Field } from "../components/ui";

interface P {
  id: number;
  code: string;
  name: string;
  barcode: string | null;
  sell_price: number;
  category_name: string | null;
}

/** توليد صورة الباركود CODE128 كـ SVG (بيتولّد محليًا — بدون إنترنت) */
function barcodeSvg(text: string): string {
  try {
    return code128Svg(text, { moduleWidth: 2, height: 60, quietZone: 10 });
  } catch {
    return "";
  }
}

export default function Labels() {
  const { toast, settings, currency } = useApp();
  const [rows, setRows] = useState<P[]>([]);
  const [search, setSearch] = useState("");
  const [counts, setCounts] = useState<Record<number, string>>({});
  const [cols, setCols] = useState("3");
  const [showName, setShowName] = useState(true);
  const [showPrice, setShowPrice] = useState(true);
  const [showShop, setShowShop] = useState(true);

  const load = useCallback(async () => {
    setRows(
      await query<P>(
        `SELECT p.id, p.code, p.name, p.barcode, p.sell_price, c.name AS category_name
           FROM products p LEFT JOIN categories c ON c.id = p.category_id
          WHERE p.is_active = 1 ORDER BY p.name COLLATE NOCASE`
      )
    );
  }, []);

  useEffect(() => {
    load().catch((e) => toast(String(e), "err"));
  }, [load, toast]);

  const view = useMemo(() => {
    const s = normalizeAr(search);
    if (!s) return rows;
    return rows.filter(
      (r) => normalizeAr(r.name).includes(s) || normalizeAr(r.code || "").includes(s)
    );
  }, [rows, search]);

  const missing = rows.filter((r) => !r.barcode);

  /** توليد باركود رقمي للأصناف اللي مالهاش — 200 + رقم الصنف */
  async function generateMissing() {
    try {
      for (const r of missing) {
        const code = "200" + String(r.id).padStart(6, "0");
        await execute(`UPDATE products SET barcode=? WHERE id=?`, [code, r.id]);
      }
      toast(`اتولّد باركود لـ ${missing.length} صنف`);
      await load();
    } catch (e) {
      toast(String(e), "err");
    }
  }

  const sheet = useMemo(() => {
    const out: { p: P; svg: string }[] = [];
    for (const r of rows) {
      const c = Math.min(200, Math.max(0, Math.floor(n2(counts[r.id]))));
      if (!c || !r.barcode) continue;
      const svg = barcodeSvg(r.barcode);
      for (let i = 0; i < c; i++) out.push({ p: r, svg });
    }
    return out;
  }, [rows, counts]);

  const totalLabels = sheet.length;

  return (
    <>
      <div className="toolbar">
        <div className="search-wrap">
          <input
            placeholder="ابحث عن صنف…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
          <span className="ic">🔍</span>
        </div>
        <Field label="عدد الملصقات في الصف">
          <select value={cols} onChange={(e) => setCols(e.target.value)}>
            <option value="2">٢ (كبير)</option>
            <option value="3">٣ (متوسط)</option>
            <option value="4">٤ (صغير)</option>
            <option value="5">٥ (صغير جدًا)</option>
          </select>
        </Field>
        <div style={{ flex: 1 }} />
        {missing.length > 0 && (
          <button
            className="btn ghost"
            style={{ marginTop: 18 }}
            onClick={() => void generateMissing()}
          >
            ⚙️ توليد باركود لـ {missing.length} صنف
          </button>
        )}
        <button
          className="btn"
          style={{ marginTop: 18 }}
          disabled={!totalLabels}
          onClick={() => window.print()}
        >
          🖨️ طباعة الشيت ({totalLabels})
        </button>
      </div>

      <div className="card" style={{ marginBottom: 14 }}>
        <div style={{ display: "flex", gap: 20, flexWrap: "wrap" }}>
          <label style={{ display: "flex", gap: 6, alignItems: "center", fontSize: 13.5 }}>
            <input
              type="checkbox"
              style={{ width: 16 }}
              checked={showShop}
              onChange={(e) => setShowShop(e.target.checked)}
            />
            اسم المحل
          </label>
          <label style={{ display: "flex", gap: 6, alignItems: "center", fontSize: 13.5 }}>
            <input
              type="checkbox"
              style={{ width: 16 }}
              checked={showName}
              onChange={(e) => setShowName(e.target.checked)}
            />
            اسم الصنف
          </label>
          <label style={{ display: "flex", gap: 6, alignItems: "center", fontSize: 13.5 }}>
            <input
              type="checkbox"
              style={{ width: 16 }}
              checked={showPrice}
              onChange={(e) => setShowPrice(e.target.checked)}
            />
            السعر
          </label>
          <div style={{ flex: 1 }} />
          <button
            className="btn ghost sm"
            onClick={() => setCounts({})}
            disabled={!totalLabels}
          >
            تصفير الأعداد
          </button>
        </div>
      </div>

      <div className="grid c2">
        <div className="table-wrap" style={{ maxHeight: "62vh" }}>
          {view.length === 0 ? (
            <Empty icon="🏷️" text="مفيش أصناف" />
          ) : (
            <table>
              <thead>
                <tr>
                  <th>الصنف</th>
                  <th>الباركود</th>
                  <th className="num">السعر</th>
                  <th className="num" style={{ width: 120 }}>
                    عدد الملصقات
                  </th>
                </tr>
              </thead>
              <tbody>
                {view.map((r) => (
                  <tr key={r.id}>
                    <td>
                      <div style={{ fontWeight: 600 }}>{r.name}</div>
                      <div style={{ fontSize: 11.5, color: "var(--ink-3)" }}>{r.code}</div>
                    </td>
                    <td style={{ fontSize: 12 }}>
                      {r.barcode || <span className="badge warn">مفيش باركود</span>}
                    </td>
                    <td className="num">{num(r.sell_price)}</td>
                    <td className="num">
                      <input
                        type="number"
                        min={0}
                        style={{ width: 90 }}
                        disabled={!r.barcode}
                        value={counts[r.id] ?? ""}
                        placeholder="0"
                        onChange={(e) =>
                          setCounts((s) => ({ ...s, [r.id]: e.target.value }))
                        }
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        <div>
          <div className="card" style={{ marginBottom: 12 }}>
            <div className="tot-row">
              <span>إجمالي الملصقات</span>
              <b>{num(totalLabels, 0)}</b>
            </div>
            <div className="tot-row">
              <span>عدد الصفحات التقريبي</span>
              <b>
                {num(
                  Math.ceil(totalLabels / (Number(cols) * (Number(cols) <= 3 ? 8 : 10))) ||
                    0,
                  0
                )}
              </b>
            </div>
            <div className="hint" style={{ marginTop: 6 }}>
              الباركود بيتولّد داخل البرنامج بصيغة CODE128 — من غير أي إنترنت.
            </div>
          </div>

          <div className="labels-preview">
            {totalLabels === 0 ? (
              <Empty icon="🏷️" text="حدد عدد الملصقات لكل صنف عشان تشوف المعاينة" />
            ) : (
              <div className={`labels-sheet cols-${cols}`}>
                {sheet.slice(0, 60).map((x, i) => (
                  <Label
                    key={i}
                    x={x}
                    shop={showShop ? settings.shop_name : ""}
                    showName={showName}
                    price={showPrice ? `${num(x.p.sell_price)} ${currency}` : ""}
                  />
                ))}
              </div>
            )}
          </div>
          {totalLabels > 60 && (
            <div className="hint" style={{ marginTop: 6 }}>
              المعاينة بتعرض أول ٦٠ ملصق — الطباعة هتطلع {totalLabels} كاملين.
            </div>
          )}
        </div>
      </div>

      {totalLabels > 0 &&
        createPortal(
          <div id="print-root">
            <div className={`labels-sheet cols-${cols}`}>
              {sheet.map((x, i) => (
                <Label
                  key={i}
                  x={x}
                  shop={showShop ? settings.shop_name : ""}
                  showName={showName}
                  price={showPrice ? `${num(x.p.sell_price)} ${currency}` : ""}
                />
              ))}
            </div>
          </div>,
          document.body
        )}
    </>
  );
}

function Label({
  x,
  shop,
  showName,
  price,
}: {
  x: { p: P; svg: string };
  shop: string;
  showName: boolean;
  price: string;
}) {
  return (
    <div className="label">
      {shop && <div className="lb-shop">{shop}</div>}
      {showName && <div className="lb-name">{x.p.name}</div>}
      <div dangerouslySetInnerHTML={{ __html: x.svg }} />
      <div className="lb-code">{x.p.barcode}</div>
      {price && <div className="lb-price">{price}</div>}
    </div>
  );
}
