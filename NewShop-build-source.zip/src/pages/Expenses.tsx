import { useCallback, useEffect, useMemo, useState } from "react";
import { batch, query, type Op } from "../lib/db";
import { useApp } from "../lib/app";
import { useAuth } from "../lib/auth";
import { dateAr, n2, normalizeAr, num, todayIso } from "../lib/format";
import { Confirm, Empty, Field, Modal } from "../components/ui";

const PRESETS = [
  "إيجار",
  "كهرباء",
  "مياه",
  "مرتبات",
  "نقل وشحن",
  "صيانة",
  "تليفون وإنترنت",
  "ضرائب ورسوم",
  "تسويق",
  "مصروفات نثرية",
];

const blank = {
  id: 0,
  date: todayIso(),
  category: "إيجار",
  amount: "",
  payment_method: "cash",
  note: "",
};

export default function Expenses() {
  const { toast, currency, shift } = useApp();
  const { user } = useAuth();
  const [from, setFrom] = useState(todayIso().slice(0, 8) + "01");
  const [to, setTo] = useState(todayIso());
  const [rows, setRows] = useState<any[]>([]);
  const [search, setSearch] = useState("");
  const [form, setForm] = useState<typeof blank | null>(null);
  const [delId, setDelId] = useState<number | null>(null);

  const load = useCallback(async () => {
    setRows(
      await query(
        `SELECT * FROM expenses WHERE date(date) BETWEEN ? AND ? AND status='posted'
          ORDER BY date DESC, id DESC LIMIT 1000`,
        [from, to]
      )
    );
  }, [from, to]);

  useEffect(() => {
    load().catch((e) => toast(String(e), "err"));
  }, [load, toast]);

  const view = useMemo(() => {
    const s = normalizeAr(search);
    if (!s) return rows;
    return rows.filter(
      (r) =>
        normalizeAr(r.category || "").includes(s) || normalizeAr(r.note || "").includes(s)
    );
  }, [rows, search]);

  const total = view.reduce((a, r) => a + n2(r.amount), 0);

  const byCat = useMemo(() => {
    const m = new Map<string, number>();
    for (const r of view) {
      const k = (r.category || "").trim() || "غير مصنّف";
      m.set(k, (m.get(k) || 0) + n2(r.amount));
    }
    return [...m.entries()].sort((a, b) => b[1] - a[1]);
  }, [view]);

  async function save() {
    if (!form) return;
    if (n2(form.amount) <= 0) return toast("اكتب مبلغ أكبر من صفر", "err");
    try {
      if (form.id) throw new Error("المصروف المرحّل لا يُعدّل؛ ألغِه وأنشئ مصروفًا جديدًا");
      const ops: Op[] = [{
        sql: `INSERT INTO expenses(date,category,amount,note,user_id,shift_id,payment_method,status)
              VALUES(?,?,?,?,?,?,?,'posted')`,
        params: [form.date,form.category,n2(form.amount),form.note.trim() || null,user?.id ?? null,shift?.id ?? null,form.payment_method],
      }];
      if (shift?.id && form.payment_method === "cash") {
        ops.push({
          sql: `INSERT INTO cash_movements(shift_id,movement_type,direction,amount,method,
                  reference_type,reference_id,user_id,note)
                VALUES(?,'expense','out',?,'cash','expense',?,?,?)`,
          params: [shift.id,n2(form.amount),"$LAST_ID:0",user?.id ?? null,form.category],
        });
      }
      ops.push({
        sql: `INSERT INTO audit_log(user_id,action,entity_type,entity_id,new_values)
              VALUES(?,'expense_posted','expense',?,?)`,
        params: [user?.id ?? null,"$LAST_ID:0",JSON.stringify({ amount: n2(form.amount), payment_method: form.payment_method })],
      });
      await batch(ops,"expenses");
      toast("تم الحفظ");
      setForm(null);
      await load();
    } catch (e) {
      toast(String(e), "err");
    }
  }

  async function remove(id: number) {
    try {
      const row = rows.find((r) => r.id === id);
      if (!row || row.status === "void") return;
      const ops: Op[] = [{ sql: `UPDATE expenses SET status='void' WHERE id=? AND status='posted'`, params: [id] }];
      if (row.shift_id && row.payment_method === "cash") {
        ops.push({
          sql: `INSERT INTO cash_movements(shift_id,movement_type,direction,amount,method,
                  reference_type,reference_id,user_id,note)
                VALUES(?,'expense_void','in',?,'cash','expense',?,?,?)`,
          params: [row.shift_id,n2(row.amount),id,user?.id ?? null,`إلغاء مصروف: ${row.category}`],
        });
      }
      ops.push({
        sql: `INSERT INTO audit_log(user_id,action,entity_type,entity_id,old_values,new_values,reason)
              VALUES(?,'expense_voided','expense',?,'posted','void','إلغاء من شاشة المصروفات')`,
        params: [user?.id ?? null,id],
      });
      await batch(ops,"expenses");
      toast("تم إلغاء المصروف مع تسجيل حركة عكسية");
      await load();
    } catch (e) {
      toast(String(e), "err");
    }
  }

  const set = (k: keyof typeof blank, v: string) =>
    setForm((f) => (f ? { ...f, [k]: v } : f));

  return (
    <>
      <div className="toolbar">
        <Field label="من تاريخ">
          <input type="date" value={from} onChange={(e) => setFrom(e.target.value)} />
        </Field>
        <Field label="إلى تاريخ">
          <input type="date" value={to} onChange={(e) => setTo(e.target.value)} />
        </Field>
        <div className="search-wrap" style={{ marginTop: 18 }}>
          <input
            placeholder="ابحث في البند أو الملاحظة…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
          <span className="ic">🔍</span>
        </div>
        <button
          className="btn"
          style={{ marginTop: 18 }}
          onClick={() => setForm({ ...blank, date: todayIso() })}
        >
          ＋ مصروف جديد
        </button>
      </div>

      <div className="grid c3" style={{ marginBottom: 14 }}>
        <div className="stat">
          <div className="ic">🧾</div>
          <div>
            <div className="lbl">عدد المصروفات</div>
            <div className="val">{num(view.length, 0)}</div>
          </div>
        </div>
        <div className="stat accent">
          <div className="ic">💸</div>
          <div>
            <div className="lbl">إجمالي المصروفات</div>
            <div className="val">{num(total)}</div>
          </div>
        </div>
        <div className="stat">
          <div className="ic">📊</div>
          <div>
            <div className="lbl">أكبر بند</div>
            <div className="val" style={{ fontSize: 17 }}>
              {byCat[0] ? `${byCat[0][0]} — ${num(byCat[0][1])}` : "—"}
            </div>
          </div>
        </div>
      </div>

      <div className="grid c2">
        <div className="table-wrap" style={{ maxHeight: "58vh" }}>
          {view.length === 0 ? (
            <Empty icon="💸" text="مفيش مصروفات في الفترة دي" />
          ) : (
            <table>
              <thead>
                <tr>
                  <th>التاريخ</th>
                  <th>البند</th>
                  <th className="num">المبلغ</th>
                  <th>طريقة الدفع</th>
                  <th>ملاحظة</th>
                  <th className="num">إجراءات</th>
                </tr>
              </thead>
              <tbody>
                {view.map((r) => (
                  <tr key={r.id}>
                    <td style={{ fontSize: 12, color: "var(--ink-3)" }}>{dateAr(r.date)}</td>
                    <td style={{ fontWeight: 600 }}>{r.category || "غير مصنّف"}</td>
                    <td className="num" style={{ fontWeight: 700 }}>
                      {num(r.amount)}
                    </td>
                    <td>{r.payment_method === "cash" ? "نقدي" : r.payment_method === "card" ? "كارت" : r.payment_method === "wallet" ? "محفظة" : "بنكي"}</td>
                    <td style={{ fontSize: 12, color: "var(--ink-3)" }}>{r.note || "—"}</td>
                    <td>
                      <div className="row-actions">
                        <button
                          className="icon-btn danger"
                          title="إلغاء بقيد عكسي"
                          onClick={() => setDelId(r.id)}
                        >
                          🗑
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        <div className="card">
          <h3>المصروفات حسب البند</h3>
          {byCat.length === 0 ? (
            <Empty icon="📊" text="لا توجد بيانات" />
          ) : (
            byCat.map(([k, v]) => (
              <div key={k} style={{ marginBottom: 10 }}>
                <div className="tot-row" style={{ padding: "2px 0" }}>
                  <span>{k}</span>
                  <b>
                    {num(v)} {currency}
                  </b>
                </div>
                <div
                  style={{
                    height: 8,
                    background: "var(--surface-2)",
                    borderRadius: 6,
                    overflow: "hidden",
                  }}
                >
                  <div
                    style={{
                      width: `${total ? (v / total) * 100 : 0}%`,
                      height: "100%",
                      background: "var(--primary)",
                    }}
                  />
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {form && (
        <Modal
          title={form.id ? "تعديل مصروف" : "مصروف جديد"}
          onClose={() => setForm(null)}
          footer={
            <>
              <button className="btn" onClick={() => void save()}>
                حفظ
              </button>
              <button className="btn ghost" onClick={() => setForm(null)}>
                إلغاء
              </button>
            </>
          }
        >
          <div className="grid c2">
            <Field label="التاريخ">
              <input
                type="date"
                value={form.date}
                onChange={(e) => set("date", e.target.value)}
              />
            </Field>
            <Field label={`المبلغ (${currency}) *`}>
              <input
                autoFocus
                type="number"
                step="0.01"
                value={form.amount}
                onChange={(e) => set("amount", e.target.value)}
              />
            </Field>
            <Field label="طريقة الدفع">
              <select value={form.payment_method} onChange={(e) => set("payment_method", e.target.value)}>
                <option value="cash">نقدي — يؤثر على درج الوردية</option>
                <option value="card">كارت</option>
                <option value="wallet">محفظة</option>
                <option value="bank">تحويل بنكي</option>
              </select>
            </Field>
          </div>
          <div style={{ marginTop: 12 }}>
            <Field label="البند" hint="اختر من القائمة أو اكتب بند جديد">
              <input
                list="exp-cats"
                value={form.category}
                onChange={(e) => set("category", e.target.value)}
              />
            </Field>
            <datalist id="exp-cats">
              {PRESETS.map((x) => (
                <option key={x} value={x} />
              ))}
            </datalist>
          </div>
          <div style={{ marginTop: 12 }}>
            <Field label="ملاحظة">
              <textarea value={form.note} onChange={(e) => set("note", e.target.value)} />
            </Field>
          </div>
        </Modal>
      )}

      {delId !== null && (
        <Confirm
          danger
          title="إلغاء مصروف"
          message="سيظل المصروف محفوظًا في السجل، وتُسجّل حركة عكسية إذا كان مدفوعًا نقدًا. تكمل؟"
          confirmText="إلغاء المصروف"
          onConfirm={() => void remove(delId)}
          onClose={() => setDelId(null)}
        />
      )}
    </>
  );
}
