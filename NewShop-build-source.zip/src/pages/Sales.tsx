import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { batch, execute, query } from "../lib/db";
import { useApp } from "../lib/app";
import { useAuth } from "../lib/auth";
import { dateTimeAr, n2, normalizeAr, num, qty as fq } from "../lib/format";
import {
  computeTotals,
  discardSuspendedSale,
  getInvoice,
  listSuspendedSales,
  lineTotal,
  loadSuspendedSale,
  nextInvoiceNo,
  round2,
  saveSale,
  suspendSale,
  type CartLine,
  type InvoiceHead,
  type InvoiceLine,
  type PayMethod,
  type PaySplit,
  type SuspendedSale,
} from "../lib/sales";
import { parseScaleBarcode, scaleConfig, scaleQty } from "../lib/scale";
import { Confirm, Empty, Field, ManagerApprove, Modal } from "../components/ui";
import InvoicePrint from "../components/InvoicePrint";

interface P {
  id: number;
  code: string;
  name: string;
  barcode: string | null;
  barcodes: string | null;
  plu: string | null;
  unit: string;
  cost_price: number;
  sell_price: number;
  wholesale_price: number;
  price_level_special: number | null;
  qty: number;
}

interface Customer {
  id: number;
  name: string;
  phone: string | null;
  balance: number;
}

export default function Sales() {
  const { toast, settings, currency, shift } = useApp();
  const { user, can } = useAuth();
  const [products, setProducts] = useState<P[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [lines, setLines] = useState<CartLine[]>([]);
  const [invNo, setInvNo] = useState("—");

  const [search, setSearch] = useState("");
  const [hi, setHi] = useState(0);
  const searchRef = useRef<HTMLInputElement>(null);

  const [discMode, setDiscMode] = useState<"value" | "percent">("value");
  const [discRaw, setDiscRaw] = useState("");

  const [pay, setPay] = useState(false);
  /** المبالغ المدخّلة لكل طريقة دفع (نص عشان الحقل يفضل فاضي) */
  const [amounts, setAmounts] = useState<Partial<Record<PayMethod, string>>>({});
  const [custId, setCustId] = useState<string>("");
  const [newCust, setNewCust] = useState("");
  const [notes, setNotes] = useState("");
  const [priceLevel, setPriceLevel] = useState<"retail" | "wholesale" | "special">("retail");

  const [over, setOver] = useState<{ p: P; add: number; avail: number } | null>(null);
  const [clearAsk, setClearAsk] = useState(false);
  const [holdAsk, setHoldAsk] = useState(false);
  const [holdLabel, setHoldLabel] = useState("");
  const [resumeOpen, setResumeOpen] = useState(false);
  const [suspended, setSuspended] = useState<SuspendedSale[]>([]);
  const [printData, setPrintData] = useState<{
    head: InvoiceHead;
    lines: InvoiceLine[];
    payments: PaySplit[];
  } | null>(null);
  const [copyPrint, setCopyPrint] = useState(false);

  const allowNeg = settings.allow_negative_stock === "1";
  const scale = useMemo(() => scaleConfig(settings), [settings]);

  /* ---------- تحميل البيانات ---------- */
  const load = useCallback(async () => {
    setProducts(
      await query<P>(
        `SELECT p.id,p.code,p.name,p.barcode,p.plu,p.unit,p.cost_price,p.sell_price,
                p.wholesale_price,p.price_level_special,p.qty,
                (SELECT GROUP_CONCAT(pb.barcode,'|') FROM product_barcodes pb
                  WHERE pb.product_id=p.id) AS barcodes
           FROM products p WHERE p.is_active = 1 ORDER BY p.name COLLATE NOCASE`
      )
    );
    setCustomers(
      await query<Customer>(`SELECT id, name, phone, balance FROM customers ORDER BY name`)
    );
    setInvNo((await nextInvoiceNo()).no);
  }, []);

  useEffect(() => {
    load().catch((e) => toast(String(e), "err"));
  }, [load, toast]);

  /* ---------- البحث ---------- */
  const hasBarcode = useCallback(
    (p: P, raw: string) =>
      (p.barcode || "") === raw || (p.barcodes || "").split("|").includes(raw),
    []
  );

  const sugg = useMemo(() => {
    const raw = search.trim();
    if (!raw) return [] as P[];
    const s = normalizeAr(raw);
    const inCart = new Map(lines.map((l) => [l.product_id, l.qty]));
    return products
      .filter(
        (p) =>
          hasBarcode(p, raw) ||
          normalizeAr(p.name).includes(s) ||
          normalizeAr(p.code || "").includes(s)
      )
      .sort((a, b) => {
        const ax = hasBarcode(a, raw) ? 0 : 1;
        const bx = hasBarcode(b, raw) ? 0 : 1;
        return ax - bx || (inCart.has(b.id) ? 0 : 1) - (inCart.has(a.id) ? 0 : 1);
      })
      .slice(0, 8);
  }, [search, products, lines, hasBarcode]);

  useEffect(() => setHi(0), [search]);

  /* ---------- السلة ---------- */
  const inCartQty = useCallback(
    (id: number) => lines.find((l) => l.product_id === id)?.qty ?? 0,
    [lines]
  );

  const priceFor = useCallback((p: P, level = priceLevel) => {
    if (level === "wholesale") return n2(p.wholesale_price) || n2(p.sell_price);
    if (level === "special") return n2(p.price_level_special) || n2(p.sell_price);
    return n2(p.sell_price);
  }, [priceLevel]);

  const pushLine = useCallback((p: P, add: number) => {
    setLines((cur) => {
      const i = cur.findIndex((l) => l.product_id === p.id);
      if (i >= 0) {
        const c = [...cur];
        c[i] = { ...c[i], qty: n2(c[i].qty) + add };
        return c;
      }
      return [
        ...cur,
        {
          product_id: p.id,
          code: p.code,
          name: p.name,
          unit: p.unit,
          qty: add,
          price: priceFor(p),
          cost: n2(p.cost_price),
          discount: 0,
          stock: n2(p.qty),
        },
      ];
    });
  }, [priceFor]);

  function changePriceLevel(level: "retail" | "wholesale" | "special") {
    setPriceLevel(level);
    setLines((current) => current.map((line) => {
      const product = products.find((p) => p.id === line.product_id);
      return product ? { ...line, price: priceFor(product, level), discount: 0 } : line;
    }));
  }

  /** تنفيذ التجاوز بعد الموافقة، مع تسجيله في سجل النشاط */
  const doOverride = useCallback(
    async (approver?: { id: number; username: string }) => {
      if (!over) return;
      const { p, add, avail } = over;
      setOver(null);
      pushLine(p, add);
      setSearch("");
      searchRef.current?.focus();
      try {
        await execute(
          `INSERT INTO activity_log(user_id, action, details) VALUES(?, 'override_stock', ?)`,
          [
            user?.id ?? null,
            `تجاوز المخزون: «${p.name}» — المتاح ${avail}، المطلوب ${add}` +
              (approver ? ` — بموافقة ${approver.username}` : " — بصلاحية المستخدم نفسه"),
          ]
        );
      } catch {
        /* تسجيل السجل مايوقفش البيع */
      }
    },
    [over, pushLine, user]
  );

  const addProduct = useCallback(
    (p: P, add = 1) => {
      const avail = n2(p.qty) - inCartQty(p.id);
      if (!allowNeg && add > avail) {
        setOver({ p, add, avail });
        return;
      }
      pushLine(p, add);
      setSearch("");
      searchRef.current?.focus();
    },
    [allowNeg, inCartQty, pushLine]
  );

  function onSearchKey(e: React.KeyboardEvent<HTMLInputElement>) {
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setHi((h) => Math.min(h + 1, sugg.length - 1));
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setHi((h) => Math.max(h - 1, 0));
    } else if (e.key === "Enter") {
      e.preventDefault();
      const raw = search.trim();
      if (!raw) return;

      // باركود الميزان الأول — جوّاه الوزن أو السعر
      const read = parseScaleBarcode(raw, scale);
      if (read) {
        const prod = products.find(
          (p) => (p.plu || "").trim() === read.plu || (p.code || "").trim() === read.plu
        );
        if (!prod) {
          toast(`مفيش صنف بكود الميزان ${read.plu}`, "err");
          return;
        }
        const q = scaleQty(read, priceFor(prod));
        if (q <= 0) {
          toast("الكمية المقروءة من الباركود صفر", "err");
          return;
        }
        addProduct(prod, q);
        return;
      }

      // الماسح بيبعت الباركود وبعده Enter — أولوية للمطابقة التامة
      const exact = products.find((p) => hasBarcode(p, raw));
      const pick = exact || sugg[hi];
      if (pick) addProduct(pick, 1);
      else toast("مفيش صنف بالكود ده", "err");
    }
  }

  function setQty(i: number, v: number) {
    setLines((cur) => {
      const c = [...cur];
      const l = c[i];
      const prod = products.find((p) => p.id === l.product_id);
      let q = Math.max(0, v);
      if (!allowNeg && prod && q > n2(prod.qty)) {
        q = n2(prod.qty);
        toast(`المتاح من «${l.name}» هو ${fq(prod.qty)} بس`, "err");
      }
      c[i] = { ...l, qty: q };
      return c;
    });
  }

  const patch = (i: number, k: keyof CartLine, v: number) =>
    setLines((cur) => {
      const c = [...cur];
      c[i] = { ...c[i], [k]: Math.max(0, v) };
      return c;
    });

  function patchDiscount(i: number, value: number) {
    const line = lines[i];
    if (!can("discount_line") && value > 0) {
      toast("مالكش صلاحية خصم على الصنف", "err");
      return;
    }
    const base = n2(line.qty) * n2(line.price);
    const maxPct = user?.role === "owner" || user?.role === "admin" ? 100 : n2(user?.max_line_discount);
    const maxValue = round2((base * maxPct) / 100);
    if (value > maxValue) toast(`الحد الأقصى لخصم الصنف ${maxPct}%`, "err");
    patch(i, "discount", Math.min(Math.max(0, value), maxValue));
  }

  const removeLine = (i: number) => setLines((c) => c.filter((_, x) => x !== i));

  /* ---------- الإجماليات ---------- */
  const subtotal = useMemo(() => lines.reduce((s, l) => s + lineTotal(l), 0), [lines]);
  const invoiceDiscount = useMemo(() => {
    const d = n2(discRaw);
    const roleMax = user?.role === "owner" || user?.role === "admin" ? 100 : n2(user?.max_invoice_discount);
    const maxPct = can("discount_invoice") ? roleMax : 0;
    const rawValue = discMode === "percent" ? (subtotal * Math.min(d, 100)) / 100 : Math.min(d, subtotal);
    return round2(Math.min(rawValue, (subtotal * maxPct) / 100));
  }, [discRaw, discMode, subtotal, user, can]);

  /* ---------- طرق الدفع ---------- */
  // الطرق اللي صاحب المحل مفعّلها من الإعدادات
  const methods = useMemo(
    () =>
      (
        [
          { key: "cash" as const, on: settings.pay_cash !== "0", label: "نقدي" },
          {
            key: "card" as const,
            on: settings.pay_card === "1",
            label: settings.pay_card_label || "فيزا",
          },
          {
            key: "wallet" as const,
            on: settings.pay_wallet === "1",
            label: settings.pay_wallet_label || "محفظة",
          },
        ] as { key: PayMethod; on: boolean; label: string }[]
      ).filter((m) => m.on),
    [settings]
  );

  const allowCredit = settings.pay_credit !== "0";
  const taxMode = settings.tax_enabled === "1"
    ? (settings.tax_mode === "inclusive" ? "inclusive" : "exclusive")
    : "disabled";
  const taxRate = taxMode === "disabled" ? 0 : Math.max(0, n2(settings.tax_rate));

  /** المبالغ المدخّلة فعليًا (أكبر من صفر) */
  const splits: PaySplit[] = useMemo(
    () =>
      methods
        .map((m) => ({ method: m.key, amount: n2(amounts[m.key] ?? "") }))
        .filter((s) => s.amount > 0),
    [methods, amounts]
  );

  const activeMethods = splits.map((s) => s.method);
  const received = round2(splits.reduce((s, x) => s + x.amount, 0));

  const totals = useMemo(
    () => computeTotals(lines, invoiceDiscount, received, taxRate, taxMode),
    [lines, invoiceDiscount, received, taxRate, taxMode]
  );

  const change = Math.max(0, round2(received - totals.total));

  /** يحط الباقي من الإجمالي في طريقة معيّنة */
  const fillRest = useCallback(
    (m: PayMethod) => {
      const others = splits
        .filter((s) => s.method !== m)
        .reduce((s, x) => s + x.amount, 0);
      const rest = round2(Math.max(0, totals.total - others));
      setAmounts((a) => ({ ...a, [m]: rest ? String(rest) : "" }));
    },
    [splits, totals.total]
  );

  /** يدفع الإجمالي كله بطريقة واحدة */
  const payAllWith = useCallback(
    (m: PayMethod) => setAmounts({ [m]: String(totals.total) }),
    [totals.total]
  );

  /** يفتح نافذة التحصيل والمبلغ كله على أول طريقة دفع مفعّلة */
  function openPayment() {
    const first = methods[0]?.key;
    setAmounts(first ? { [first]: String(totals.total) } : {});
    setPay(true);
  }

  /* ---------- الحفظ ---------- */
  function newInvoice() {
    setLines([]);
    setSearch("");
    setDiscRaw("");
    setAmounts({});
    setCustId("");
    setNotes("");
    setPrintData(null);
    setCopyPrint(false);
    searchRef.current?.focus();
  }

  async function holdCurrent() {
    if (!lines.length) return toast("الفاتورة فاضية", "err");
    try {
      await suspendSale({
        label: holdLabel,
        lines,
        customerId: custId ? Number(custId) : null,
        invoiceDiscount,
        notes,
        userId: user?.id ?? null,
        priceLevel,
      });
      setHoldAsk(false);
      setHoldLabel("");
      newInvoice();
      toast("تم تعليق الفاتورة بدون التأثير على المخزون");
    } catch (e) {
      toast(String(e), "err");
    }
  }

  async function openResume() {
    try {
      setSuspended(await listSuspendedSales());
      setResumeOpen(true);
    } catch (e) {
      toast(String(e), "err");
    }
  }

  async function resume(id: number) {
    try {
      const saved = await loadSuspendedSale(id);
      if (!saved) throw new Error("الفاتورة المعلقة غير موجودة");
      setLines(saved.lines);
      setCustId(saved.head.customer_id ? String(saved.head.customer_id) : "");
      setDiscMode("value");
      setDiscRaw(saved.head.invoice_discount ? String(saved.head.invoice_discount) : "");
      setNotes(saved.head.notes || "");
      setPriceLevel(saved.head.price_level || "retail");
      await discardSuspendedSale(id, user?.id ?? null);
      setResumeOpen(false);
      toast("تم استئناف الفاتورة بكل بياناتها");
      searchRef.current?.focus();
    } catch (e) {
      toast(String(e), "err");
    }
  }

  async function confirmSale(alsoPrint: boolean) {
    if (!lines.length) return toast("الفاتورة فاضية", "err");
    if (settings.shift_required === "1" && !shift)
      return toast("لازم تفتح وردية الأول من شاشة «الورديات والدرج»", "err");
    if (lines.some((l) => n2(l.qty) <= 0))
      return toast("في صنف كميته صفر — امسحه أو غيّر الكمية", "err");

    const remaining = round2(Math.max(0, totals.total - received));
    if (remaining > 0 && !allowCredit)
      return toast("البيع الآجل مقفول من الإعدادات — كمّل المبلغ", "err");
    if (remaining > 0 && !custId)
      return toast("البيع الآجل لازم يكون على عميل — اختر العميل", "err");

    try {
      const res = await saveSale({
        lines,
        customerId: custId ? Number(custId) : null,
        invoiceDiscount,
        paid: Math.min(received, totals.total),
        splits,
        notes: notes.trim() || undefined,
        userId: user?.id ?? null,
        shiftId: shift?.id ?? null,
        priceLevel,
        taxRate,
        taxMode,
      });
      toast(`اتحفظت الفاتورة ${res.invoiceNo}`);
      setPay(false);

      const inv = await getInvoice(res.id);
      if (inv) {
        setCopyPrint(false);
        setPrintData(inv);
        if (alsoPrint) setTimeout(() => window.print(), 120);
      }
      setLines([]);
      setSearch("");
      setDiscRaw("");
      setAmounts({});
      setCustId("");
      setNotes("");
      await load();
      searchRef.current?.focus();
    } catch (e) {
      toast(String(e), "err");
    }
  }

  async function reprintLast() {
    if (!printData) return;
    if (!can("sales_reprint")) return toast("مالكش صلاحية إعادة الطباعة", "err");
    try {
      await batch([{
        sql: `INSERT INTO audit_log(user_id,action,entity_type,entity_id,new_values)
              VALUES(?,'invoice_reprinted','sale',?,?)`,
        params: [user?.id ?? null,printData.head.id,JSON.stringify({ invoice_no: printData.head.invoice_no })],
      }],"sales_reprint");
      setCopyPrint(true);
      setTimeout(() => window.print(),120);
    } catch (e) {
      toast(String(e),"err");
    }
  }

  async function addCustomer() {
    const nm = newCust.trim();
    if (!nm) return;
    try {
      const r = await execute(`INSERT INTO customers(name) VALUES(?)`, [nm]);
      setNewCust("");
      setCustomers(
        await query<Customer>(`SELECT id, name, phone, balance FROM customers ORDER BY name`)
      );
      setCustId(String(r.last_insert_id));
      toast("تمت إضافة العميل");
    } catch (e) {
      toast(String(e), "err");
    }
  }

  /* ---------- اختصارات الكيبورد ---------- */
  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      const el = document.activeElement as HTMLElement | null;
      const typing = !!el && ["INPUT", "TEXTAREA", "SELECT"].includes(el.tagName);
      // لو في نافذة مفتوحة سيبها تتصرف لوحدها
      if (document.querySelector(".modal-back")) return;

      if (e.key === "F2") {
        e.preventDefault();
        lines.length ? setClearAsk(true) : newInvoice();
      } else if (e.key === "F3") {
        e.preventDefault();
        searchRef.current?.focus();
        searchRef.current?.select();
      } else if (e.key === "F4") {
        e.preventDefault();
        if (lines.length) {
          openPayment();
        } else toast("الفاتورة فاضية", "err");
      } else if (e.key === "F6") {
        e.preventDefault();
        if (lines.length) setHoldAsk(true);
        else toast("الفاتورة فاضية", "err");
      } else if (e.key === "F7") {
        e.preventDefault();
        void openResume();
      } else if (e.key === "Escape") {
        if (!typing && lines.length) setClearAsk(true);
      } else if (!typing && e.key.length === 1 && !e.ctrlKey && !e.altKey) {
        // الماسح بيكتب زي الكيبورد — نوجّه الحروف لخانة البحث تلقائيًا
        searchRef.current?.focus();
      }
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [lines.length, totals.total]);

  useEffect(() => {
    searchRef.current?.focus();
  }, []);

  const selectedCustomer = customers.find((c) => String(c.id) === custId);

  return (
    <>
      <div className="pos">
        <div className="pos-main">
          <div className="pos-search">
            <input
              ref={searchRef}
              value={search}
              placeholder="امسح الباركود أو اكتب اسم الصنف…  (F3)"
              onChange={(e) => setSearch(e.target.value)}
              onKeyDown={onSearchKey}
            />
            <span className="ic">🔍</span>
            {sugg.length > 0 && (
              <div className="sugg">
                {sugg.map((p, i) => {
                  const avail = n2(p.qty) - inCartQty(p.id);
                  return (
                    <div
                      key={p.id}
                      className={`sugg-row${i === hi ? " on" : ""}`}
                      onMouseEnter={() => setHi(i)}
                      onMouseDown={(e) => {
                        e.preventDefault();
                        addProduct(p, 1);
                      }}
                    >
                      <div className="nm">
                        {p.name}
                        <div className="meta">
                          {p.code} {p.barcode ? `· ${p.barcode}` : ""} · المتاح{" "}
                          {fq(avail)} {p.unit}
                        </div>
                      </div>
                      <div className="pr">{num(priceFor(p))}</div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          <div className="cart-wrap">
            {lines.length === 0 ? (
              <Empty icon="🛒" text="ابدأ بمسح الباركود أو البحث عن صنف" />
            ) : (
              <table>
                <thead>
                  <tr>
                    <th style={{ width: 40 }}>م</th>
                    <th>الصنف</th>
                    <th className="num" style={{ width: 110 }}>
                      الكمية
                    </th>
                    <th className="num" style={{ width: 110 }}>
                      السعر
                    </th>
                    <th className="num" style={{ width: 110 }}>
                      خصم
                    </th>
                    <th className="num" style={{ width: 110 }}>
                      الإجمالي
                    </th>
                    <th style={{ width: 50 }}></th>
                  </tr>
                </thead>
                <tbody>
                  {lines.map((l, i) => (
                    <tr key={l.product_id}>
                      <td className="num">{i + 1}</td>
                      <td>
                        <div style={{ fontWeight: 600 }}>{l.name}</div>
                        <div style={{ fontSize: 11.5, color: "var(--ink-3)" }}>
                          {l.code} · الوحدة: {l.unit}
                        </div>
                      </td>
                      <td className="num">
                        <input
                          type="number"
                          step="0.001"
                          value={l.qty}
                          onChange={(e) => setQty(i, Number(e.target.value))}
                        />
                      </td>
                      <td className="num">
                        <input
                          type="number"
                          step="0.01"
                          value={l.price}
                          disabled={!can("edit_prices")}
                          title={can("edit_prices") ? "" : "مالكش صلاحية تعديل الأسعار"}
                          onChange={(e) => patch(i, "price", Number(e.target.value))}
                        />
                      </td>
                      <td className="num">
                        <input
                          type="number"
                          step="0.01"
                          value={l.discount}
                          disabled={!can("discount_line")}
                          onChange={(e) => patchDiscount(i, Number(e.target.value))}
                        />
                      </td>
                      <td className="num" style={{ fontWeight: 800 }}>
                        {num(lineTotal(l))}
                      </td>
                      <td>
                        <button
                          className="icon-btn danger"
                          title="مسح السطر"
                          onClick={() => removeLine(i)}
                        >
                          ✕
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>

        <aside className="pos-side">
          <div className="tot-card">
            {settings.price_levels_enabled !== "0" && (
              <div className="tot-row" style={{ alignItems: "center" }}>
                <span>مستوى السعر</span>
                <select
                  aria-label="مستوى السعر"
                  value={priceLevel}
                  onChange={(e) => changePriceLevel(e.target.value as typeof priceLevel)}
                  style={{ width: 126 }}
                >
                  <option value="retail">قطاعي</option>
                  <option value="wholesale">جملة</option>
                  <option value="special">خاص</option>
                </select>
              </div>
            )}
            <div className="tot-row">
              <span>رقم الفاتورة</span>
              <b>{invNo}</b>
            </div>
            <div className="tot-row">
              <span>عدد الأصناف</span>
              <b>{lines.length}</b>
            </div>
            <div className="tot-row">
              <span>المجموع</span>
              <b>{num(subtotal)}</b>
            </div>

            <div style={{ marginTop: 10 }}>
              <label
                style={{ fontSize: 12.5, fontWeight: 600, color: "var(--ink-2)" }}
              >
                خصم على الفاتورة
              </label>
              <div className="disc-row" style={{ marginTop: 5 }}>
                <input
                  type="number"
                  step="0.01"
                  value={discRaw}
                  placeholder="0"
                  disabled={!can("discount_invoice")}
                  onChange={(e) => setDiscRaw(e.target.value)}
                />
                <div className="seg">
                  <button
                    className={discMode === "value" ? "on" : ""}
                    onClick={() => setDiscMode("value")}
                  >
                    قيمة
                  </button>
                  <button
                    className={discMode === "percent" ? "on" : ""}
                    onClick={() => setDiscMode("percent")}
                  >
                    %
                  </button>
                </div>
              </div>
              {invoiceDiscount > 0 && (
                <div className="tot-row">
                  <span>قيمة الخصم</span>
                  <b style={{ color: "var(--danger)" }}>− {num(invoiceDiscount)}</b>
                </div>
              )}
              {totals.tax > 0 && (
                <div className="tot-row">
                  <span>الضريبة ({num(taxRate)}%)</span>
                  <b>{num(totals.tax)}</b>
                </div>
              )}
            </div>

            <div className="tot-grand">
              <span>الإجمالي</span>
              <span className="v">{num(totals.total)}</span>
            </div>
            <div
              className="tot-row"
              style={{ justifyContent: "center", color: "var(--ink-3)", fontSize: 12 }}
            >
              {currency}
            </div>
          </div>

          <div className="pos-actions">
            <button
              className="btn"
              disabled={!lines.length}
              onClick={() => {
                openPayment();
              }}
            >
              💵 تحصيل وحفظ <span className="kbd">F4</span>
            </button>
            <button className="btn ghost" disabled={!lines.length} onClick={() => setHoldAsk(true)}>
              ⏸ تعليق الفاتورة <span className="kbd">F6</span>
            </button>
            <button className="btn ghost" onClick={() => void openResume()}>
              ▶ استئناف فاتورة <span className="kbd">F7</span>
            </button>
            <button
              className="btn ghost"
              onClick={() => (lines.length ? setClearAsk(true) : newInvoice())}
            >
              🧾 فاتورة جديدة <span className="kbd">F2</span>
            </button>
            {printData && (
              <button className="btn accent" onClick={() => void reprintLast()}>
                🖨️ طباعة آخر فاتورة ({printData.head.invoice_no})
              </button>
            )}
          </div>

          <div className="card" style={{ fontSize: 12, color: "var(--ink-3)", lineHeight: 2 }}>
            <b style={{ color: "var(--ink-2)" }}>اختصارات:</b>
            <div>F2 — فاتورة جديدة</div>
            <div>F3 — البحث عن صنف</div>
            <div>F4 — التحصيل</div>
            <div>F6 — تعليق الفاتورة</div>
            <div>F7 — استئناف فاتورة معلقة</div>
            <div>Esc — إلغاء الفاتورة الحالية</div>
            <div style={{ marginTop: 6 }}>
              الماسح بيشتغل من غير أي إعدادات — امسح الباركود على طول.
            </div>
          </div>
        </aside>
      </div>

      {/* نافذة التحصيل */}
      {pay && (
        <Modal
          title={`تحصيل الفاتورة ${invNo}`}
          onClose={() => setPay(false)}
          footer={
            <>
              <button className="btn" onClick={() => void confirmSale(true)}>
                💾 حفظ وطباعة
              </button>
              <button className="btn ghost" onClick={() => void confirmSale(false)}>
                حفظ بدون طباعة
              </button>
              <button className="btn ghost" onClick={() => setPay(false)}>
                رجوع
              </button>
            </>
          }
        >
          <div className="tot-grand" style={{ marginBottom: 14 }}>
            <span>المطلوب</span>
            <span className="v">
              {num(totals.total)} {currency}
            </span>
          </div>

          <div className="pay-grid" style={{ marginBottom: 14 }}>
            <button
              className={`pay-opt${
                received >= totals.total && activeMethods.length === 1 ? " on" : ""
              }`}
              onClick={() => payAllWith(methods[0]?.key ?? "cash")}
            >
              {methods[0]?.label ?? "نقدي"} بالكامل
            </button>
            <button
              className={`pay-opt${received === 0 ? " on" : ""}`}
              onClick={() => setAmounts({})}
              disabled={!allowCredit}
              title={allowCredit ? "" : "البيع الآجل مقفول من الإعدادات"}
            >
              آجل بالكامل
            </button>
            <button
              className={`pay-opt${activeMethods.length > 1 ? " on" : ""}`}
              onClick={() => setAmounts({})}
            >
              مقسّم — حدّد المبالغ تحت
            </button>
          </div>

          {/* مبالغ كل طريقة دفع */}
          <div className="pay-rows">
            {methods.map((m, i) => (
              <div className="pay-row" key={m.key}>
                <label htmlFor={`pay-${m.key}`}>{m.label}</label>
                <input
                  id={`pay-${m.key}`}
                  autoFocus={i === 0}
                  type="number"
                  step="0.01"
                  min="0"
                  placeholder="0"
                  value={amounts[m.key] ?? ""}
                  onChange={(e) =>
                    setAmounts((a) => ({ ...a, [m.key]: e.target.value }))
                  }
                  onKeyDown={(e) => e.key === "Enter" && void confirmSale(true)}
                />
                <button
                  type="button"
                  className="btn ghost sm"
                  title="حط الباقي كله هنا"
                  onClick={() => fillRest(m.key)}
                >
                  الباقي
                </button>
              </div>
            ))}
          </div>

          <div style={{ marginTop: 12 }}>
            <Field label="العميل" hint="مطلوب لو في متبقي آجل">
              <select value={custId} onChange={(e) => setCustId(e.target.value)}>
                <option value="">— عميل نقدي —</option>
                {customers.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                    {n2(c.balance) ? ` (عليه ${num(c.balance)})` : ""}
                  </option>
                ))}
              </select>
            </Field>
          </div>

          <div style={{ display: "flex", gap: 8, alignItems: "flex-end", marginTop: 10 }}>
            <Field label="إضافة عميل جديد بسرعة">
              <input
                value={newCust}
                placeholder="اسم العميل"
                onChange={(e) => setNewCust(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    e.preventDefault();
                    void addCustomer();
                  }
                }}
              />
            </Field>
            <button className="btn ghost" onClick={() => void addCustomer()}>
              ＋ إضافة
            </button>
          </div>

          <div className="grid c2" style={{ marginTop: 14 }}>
            <div className="card" style={{ padding: 10 }}>
              <div className="tot-row">
                <span>المدفوع</span>
                <b>{num(Math.min(received, totals.total))}</b>
              </div>
              <div className="tot-row">
                <span>المتبقي على العميل</span>
                <b style={{ color: totals.remaining > 0 ? "var(--danger)" : "var(--ok)" }}>
                  {num(Math.max(0, totals.total - received))}
                </b>
              </div>
              <div className="tot-row">
                <span>الباقي للعميل</span>
                <b style={{ color: "var(--accent-dark)" }}>{num(change)}</b>
              </div>
            </div>
            <Field label="ملاحظات على الفاتورة">
              <textarea
                style={{ minHeight: 84 }}
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
              />
            </Field>
          </div>

          {selectedCustomer && (
            <div className="hint" style={{ marginTop: 8 }}>
              رصيد {selectedCustomer.name} الحالي: {num(selectedCustomer.balance)}{" "}
              {currency}
              {totals.total - received > 0 &&
                ` → هيبقى ${num(
                  n2(selectedCustomer.balance) + (totals.total - received)
                )}`}
            </div>
          )}
        </Modal>
      )}

      {/* تجاوز المخزون — لو المستخدم مش معاه الصلاحية، لازم موافقة مدير */}
      {over &&
        (can("override_stock") ? (
          <Confirm
            danger
            title="الكمية أكبر من المخزون"
            message={`المتاح من «${over.p.name}» هو ${fq(over.avail)} ${over.p.unit} بس. تحب تكمل وتبيع بكمية أكبر؟`}
            confirmText="تجاوز وأضف"
            onConfirm={() => void doOverride()}
            onClose={() => setOver(null)}
          />
        ) : (
          <ManagerApprove
            perm="override_stock"
            title="الكمية أكبر من المخزون"
            message={`المتاح من «${over.p.name}» هو ${fq(over.avail)} ${over.p.unit} بس، وانت طالب ${fq(over.add)}. العملية دي محتاجة موافقة مدير.`}
            confirmText="موافقة وإضافة"
            onApprove={(approver) => void doOverride(approver)}
            onClose={() => setOver(null)}
          />
        ))}

      {clearAsk && (
        <Confirm
          danger
          title="إلغاء الفاتورة الحالية"
          message="هيتم مسح كل الأصناف من الفاتورة الحالية. تكمل؟"
          confirmText="امسح"
          onConfirm={newInvoice}
          onClose={() => setClearAsk(false)}
        />
      )}

      {holdAsk && (
        <Modal
          title="تعليق الفاتورة"
          onClose={() => setHoldAsk(false)}
          footer={
            <>
              <button className="btn" onClick={() => void holdCurrent()}>تعليق</button>
              <button className="btn ghost" onClick={() => setHoldAsk(false)}>رجوع</button>
            </>
          }
        >
          <Field label="اسم اختياري" hint="مثال: طلب التوصيل أو اسم العميل">
            <input autoFocus value={holdLabel} onChange={(e) => setHoldLabel(e.target.value)} />
          </Field>
          <div className="hint" style={{ marginTop: 10 }}>
            سيتم حفظ الأصناف والكميات والأسعار والخصومات والعميل والملاحظات، بدون خصم مخزون.
          </div>
        </Modal>
      )}

      {resumeOpen && (
        <Modal wide title="الفواتير المعلقة" onClose={() => setResumeOpen(false)}>
          {suspended.length === 0 ? (
            <Empty icon="⏸" text="لا توجد فواتير معلقة" />
          ) : (
            <div className="table-wrap" style={{ boxShadow: "none" }}>
              <table>
                <thead><tr><th>الاسم</th><th>التاريخ</th><th className="num">الأصناف</th><th className="num">الإجمالي</th><th /></tr></thead>
                <tbody>
                  {suspended.map((s) => (
                    <tr key={s.id}>
                      <td>{s.label || `فاتورة معلقة #${s.id}`}</td>
                      <td>{dateTimeAr(s.created_at)}</td>
                      <td className="num">{s.item_count}</td>
                      <td className="num">{num(s.total)}</td>
                      <td><button className="btn sm" onClick={() => void resume(s.id)}>استئناف</button></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Modal>
      )}

      {printData && (
        <InvoicePrint
          head={printData.head}
          lines={printData.lines}
          payments={printData.payments}
          copy={copyPrint}
        />
      )}
    </>
  );
}
