import { useCallback, useEffect, useState } from "react";
import { execute, query } from "../lib/db";
import { useApp } from "../lib/app";
import { dateAr, num } from "../lib/format";
import { Confirm, Empty, Field, Modal } from "../components/ui";

interface Cat {
  id: number;
  name: string;
  created_at: string;
  products: number;
}

export default function Categories() {
  const { toast } = useApp();
  const [rows, setRows] = useState<Cat[]>([]);
  const [form, setForm] = useState<{ id: number; name: string } | null>(null);
  const [delId, setDelId] = useState<number | null>(null);

  const load = useCallback(async () => {
    setRows(
      await query<Cat>(
        `SELECT c.*, (SELECT COUNT(*) FROM products p WHERE p.category_id = c.id) AS products
           FROM categories c ORDER BY c.name COLLATE NOCASE`
      )
    );
  }, []);

  useEffect(() => {
    load().catch((e) => toast(String(e), "err"));
  }, [load, toast]);

  async function save() {
    if (!form) return;
    const name = form.name.trim();
    if (!name) return toast("اكتب اسم التصنيف", "err");
    try {
      if (form.id)
        await execute(`UPDATE categories SET name=? WHERE id=?`, [name, form.id]);
      else await execute(`INSERT INTO categories(name) VALUES(?)`, [name]);
      toast("تم الحفظ");
      setForm(null);
      await load();
    } catch (e) {
      toast(
        String(e).includes("UNIQUE") ? "التصنيف ده موجود بالفعل" : String(e),
        "err"
      );
    }
  }

  async function remove(id: number) {
    try {
      await execute(`UPDATE products SET category_id=NULL WHERE category_id=?`, [id]);
      await execute(`DELETE FROM categories WHERE id=?`, [id]);
      toast("تم حذف التصنيف");
      await load();
    } catch (e) {
      toast(String(e), "err");
    }
  }

  return (
    <>
      <div className="toolbar">
        <div style={{ flex: 1 }} />
        <button className="btn" onClick={() => setForm({ id: 0, name: "" })}>
          ＋ تصنيف جديد
        </button>
      </div>

      <div className="table-wrap">
        {rows.length === 0 ? (
          <Empty icon="🏷️" text="مفيش تصنيفات" />
        ) : (
          <table>
            <thead>
              <tr>
                <th>التصنيف</th>
                <th className="num">عدد الأصناف</th>
                <th>تاريخ الإضافة</th>
                <th className="num">إجراءات</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((c) => (
                <tr key={c.id}>
                  <td style={{ fontWeight: 600 }}>{c.name}</td>
                  <td className="num">{num(c.products, 0)}</td>
                  <td style={{ fontSize: 12, color: "var(--ink-3)" }}>
                    {dateAr(c.created_at)}
                  </td>
                  <td>
                    <div className="row-actions">
                      <button
                        className="icon-btn"
                        title="تعديل"
                        onClick={() => setForm({ id: c.id, name: c.name })}
                      >
                        ✏️
                      </button>
                      <button
                        className="icon-btn danger"
                        title="حذف"
                        onClick={() => setDelId(c.id)}
                      >
                        🗑
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {form && (
        <Modal
          title={form.id ? "تعديل تصنيف" : "تصنيف جديد"}
          onClose={() => setForm(null)}
          footer={
            <>
              <button className="btn" onClick={() => void save()}>
                حفظ
              </button>
              <button className="btn ghost" onClick={() => setForm(null)}>
                إلغاء
              </button>
            </>
          }
        >
          <Field label="اسم التصنيف">
            <input
              autoFocus
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              onKeyDown={(e) => e.key === "Enter" && void save()}
            />
          </Field>
        </Modal>
      )}

      {delId !== null && (
        <Confirm
          danger
          title="حذف تصنيف"
          message="الأصناف اللي في التصنيف ده هتفضل موجودة بس من غير تصنيف. تكمل؟"
          confirmText="احذف"
          onConfirm={() => void remove(delId)}
          onClose={() => setDelId(null)}
        />
      )}
    </>
  );
}
