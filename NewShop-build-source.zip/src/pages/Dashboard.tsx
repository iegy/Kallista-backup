import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { query } from "../lib/db";
import { useApp } from "../lib/app";
import { PAY_LABELS } from "../lib/sales";
import { useAuth } from "../lib/auth";
import { dateTimeAr, money, num, qty } from "../lib/format";
import { Empty, Stat } from "../components/ui";
import Alerts from "../components/Alerts";

interface Totals {
  sales: number;
  count: number;
  profit: number;
  low: number;
  stockValue: number;
}

export default function Dashboard() {
  const { currency, toast } = useApp();
  const { can } = useAuth();
  const [t, setT] = useState<Totals>({
    sales: 0,
    count: 0,
    profit: 0,
    low: 0,
    stockValue: 0,
  });
  const [lowItems, setLowItems] = useState<any[]>([]);
  const [last, setLast] = useState<any[]>([]);

  useEffect(() => {
    (async () => {
      const [a] = await query<any>(
        `SELECT COALESCE(SUM(total),0)-COALESCE((SELECT SUM(total) FROM returns
                  WHERE type='sale' AND status='posted' AND date(date)=date('now','localtime')),0) AS total,
                COUNT(*) AS cnt
           FROM sales WHERE date(date)=date('now','localtime') AND document_state<>'void'`
      );
      const [b] = can("view_profits")
        ? await query<any>(
        `SELECT COALESCE(SUM(si.line_net_total-si.tax_amount-si.cost_at_sale*si.qty),0)-COALESCE((
                  SELECT SUM(ri.total-ri.tax_amount-ri.cost_at_sale*ri.qty)
                    FROM return_items ri JOIN returns r ON r.id=ri.return_id
                   WHERE r.type='sale' AND r.status='posted'
                     AND date(r.date)=date('now','localtime')),0) AS gross
           FROM sale_items si JOIN sales s ON s.id = si.sale_id
          WHERE date(s.date)=date('now','localtime') AND s.document_state<>'void'`
          )
        : [{ gross: 0 }];
      const [c] = await query<any>(
        `SELECT 0 AS d`
      );
      const [e] = await query<any>(
        `SELECT COALESCE(SUM(amount),0) AS x FROM expenses
          WHERE date(date)=date('now','localtime') AND status='posted'`
      );
      const [l] = await query<any>(
        `SELECT COUNT(*) AS n FROM products WHERE is_active=1 AND qty <= min_qty`
      );
      const [v] = can("view_cost")
        ? await query<any>(
            `SELECT COALESCE(SUM(qty * cost_price),0) AS v FROM products WHERE is_active=1`
          )
        : [{ v: 0 }];

      setT({
        sales: Number(a?.total || 0),
        count: Number(a?.cnt || 0),
        profit: Number(b?.gross || 0) - Number(c?.d || 0) - Number(e?.x || 0),
        low: Number(l?.n || 0),
        stockValue: Number(v?.v || 0),
      });

      setLowItems(
        await query(
          `SELECT id, code, name, qty, min_qty, unit FROM products
            WHERE is_active=1 AND qty <= min_qty ORDER BY (qty - min_qty) ASC LIMIT 8`
        )
      );
      setLast(
        await query(
          `SELECT s.id, s.invoice_no, s.date, s.total, s.payment_type, s.remaining,
                  COALESCE(c.name,'عميل نقدي') AS customer
             FROM sales s LEFT JOIN customers c ON c.id = s.customer_id
            WHERE s.document_state<>'void' ORDER BY s.id DESC LIMIT 5`
        )
      );
    })().catch((err) => toast(String(err), "err"));
  }, [toast, can]);

  const payLabel = (p: string) => PAY_LABELS[p] || p;

  return (
    <>
      <Alerts />

      <div className="grid c4">
        <Stat icon="💰" label="مبيعات النهارده" value={money(t.sales, currency)} />
        <Stat icon="🧾" label="عدد الفواتير" value={num(t.count, 0)} />
        {can("view_profits") ? (
          <Stat
            icon="📈"
            label="صافي ربح النهارده"
            value={money(t.profit, currency)}
            accent
          />
        ) : (
          <Stat icon="🔒" label="صافي الربح" value="—" accent />
        )}
        <Stat icon="⚠️" label="أصناف ناقصة" value={num(t.low, 0)} accent />
      </div>

      <div className="grid c2" style={{ marginTop: 14 }}>
        <div className="card">
          <h3>الأصناف الناقصة</h3>
          {lowItems.length === 0 ? (
            <Empty icon="✅" text="مفيش أصناف تحت الحد الأدنى" />
          ) : (
            <div className="table-wrap" style={{ boxShadow: "none", border: "none" }}>
              <table>
                <thead>
                  <tr>
                    <th>الصنف</th>
                    <th className="num">المتاح</th>
                    <th className="num">الحد الأدنى</th>
                    <th className="num">الحالة</th>
                  </tr>
                </thead>
                <tbody>
                  {lowItems.map((p) => (
                    <tr key={p.id}>
                      <td>{p.name}</td>
                      <td className="num">
                        {qty(p.qty)} {p.unit}
                      </td>
                      <td className="num">{qty(p.min_qty)}</td>
                      <td className="num">
                        <span className={`badge ${Number(p.qty) <= 0 ? "danger" : "warn"}`}>
                          {Number(p.qty) <= 0 ? "خلص" : "قارب على الانتهاء"}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
          <div style={{ marginTop: 10 }}>
            <Link className="btn ghost sm" to="/products">
              فتح الأصناف
            </Link>
          </div>
        </div>

        <div className="card">
          <h3>آخر ٥ فواتير</h3>
          {last.length === 0 ? (
            <Empty icon="🧾" text="لسه مفيش فواتير" />
          ) : (
            <div className="table-wrap" style={{ boxShadow: "none", border: "none" }}>
              <table>
                <thead>
                  <tr>
                    <th>رقم الفاتورة</th>
                    <th>العميل</th>
                    <th>التاريخ</th>
                    <th className="num">الإجمالي</th>
                    <th className="num">الدفع</th>
                  </tr>
                </thead>
                <tbody>
                  {last.map((s) => (
                    <tr key={s.id}>
                      <td>{s.invoice_no}</td>
                      <td>{s.customer}</td>
                      <td style={{ fontSize: 12, color: "var(--ink-3)" }}>
                        {dateTimeAr(s.date)}
                      </td>
                      <td className="num">{num(s.total)}</td>
                      <td className="num">
                        <span
                          className={`badge ${
                            Number(s.remaining) > 0 ? "warn" : "ok"
                          }`}
                        >
                          {payLabel(s.payment_type)}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {can("view_profits") && (
        <div className="card" style={{ marginTop: 14 }}>
          <h3>تقييم المخزن الحالي (بسعر التكلفة)</h3>
          <div style={{ fontSize: 26, fontWeight: 800 }}>
            {money(t.stockValue, currency)}
          </div>
        </div>
      )}
    </>
  );
}
