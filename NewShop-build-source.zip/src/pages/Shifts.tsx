import { useCallback, useEffect, useMemo, useState } from "react";
import { useApp } from "../lib/app";
import { useAuth } from "../lib/auth";
import { dateTimeAr, n2, num } from "../lib/format";
import { PAY_LABELS } from "../lib/sales";
import {
  closeShift,
  listShifts,
  moveCash,
  shiftReport,
  startShift,
  type Shift,
  type ShiftReport,
} from "../lib/shifts";
import { Empty, Field, Modal, Stat } from "../components/ui";
import ShiftReportPrint from "../components/ShiftReportPrint";

export default function Shifts() {
  const { toast, currency, shift, reloadShift } = useApp();
  const { user, can } = useAuth();

  const [rows, setRows] = useState<Shift[]>([]);
  const [rep, setRep] = useState<ShiftReport | null>(null);

  const [openBox, setOpenBox] = useState(false);
  const [opening, setOpening] = useState("");
  const [openNotes, setOpenNotes] = useState("");

  const [cashBox, setCashBox] = useState<"in" | "out" | null>(null);
  const [cashAmt, setCashAmt] = useState("");
  const [cashWhy, setCashWhy] = useState("");

  const [closeBox, setCloseBox] = useState(false);
  const [counted, setCounted] = useState("");
  const [closeNotes, setCloseNotes] = useState("");

  const [print, setPrint] = useState<{ rep: ShiftReport; kind: "X" | "Z" } | null>(null);

  const load = useCallback(async () => {
    setRows(await listShifts());
    await reloadShift();
  }, [reloadShift]);

  useEffect(() => {
    load().catch((e) => toast(String(e), "err"));
  }, [load, toast]);

  // تقرير مباشر للوردية المفتوحة
  const refreshReport = useCallback(async () => {
    if (!shift) return setRep(null);
    try {
      setRep(await shiftReport(shift.id));
    } catch (e) {
      toast(String(e), "err");
    }
  }, [shift, toast]);

  useEffect(() => {
    void refreshReport();
  }, [refreshReport]);

  const diffOfCounted = useMemo(() => {
    if (!rep) return 0;
    return Math.round((n2(counted) - rep.expectedCash) * 100) / 100;
  }, [counted, rep]);

  async function doOpen() {
    if (!can("shifts_open")) return toast("ليس لديك صلاحية فتح وردية", "err");
    try {
      await startShift(user?.id ?? null, n2(opening), openNotes);
      setOpenBox(false);
      setOpening("");
      setOpenNotes("");
      toast("اتفتحت الوردية");
      await load();
    } catch (e) {
      toast(String(e), "err");
    }
  }

  async function doCash() {
    if (!shift || !cashBox) return;
    try {
      const amt = cashBox === "in" ? n2(cashAmt) : -n2(cashAmt);
      await moveCash(shift.id, amt, cashWhy, user?.id ?? null);
      setCashBox(null);
      setCashAmt("");
      setCashWhy("");
      toast(cashBox === "in" ? "تم الإيداع" : "تم السحب");
      await refreshReport();
    } catch (e) {
      toast(String(e), "err");
    }
  }

  async function doClose() {
    if (!shift) return;
    if (!can("shifts_close")) return toast("ليس لديك صلاحية إغلاق الوردية", "err");
    try {
      const r = await closeShift(shift.id, n2(counted), closeNotes, user?.id ?? null);
      setCloseBox(false);
      setCounted("");
      setCloseNotes("");
      toast("اتقفلت الوردية");
      setPrint({ rep: r, kind: "Z" });
      await load();
      setTimeout(() => window.print(), 200);
    } catch (e) {
      toast(String(e), "err");
    }
  }

  async function printOld(id: number) {
    try {
      const r = await shiftReport(id);
      setPrint({ rep: r, kind: r.shift.status === "closed" ? "Z" : "X" });
      setTimeout(() => window.print(), 200);
    } catch (e) {
      toast(String(e), "err");
    }
  }

  return (
    <>
      {/* ===== الوردية المفتوحة ===== */}
      {shift && rep ? (
        <>
          <div className="grid c4">
            <Stat icon="🧾" label="عدد الفواتير" value={String(rep.invoices)} />
            <Stat icon="💰" label="إجمالي المبيعات" value={`${num(rep.salesTotal)} ${currency}`} />
            <Stat icon="💵" label="مبيعات نقدي" value={`${num(rep.byMethod.cash)} ${currency}`} />
            <Stat
              icon="🗄️"
              label="المفروض في الدرج"
              value={`${num(rep.expectedCash)} ${currency}`}
              accent
            />
          </div>

          <div className="card">
            <h3>
              وردية #{shift.id} — {shift.user_name || "—"} · فتحت{" "}
              {dateTimeAr(shift.opened_at)}
            </h3>

            <div className="grid c2">
              <div>
                <div className="sh-sub">المبيعات حسب طريقة الدفع</div>
                <table className="sh-table">
                  <tbody>
                    {(["cash", "card", "wallet", "credit"] as const).map((m) => (
                      <tr key={m}>
                        <td>{PAY_LABELS[m]}</td>
                        <td className="num">{num(rep.byMethod[m])}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div>
                <div className="sh-sub">حركة الدرج</div>
                <table className="sh-table">
                  <tbody>
                    <tr>
                      <td>رصيد البداية</td>
                      <td className="num">{num(shift.opening_cash)}</td>
                    </tr>
                    <tr>
                      <td>+ مبيعات نقدي</td>
                      <td className="num">{num(rep.byMethod.cash)}</td>
                    </tr>
                    <tr>
                      <td>+ تحصيلات نقدي</td>
                      <td className="num">{num(rep.collections.cash)}</td>
                    </tr>
                    <tr>
                      <td>+ مسترد نقدي من موردين</td>
                      <td className="num">{num(rep.purchaseRefunds)}</td>
                    </tr>
                    <tr>
                      <td>+ إيداع يدوي</td>
                      <td className="num">{num(rep.cashIn)}</td>
                    </tr>
                    <tr>
                      <td>− مرتجعات كاش</td>
                      <td className="num">{num(rep.cashRefunds)}</td>
                    </tr>
                    <tr>
                      <td>− مدفوعات موردين</td>
                      <td className="num">{num(rep.supplierPaid.cash)}</td>
                    </tr>
                    <tr>
                      <td>− مصروفات</td>
                      <td className="num">{num(rep.expenses)}</td>
                    </tr>
                    <tr>
                      <td>− سحب يدوي</td>
                      <td className="num">{num(rep.cashOut)}</td>
                    </tr>
                    <tr className="sh-total">
                      <td>المفروض في الدرج</td>
                      <td className="num">{num(rep.expectedCash)}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            <div style={{ display: "flex", gap: 8, marginTop: 16, flexWrap: "wrap" }}>
              <button className="btn ghost" onClick={() => setCashBox("in")}>
                ＋ إيداع في الدرج
              </button>
              <button className="btn ghost" onClick={() => setCashBox("out")}>
                − سحب من الدرج
              </button>
              <button
                className="btn ghost"
                disabled={!can("shifts_close")}
                onClick={() => {
                  setPrint({ rep, kind: "X" });
                  setTimeout(() => window.print(), 200);
                }}
              >
                🖨️ كشف X
              </button>
              <button
                className="btn accent"
                onClick={() => {
                  setCounted("");
                  setCloseBox(true);
                }}
              >
                🔒 تقفيل الوردية (Z)
              </button>
            </div>

            {rep.moves.length > 0 && (
              <>
                <div className="sh-sub" style={{ marginTop: 16 }}>
                  حركات الدرج اليدوية
                </div>
                <table className="sh-table">
                  <tbody>
                    {rep.moves.map((m, i) => (
                      <tr key={i}>
                        <td>{dateTimeAr(m.date)}</td>
                        <td>{m.reason}</td>
                        <td
                          className="num"
                          style={{ color: m.amount < 0 ? "var(--danger)" : "var(--ok)" }}
                        >
                          {num(m.amount)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </>
            )}
          </div>
        </>
      ) : (
        <div className="card">
          <Empty icon="🕒" text="مفيش وردية مفتوحة دلوقتي" />
          <div style={{ textAlign: "center" }}>
            <button className="btn" disabled={!can("shifts_open")} onClick={() => setOpenBox(true)}>
              ▶️ فتح وردية جديدة
            </button>
          </div>
        </div>
      )}

      {/* ===== الورديات السابقة ===== */}
      <div className="card">
        <h3>الورديات السابقة</h3>
        {rows.length === 0 ? (
          <Empty text="لسه مفيش ورديات" />
        ) : (
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>#</th>
                  <th>الكاشير</th>
                  <th>فتحت</th>
                  <th>قفلت</th>
                  <th className="num">بداية</th>
                  <th className="num">المفروض</th>
                  <th className="num">المعدود</th>
                  <th className="num">الفرق</th>
                  <th>الحالة</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {rows.map((s) => (
                  <tr key={s.id}>
                    <td>{s.id}</td>
                    <td>{s.user_name || "—"}</td>
                    <td>{dateTimeAr(s.opened_at)}</td>
                    <td>{s.closed_at ? dateTimeAr(s.closed_at) : "—"}</td>
                    <td className="num">{num(s.opening_cash)}</td>
                    <td className="num">
                      {s.expected_cash === null ? "—" : num(s.expected_cash)}
                    </td>
                    <td className="num">
                      {s.counted_cash === null ? "—" : num(s.counted_cash)}
                    </td>
                    <td
                      className="num"
                      style={{
                        color:
                          s.diff === null
                            ? undefined
                            : Number(s.diff) < 0
                              ? "var(--danger)"
                              : Number(s.diff) > 0
                                ? "var(--warn)"
                                : "var(--ok)",
                        fontWeight: 700,
                      }}
                    >
                      {s.diff === null ? "—" : num(s.diff)}
                    </td>
                    <td>
                      <span className={`badge ${s.status === "open" ? "warn" : "ok"}`}>
                        {s.status === "open" ? "مفتوحة" : "مقفولة"}
                      </span>
                    </td>
                    <td>
                      <button
                        className="icon-btn"
                        title="طباعة التقرير"
                        onClick={() => void printOld(s.id)}
                      >
                        🖨️
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* ===== فتح وردية ===== */}
      {openBox && (
        <Modal
          title="فتح وردية جديدة"
          onClose={() => setOpenBox(false)}
          footer={
            <>
              <button className="btn" onClick={() => void doOpen()}>
                فتح الوردية
              </button>
              <button className="btn ghost" onClick={() => setOpenBox(false)}>
                إلغاء
              </button>
            </>
          }
        >
          <Field
            label={`رصيد بداية الدرج (${currency})`}
            hint="الفلوس اللي في الدرج دلوقتي قبل أي بيع"
          >
            <input
              autoFocus
              type="number"
              step="0.01"
              value={opening}
              onChange={(e) => setOpening(e.target.value)}
            />
          </Field>
          <div style={{ marginTop: 12 }}>
            <Field label="ملاحظات">
              <input value={openNotes} onChange={(e) => setOpenNotes(e.target.value)} />
            </Field>
          </div>
        </Modal>
      )}

      {/* ===== إيداع / سحب ===== */}
      {cashBox && shift && (
        <Modal
          title={cashBox === "in" ? "إيداع في الدرج" : "سحب من الدرج"}
          onClose={() => setCashBox(null)}
          footer={
            <>
              <button className="btn" onClick={() => void doCash()}>
                تأكيد
              </button>
              <button className="btn ghost" onClick={() => setCashBox(null)}>
                إلغاء
              </button>
            </>
          }
        >
          <Field label={`المبلغ (${currency})`}>
            <input
              autoFocus
              type="number"
              step="0.01"
              value={cashAmt}
              onChange={(e) => setCashAmt(e.target.value)}
            />
          </Field>
          <div style={{ marginTop: 12 }}>
            <Field
              label="السبب"
              hint={cashBox === "in" ? "مثال: فكّة من الخزنة" : "مثال: توريد للخزنة"}
            >
              <input
                value={cashWhy}
                onChange={(e) => setCashWhy(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && void doCash()}
              />
            </Field>
          </div>
        </Modal>
      )}

      {/* ===== تقفيل ===== */}
      {closeBox && rep && (
        <Modal
          title={`تقفيل وردية #${rep.shift.id}`}
          onClose={() => setCloseBox(false)}
          footer={
            <>
              <button className="btn accent" onClick={() => void doClose()}>
                تقفيل وطباعة تقرير Z
              </button>
              <button className="btn ghost" onClick={() => setCloseBox(false)}>
                رجوع
              </button>
            </>
          }
        >
          <div className="tot-grand" style={{ marginBottom: 14 }}>
            <span>المفروض في الدرج</span>
            <span className="v">
              {num(rep.expectedCash)} {currency}
            </span>
          </div>

          <Field
            label={`اللي معاك فعلًا في الدرج (${currency})`}
            hint="عُدّ الفلوس واكتب الرقم الحقيقي — البرنامج هيحسب الفرق"
          >
            <input
              autoFocus
              type="number"
              step="0.01"
              value={counted}
              onChange={(e) => setCounted(e.target.value)}
            />
          </Field>

          {counted !== "" && (
            <div
              className="gate-err"
              style={
                diffOfCounted === 0
                  ? { background: "var(--ok-soft)", color: "var(--ok)" }
                  : diffOfCounted > 0
                    ? { background: "var(--warn-soft)", color: "var(--warn)" }
                    : undefined
              }
            >
              {diffOfCounted === 0
                ? "مظبوط تمامًا ✔"
                : diffOfCounted > 0
                  ? `زيادة ${num(diffOfCounted)} ${currency}`
                  : `عجز ${num(Math.abs(diffOfCounted))} ${currency}`}
            </div>
          )}

          <div style={{ marginTop: 12 }}>
            <Field label="ملاحظات التقفيل">
              <input value={closeNotes} onChange={(e) => setCloseNotes(e.target.value)} />
            </Field>
          </div>
        </Modal>
      )}

      {print && <ShiftReportPrint rep={print.rep} kind={print.kind} />}
    </>
  );
}
