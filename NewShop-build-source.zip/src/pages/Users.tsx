import { useCallback, useEffect, useMemo, useState } from "react";
import { invoke } from "@tauri-apps/api/core";
import { isTauri, query, sessionToken } from "../lib/db";
import { useApp } from "../lib/app";
import { dateAr } from "../lib/format";
import {
  ALL_PERMS,
  CASHIER_PERMS,
  PERMS,
  useAuth,
} from "../lib/auth";
import { Confirm, Empty, Field, Modal } from "../components/ui";

interface Row {
  id: number;
  username: string;
  full_name: string | null;
  role: string;
  permissions: string | null;
  is_active: number;
  created_at: string;
  max_line_discount: number;
  max_invoice_discount: number;
}

const blank = {
  id: 0,
  username: "",
  full_name: "",
  role: "cashier",
  password: "",
  is_active: 1,
  perms: CASHIER_PERMS as string[],
  max_line_discount: 10,
  max_invoice_discount: 10,
};

export default function Users() {
  const { toast } = useApp();
  const { user } = useAuth();
  const [rows, setRows] = useState<Row[]>([]);
  const [form, setForm] = useState<typeof blank | null>(null);
  const [delId, setDelId] = useState<number | null>(null);
  const [log, setLog] = useState<any[]>([]);

  const load = useCallback(async () => {
    setRows(await query<Row>(`SELECT * FROM users ORDER BY id`));
    setLog(
      await query(
        `SELECT a.*, COALESCE(u.full_name, u.username, '—') AS who
           FROM activity_log a LEFT JOIN users u ON u.id = a.user_id
          ORDER BY a.id DESC LIMIT 40`
      )
    );
  }, []);

  useEffect(() => {
    load().catch((e) => toast(String(e), "err"));
  }, [load, toast]);

  const groups = useMemo(() => {
    const m = new Map<string, typeof PERMS>();
    for (const p of PERMS) {
      if (!m.has(p.group)) m.set(p.group, []);
      m.get(p.group)!.push(p);
    }
    return [...m.entries()];
  }, []);

  async function save() {
    if (!form) return;
    const u = form.username.trim();
    if (!u) return toast("اكتب اسم المستخدم", "err");
    if (!form.id && form.password.length < 8)
      return toast("كلمة السر يجب ألا تقل عن ٨ أحرف", "err");

    try {
      const perms = form.role === "admin" || form.role === "owner" ? ALL_PERMS : form.perms;
      if (isTauri()) {
        await invoke("user_save", {
          sessionToken: sessionToken(),
          input: {
            id: form.id || null,
            username: u,
            full_name: form.full_name.trim() || null,
            role: form.role === "owner" ? "admin" : form.role,
            permissions: perms,
            is_active: form.is_active,
            password: form.password.trim() || null,
            max_line_discount: Number(form.max_line_discount),
            max_invoice_discount: Number(form.max_invoice_discount),
          },
        });
      } else {
        throw new Error("تعديل المستخدمين متاح داخل تطبيق Windows فقط");
      }
      toast("تم الحفظ");
      setForm(null);
      await load();
    } catch (e) {
      toast(
        String(e).includes("UNIQUE") ? "اسم المستخدم ده موجود بالفعل" : String(e),
        "err"
      );
    }
  }

  async function remove(id: number) {
    if (id === user?.id) return toast("مينفعش تحذف الحساب اللي داخل بيه", "err");
    const admins = rows.filter((r) => r.role === "admin" && r.is_active);
    const target = rows.find((r) => r.id === id);
    if (target?.role === "admin" && admins.length <= 1)
      return toast("لازم يفضل مدير واحد على الأقل", "err");
    try {
      if (!isTauri()) throw new Error("إيقاف المستخدمين متاح داخل تطبيق Windows فقط");
      await invoke("user_deactivate", {
        sessionToken: sessionToken(),
        userId: id,
        reason: "إيقاف من شاشة إدارة المستخدمين",
      });
      toast("تم إيقاف المستخدم");
      await load();
    } catch (e) {
      toast(String(e), "err");
    }
  }

  const set = (k: keyof typeof blank, v: any) =>
    setForm((f) => (f ? { ...f, [k]: v } : f));

  const togglePerm = (key: string) =>
    setForm((f) =>
      f
        ? {
            ...f,
            perms: f.perms.includes(key)
              ? f.perms.filter((x) => x !== key)
              : [...f.perms, key],
          }
        : f
    );

  return (
    <>
      <div className="toolbar">
        <div style={{ flex: 1 }} />
        <button className="btn" onClick={() => setForm({ ...blank })}>
          ＋ مستخدم جديد
        </button>
      </div>

      <div className="table-wrap">
        {rows.length === 0 ? (
          <Empty icon="👤" text="مفيش مستخدمين" />
        ) : (
          <table>
            <thead>
              <tr>
                <th>اسم المستخدم</th>
                <th>الاسم</th>
                <th className="num">الدور</th>
                <th className="num">عدد الصلاحيات</th>
                <th>تاريخ الإضافة</th>
                <th className="num">الحالة</th>
                <th className="num">إجراءات</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => {
                let perms: string[] = [];
                try {
                  perms = r.permissions ? JSON.parse(r.permissions) : [];
                } catch {
                  perms = [];
                }
                return (
                  <tr key={r.id} style={!r.is_active ? { opacity: 0.5 } : undefined}>
                    <td style={{ fontWeight: 700, fontFamily: "monospace" }}>
                      {r.username}
                      {r.id === user?.id && (
                        <span className="badge ok" style={{ marginRight: 6 }}>
                          أنت
                        </span>
                      )}
                    </td>
                    <td>{r.full_name || "—"}</td>
                    <td className="num">
                      <span className={`badge ${r.role === "admin" ? "warn" : ""}`}>
                        {r.role === "owner" ? "المالك" : r.role === "admin" ? "مدير" : "كاشير"}
                      </span>
                    </td>
                    <td className="num">
                      {r.role === "admin" || r.role === "owner" ? "الكل" : perms.length}
                    </td>
                    <td style={{ fontSize: 12, color: "var(--ink-3)" }}>
                      {dateAr(r.created_at)}
                    </td>
                    <td className="num">
                      <span className={`badge ${r.is_active ? "ok" : "danger"}`}>
                        {r.is_active ? "مفعّل" : "موقوف"}
                      </span>
                    </td>
                    <td>
                      <div className="row-actions">
                        <button
                          className="icon-btn"
                          title="تعديل"
                          onClick={() =>
                            setForm({
                              id: r.id,
                              username: r.username,
                              full_name: r.full_name || "",
                              role: r.role,
                              password: "",
                              is_active: r.is_active,
                              perms,
                              max_line_discount: Number(r.max_line_discount ?? 10),
                              max_invoice_discount: Number(r.max_invoice_discount ?? 10),
                            })
                          }
                        >
                          ✏️
                        </button>
                        {r.is_active === 1 && (
                          <button
                            className="icon-btn danger"
                            title="إيقاف"
                            onClick={() => setDelId(r.id)}
                          >
                            🚫
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>

      <div className="card" style={{ marginTop: 14 }}>
        <h3>آخر النشاطات</h3>
        {log.length === 0 ? (
          <Empty icon="📜" text="مفيش نشاط مسجل" />
        ) : (
          <div className="table-wrap" style={{ boxShadow: "none", maxHeight: 260 }}>
            <table>
              <thead>
                <tr>
                  <th>التاريخ</th>
                  <th>المستخدم</th>
                  <th>الحدث</th>
                  <th>التفاصيل</th>
                </tr>
              </thead>
              <tbody>
                {log.map((l) => (
                  <tr key={l.id}>
                    <td style={{ fontSize: 12, color: "var(--ink-3)" }}>{l.date}</td>
                    <td>{l.who}</td>
                    <td>{l.action}</td>
                    <td style={{ fontSize: 12, color: "var(--ink-3)" }}>
                      {l.details || "—"}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {form && (
        <Modal
          wide
          title={form.id ? `تعديل المستخدم ${form.username}` : "مستخدم جديد"}
          onClose={() => setForm(null)}
          footer={
            <>
              <button className="btn" onClick={() => void save()}>
                حفظ
              </button>
              <button className="btn ghost" onClick={() => setForm(null)}>
                إلغاء
              </button>
            </>
          }
        >
          <div className="grid c2">
            <Field label="اسم المستخدم *">
              <input
                autoFocus
                value={form.username}
                style={{ fontFamily: "monospace" }}
                onChange={(e) => set("username", e.target.value)}
              />
            </Field>
            <Field label="الاسم بالكامل">
              <input
                value={form.full_name}
                onChange={(e) => set("full_name", e.target.value)}
              />
            </Field>
            <Field
              label={form.id ? "كلمة سر جديدة" : "كلمة السر *"}
              hint={form.id ? "سيبها فاضية لو مش عايز تغيّرها" : "٨ أحرف على الأقل"}
            >
              <input
                type="password"
                value={form.password}
                onChange={(e) => set("password", e.target.value)}
              />
            </Field>
            <Field label="الدور">
              <select
                value={form.role}
                disabled={form.role === "owner"}
                onChange={(e) => set("role", e.target.value)}
              >
                <option value="cashier">كاشير</option>
                <option value="admin">مدير (كل الصلاحيات)</option>
                {form.role === "owner" && <option value="owner">المالك — محمي</option>}
              </select>
            </Field>
          </div>

          {form.role === "cashier" && (
            <div style={{ marginTop: 16 }}>
              <label style={{ fontSize: 13, fontWeight: 700 }}>الصلاحيات</label>
              <div style={{ display: "flex", gap: 8, margin: "8px 0" }}>
                <button
                  className="btn ghost sm"
                  onClick={() => set("perms", [...ALL_PERMS])}
                >
                  تحديد الكل
                </button>
                <button className="btn ghost sm" onClick={() => set("perms", [])}>
                  إلغاء الكل
                </button>
                <button
                  className="btn ghost sm"
                  onClick={() => set("perms", [...CASHIER_PERMS])}
                >
                  الافتراضي للكاشير
                </button>
              </div>
              <div className="perm-grid">
                {groups.map(([g, items]) => (
                  <div key={g} style={{ display: "contents" }}>
                    <div className="perm-group">{g}</div>
                    {items.map((p) => (
                      <label key={p.key} className="perm-item">
                        <input
                          type="checkbox"
                          checked={form.perms.includes(p.key)}
                          onChange={() => togglePerm(p.key)}
                        />
                        {p.label}
                      </label>
                    ))}
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="grid c2" style={{ marginTop: 14 }}>
            <Field label="أقصى خصم على الصنف %">
              <input
                type="number"
                min="0"
                max="100"
                value={form.max_line_discount}
                onChange={(e) => set("max_line_discount", Number(e.target.value))}
              />
            </Field>
            <Field label="أقصى خصم على الفاتورة %">
              <input
                type="number"
                min="0"
                max="100"
                value={form.max_invoice_discount}
                onChange={(e) => set("max_invoice_discount", Number(e.target.value))}
              />
            </Field>
          </div>

          <div style={{ marginTop: 14 }}>
            <Field label="الحالة">
              <select
                value={String(form.is_active)}
                onChange={(e) => set("is_active", Number(e.target.value))}
                style={{ maxWidth: 220 }}
              >
                <option value="1">مفعّل</option>
                <option value="0">موقوف</option>
              </select>
            </Field>
          </div>
        </Modal>
      )}

      {delId !== null && (
        <Confirm
          danger
          title="إيقاف مستخدم"
          message="المستخدم مش هيقدر يدخل البرنامج تاني. بياناته وحركاته هتفضل محفوظة."
          confirmText="أوقف"
          onConfirm={() => void remove(delId)}
          onClose={() => setDelId(null)}
        />
      )}
    </>
  );
}
