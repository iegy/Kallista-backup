import { useCallback, useEffect, useMemo, useState } from "react";
import { execute, query } from "../lib/db";
import { useApp } from "../lib/app";
import { useAuth } from "../lib/auth";
import { dateTimeAr, n2, normalizeAr, num } from "../lib/format";
import {
  recordPayment,
  statement,
  type Party,
  type PartyType,
  type StmtRow,
} from "../lib/parties";
import { Confirm, Empty, Field, Modal } from "../components/ui";

const T = {
  customer: {
    title: "العملاء",
    one: "عميل",
    add: "عميل جديد",
    balanceLbl: "المديونية (عليه)",
    payTitle: "تحصيل من العميل",
    payBtn: "💵 تحصيل",
    payHint: "المبلغ اللي استلمته من العميل",
    upCol: "مدين (فواتير)",
    downCol: "دائن (تحصيل/مرتجع)",
    totalLbl: "إجمالي مديونية العملاء",
  },
  supplier: {
    title: "الموردين",
    one: "مورد",
    add: "مورد جديد",
    balanceLbl: "المستحق (له)",
    payTitle: "دفعة للمورد",
    payBtn: "💸 دفع",
    payHint: "المبلغ اللي دفعته للمورد",
    upCol: "دائن (فواتير شراء)",
    downCol: "مدين (دفعات/مرتجع)",
    totalLbl: "إجمالي المستحق للموردين",
  },
} as const;

const blank = { id: 0, name: "", phone: "", address: "", notes: "" };

export default function Parties({ type }: { type: PartyType }) {
  const t = T[type];
  const table = type === "customer" ? "customers" : "suppliers";
  const { toast, currency, shift } = useApp();
  const { user } = useAuth();

  const [rows, setRows] = useState<Party[]>([]);
  const [search, setSearch] = useState("");
  const [form, setForm] = useState<typeof blank | null>(null);
  const [delId, setDelId] = useState<number | null>(null);
  const [stmt, setStmt] = useState<{ p: Party; rows: StmtRow[] } | null>(null);
  const [payFor, setPayFor] = useState<Party | null>(null);
  const [payAmt, setPayAmt] = useState("");
  const [payNote, setPayNote] = useState("");

  const load = useCallback(async () => {
    setRows(await query<Party>(`SELECT * FROM ${table} ORDER BY name COLLATE NOCASE`));
  }, [table]);

  useEffect(() => {
    setSearch("");
    load().catch((e) => toast(String(e), "err"));
  }, [load, toast]);

  const view = useMemo(() => {
    const s = normalizeAr(search);
    if (!s) return rows;
    return rows.filter(
      (r) => normalizeAr(r.name).includes(s) || (r.phone || "").includes(search.trim())
    );
  }, [rows, search]);

  const totalDue = view.reduce((a, r) => a + n2(r.balance), 0);

  async function save() {
    if (!form) return;
    if (!form.name.trim()) return toast("اكتب الاسم", "err");
    try {
      if (form.id) {
        await execute(
          `UPDATE ${table} SET name=?, phone=?, address=?, notes=? WHERE id=?`,
          [form.name.trim(), form.phone.trim() || null, form.address.trim() || null, form.notes.trim() || null, form.id]
        );
      } else {
        await execute(`INSERT INTO ${table}(name, phone, address, notes) VALUES(?,?,?,?)`, [
          form.name.trim(),
          form.phone.trim() || null,
          form.address.trim() || null,
          form.notes.trim() || null,
        ]);
      }
      toast("تم الحفظ");
      setForm(null);
      await load();
    } catch (e) {
      toast(String(e), "err");
    }
  }

  async function remove(id: number) {
    try {
      const col = type === "customer" ? "customer_id" : "supplier_id";
      const tbl = type === "customer" ? "sales" : "purchases";
      const [u] = await query<any>(`SELECT COUNT(*) AS n FROM ${tbl} WHERE ${col}=?`, [id]);
      if (Number(u?.n || 0) > 0)
        return toast(`مينفعش تحذف ${t.one} عليه فواتير — عدّل بياناته بدل ما تحذفه`, "err");
      await execute(`DELETE FROM ${table} WHERE id=?`, [id]);
      toast("تم الحذف");
      await load();
    } catch (e) {
      toast(String(e), "err");
    }
  }

  async function openStmt(p: Party) {
    setStmt({ p, rows: await statement(type, p.id, n2(p.balance)) });
  }

  async function doPay() {
    if (!payFor) return;
    try {
      await recordPayment(
        type,
        payFor.id,
        n2(payAmt),
        "cash",
        payNote.trim(),
        user?.id ?? null,
        shift?.id ?? null
      );
      toast("تم التسجيل");
      setPayFor(null);
      setPayAmt("");
      setPayNote("");
      await load();
      if (stmt) await openStmt(stmt.p);
    } catch (e) {
      toast(String(e), "err");
    }
  }

  const set = (k: keyof typeof blank, v: string) =>
    setForm((f) => (f ? { ...f, [k]: v } : f));

  return (
    <>
      <div className="toolbar">
        <div className="search-wrap">
          <input
            placeholder={`ابحث بالاسم أو التليفون…`}
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
          <span className="ic">🔍</span>
        </div>
        <div style={{ flex: 1 }} />
        <button className="btn" onClick={() => setForm({ ...blank })}>
          ＋ {t.add}
        </button>
      </div>

      <div className="grid c3" style={{ marginBottom: 14 }}>
        <div className="stat">
          <div className="ic">{type === "customer" ? "👥" : "🏭"}</div>
          <div>
            <div className="lbl">العدد</div>
            <div className="val">{num(view.length, 0)}</div>
          </div>
        </div>
        <div className="stat accent">
          <div className="ic">💳</div>
          <div>
            <div className="lbl">{t.totalLbl}</div>
            <div className="val">{num(totalDue)}</div>
          </div>
        </div>
        <div className="stat">
          <div className="ic">✅</div>
          <div>
            <div className="lbl">أرصدة مسدّدة</div>
            <div className="val">{num(view.filter((r) => n2(r.balance) <= 0).length, 0)}</div>
          </div>
        </div>
      </div>

      <div className="table-wrap">
        {view.length === 0 ? (
          <Empty icon={type === "customer" ? "👥" : "🏭"} text={`مفيش ${t.title}`} />
        ) : (
          <table>
            <thead>
              <tr>
                <th>الاسم</th>
                <th>التليفون</th>
                <th>العنوان</th>
                <th className="num">{t.balanceLbl}</th>
                <th className="num">إجراءات</th>
              </tr>
            </thead>
            <tbody>
              {view.map((p) => (
                <tr key={p.id}>
                  <td style={{ fontWeight: 600 }}>{p.name}</td>
                  <td>{p.phone || "—"}</td>
                  <td style={{ color: "var(--ink-3)" }}>{p.address || "—"}</td>
                  <td className="num">
                    <span className={`badge ${n2(p.balance) > 0 ? "danger" : "ok"}`}>
                      {num(p.balance)} {currency}
                    </span>
                  </td>
                  <td>
                    <div className="row-actions">
                      <button
                        className="icon-btn"
                        title="كشف حساب"
                        onClick={() => void openStmt(p)}
                      >
                        📄
                      </button>
                      <button
                        className="icon-btn"
                        title={t.payTitle}
                        onClick={() => {
                          setPayFor(p);
                          setPayAmt(n2(p.balance) > 0 ? String(n2(p.balance)) : "");
                        }}
                      >
                        {type === "customer" ? "💵" : "💸"}
                      </button>
                      <button
                        className="icon-btn"
                        title="تعديل"
                        onClick={() =>
                          setForm({
                            id: p.id,
                            name: p.name,
                            phone: p.phone || "",
                            address: p.address || "",
                            notes: p.notes || "",
                          })
                        }
                      >
                        ✏️
                      </button>
                      <button
                        className="icon-btn danger"
                        title="حذف"
                        onClick={() => setDelId(p.id)}
                      >
                        🗑
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {form && (
        <Modal
          title={form.id ? `تعديل ${t.one}` : t.add}
          onClose={() => setForm(null)}
          footer={
            <>
              <button className="btn" onClick={() => void save()}>
                حفظ
              </button>
              <button className="btn ghost" onClick={() => setForm(null)}>
                إلغاء
              </button>
            </>
          }
        >
          <div className="grid c2">
            <Field label="الاسم *">
              <input autoFocus value={form.name} onChange={(e) => set("name", e.target.value)} />
            </Field>
            <Field label="التليفون">
              <input value={form.phone} onChange={(e) => set("phone", e.target.value)} />
            </Field>
          </div>
          <div style={{ marginTop: 12 }}>
            <Field label="العنوان">
              <input value={form.address} onChange={(e) => set("address", e.target.value)} />
            </Field>
          </div>
          <div style={{ marginTop: 12 }}>
            <Field label="ملاحظات">
              <textarea value={form.notes} onChange={(e) => set("notes", e.target.value)} />
            </Field>
          </div>
        </Modal>
      )}

      {stmt && (
        <Modal
          wide
          title={`كشف حساب — ${stmt.p.name}`}
          onClose={() => setStmt(null)}
          footer={
            <>
              <button
                className="btn"
                onClick={() => {
                  setPayFor(stmt.p);
                  setPayAmt(n2(stmt.p.balance) > 0 ? String(n2(stmt.p.balance)) : "");
                }}
              >
                {t.payBtn}
              </button>
              <button className="btn ghost" onClick={() => setStmt(null)}>
                إغلاق
              </button>
            </>
          }
        >
          <div className="tot-grand" style={{ marginBottom: 14 }}>
            <span>{t.balanceLbl}</span>
            <span className="v">
              {num(stmt.p.balance)} {currency}
            </span>
          </div>
          {stmt.rows.length === 0 ? (
            <Empty icon="📄" text="مفيش حركة على الحساب ده" />
          ) : (
            <div className="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th>التاريخ</th>
                    <th>البيان</th>
                    <th className="num">{t.upCol}</th>
                    <th className="num">{t.downCol}</th>
                    <th className="num">الرصيد</th>
                  </tr>
                </thead>
                <tbody>
                  {stmt.rows.map((r, i) => (
                    <tr key={i}>
                      <td style={{ fontSize: 12, color: "var(--ink-3)" }}>
                        {r.date ? dateTimeAr(r.date) : "—"}
                      </td>
                      <td>{r.doc}</td>
                      <td className="num">{r.up ? num(r.up) : "—"}</td>
                      <td className="num" style={{ color: "var(--ok)" }}>
                        {r.down ? num(r.down) : "—"}
                      </td>
                      <td className="num" style={{ fontWeight: 700 }}>
                        {num(r.balance)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Modal>
      )}

      {payFor && (
        <Modal
          title={`${t.payTitle} — ${payFor.name}`}
          onClose={() => setPayFor(null)}
          footer={
            <>
              <button className="btn" onClick={() => void doPay()}>
                تسجيل
              </button>
              <button className="btn ghost" onClick={() => setPayFor(null)}>
                إلغاء
              </button>
            </>
          }
        >
          <div className="tot-row">
            <span>الرصيد الحالي</span>
            <b>
              {num(payFor.balance)} {currency}
            </b>
          </div>
          <div className="grid c2" style={{ marginTop: 12 }}>
            <Field label="المبلغ *" hint={t.payHint}>
              <input
                autoFocus
                type="number"
                step="0.01"
                value={payAmt}
                onChange={(e) => setPayAmt(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && void doPay()}
              />
            </Field>
            <Field label="ملاحظة">
              <input value={payNote} onChange={(e) => setPayNote(e.target.value)} />
            </Field>
          </div>
          <div className="tot-row" style={{ marginTop: 10 }}>
            <span>الرصيد بعد العملية</span>
            <b>{num(n2(payFor.balance) - n2(payAmt))}</b>
          </div>
        </Modal>
      )}

      {delId !== null && (
        <Confirm
          danger
          title={`حذف ${t.one}`}
          message="متأكد؟ العملية دي مالهاش رجعة."
          confirmText="احذف"
          onConfirm={() => void remove(delId)}
          onClose={() => setDelId(null)}
        />
      )}
    </>
  );
}
