import { useCallback, useEffect, useMemo, useState } from "react";
import { batch, query, type Op } from "../lib/db";
import { useApp } from "../lib/app";
import { useAuth } from "../lib/auth";
import { dateTimeAr, n2, normalizeAr, num, qty as fq } from "../lib/format";
import { Confirm, Empty } from "../components/ui";

interface Row {
  id: number;
  code: string;
  name: string;
  unit: string;
  qty: number;
  cost_price: number;
  category_name: string | null;
}

export default function Stocktake() {
  const { toast, currency } = useApp();
  const { user } = useAuth();
  const [session, setSession] = useState<number | null>(null);
  const [rows, setRows] = useState<Row[]>([]);
  const [cats, setCats] = useState<{ id: number; name: string }[]>([]);
  const [counted, setCounted] = useState<Record<number, string>>({});
  const [search, setSearch] = useState("");
  const [catFilter, setCatFilter] = useState("");
  const [onlyDiff, setOnlyDiff] = useState(false);
  const [history, setHistory] = useState<any[]>([]);
  const [ask, setAsk] = useState(false);

  const load = useCallback(async () => {
    setRows(
      await query<Row>(
        `SELECT p.id, p.code, p.name, p.unit, p.qty, p.cost_price, c.name AS category_name
           FROM products p LEFT JOIN categories c ON c.id = p.category_id
          WHERE p.is_active = 1 ORDER BY p.name COLLATE NOCASE`
      )
    );
    setCats(await query(`SELECT id, name FROM categories ORDER BY name`));
    setHistory(
      await query(
        `SELECT s.*, (SELECT COUNT(*) FROM stocktake_items i WHERE i.stocktake_id = s.id) AS items
           FROM stocktakes s ORDER BY s.id DESC LIMIT 50`
      )
    );
  }, []);

  useEffect(() => {
    load().catch((e) => toast(String(e), "err"));
  }, [load, toast]);

  const view = useMemo(() => {
    const s = normalizeAr(search);
    return rows.filter((r) => {
      if (catFilter && r.category_name !== catFilter) return false;
      if (onlyDiff) {
        const c = counted[r.id];
        if (c === undefined || c === "") return false;
        if (n2(c) === n2(r.qty)) return false;
      }
      if (!s) return true;
      return normalizeAr(r.name).includes(s) || normalizeAr(r.code || "").includes(s);
    });
  }, [rows, search, catFilter, onlyDiff, counted]);

  const entered = rows.filter(
    (r) => counted[r.id] !== undefined && counted[r.id] !== ""
  );
  const diffs = entered
    .map((r) => ({ r, d: n2(counted[r.id]) - n2(r.qty) }))
    .filter((x) => x.d !== 0);
  const shortage = diffs.filter((x) => x.d < 0);
  const surplus = diffs.filter((x) => x.d > 0);
  const valueImpact = diffs.reduce((a, x) => a + x.d * n2(x.r.cost_price), 0);

  async function start() {
    try {
      const ids = await batch(
        [{
          sql: `INSERT INTO stocktakes(status,notes,user_id,stocktake_no,reason)
                VALUES('draft',?,?,?,'جرد فعلي')`,
          params: ["جرد من شاشة الجرد", user?.id ?? null, `ST-${Date.now().toString().slice(-10)}`],
        }],
        "stocktake"
      );
      setSession(ids[0]);
      setCounted({});
      toast("اتفتحت جلسة جرد جديدة — ابدأ إدخال الكميات الفعلية");
      await load();
    } catch (e) {
      toast(String(e), "err");
    }
  }

  async function apply() {
    if (!session) return;
    try {
      const ops: Op[] = [];
      for (const r of entered) {
        const c = n2(counted[r.id]);
        if (c < 0) throw new Error(`الكمية الفعلية للصنف «${r.name}» لا يمكن أن تكون سالبة`);
        const d = c - n2(r.qty);
        ops.push({
          sql: `INSERT INTO stocktake_items(stocktake_id,product_id,system_qty,counted_qty,diff,
                  cost_snapshot,value_difference)
                VALUES(?,?,?,?,?,?,?)`,
          params: [session, r.id, n2(r.qty), c, d, n2(r.cost_price), d * n2(r.cost_price)],
        });
        if (d !== 0) {
          ops.push({
            sql: `INSERT INTO stock_moves(product_id,qty_change,type,ref_id,note,user_id,
                    reference_type,reference_id,qty_before,qty_after,unit_cost,total_value)
                  SELECT id,?,'stocktake',?,?,?,'stocktake',?,qty,?,cost_price,?*cost_price
                    FROM products WHERE id=?`,
            params: [d, session, d < 0 ? "عجز جرد" : "زيادة جرد", user?.id ?? null, session, c, d, r.id],
          });
          ops.push({ sql: `UPDATE products SET qty=? WHERE id=?`, params: [c, r.id] });
        }
      }
      ops.push({
        sql: `UPDATE stocktakes SET status='applied',notes=?,posted_at=datetime('now','localtime'),
                posted_by=? WHERE id=?`,
        params: [
          `أصناف: ${entered.length} — فروقات: ${diffs.length} — أثر التكلفة: ${valueImpact.toFixed(2)}`,
          user?.id ?? null,
          session,
        ],
      });
      ops.push({
        sql: `INSERT INTO audit_log(user_id,action,entity_type,entity_id,new_values,reason)
              VALUES(?,'stocktake_posted','stocktake',?,?,?)`,
        params: [user?.id ?? null, session, JSON.stringify({ items: entered.length, differences: diffs.length, value_impact: valueImpact }), "جرد فعلي"],
      });

      await batch(ops, "stocktake");
      toast(`اتطبّق الجرد — ${diffs.length} صنف اتعدّل`);
      setSession(null);
      setCounted({});
      await load();
    } catch (e) {
      toast(String(e), "err");
    }
  }

  return (
    <>
      {!session ? (
        <>
          <div className="card" style={{ textAlign: "center", padding: 26 }}>
            <div style={{ fontSize: 40, marginBottom: 8 }}>📋</div>
            <h3 style={{ margin: "0 0 6px" }}>الجرد</h3>
            <p style={{ color: "var(--ink-2)", lineHeight: 1.9, maxWidth: 560, margin: "0 auto 14px" }}>
              افتح جلسة جرد، أدخل الكمية الفعلية اللي عدّيتها لكل صنف، والبرنامج هيحسب
              العجز والزيادة، يسوّي المخزن، ويسجّل الحركة بسبب «جرد».
            </p>
            <button className="btn" onClick={() => void start()}>
              ＋ بدء جرد جديد
            </button>
          </div>

          <div className="card">
            <h3>سجل الجرد السابق</h3>
            {history.length === 0 ? (
              <Empty icon="📋" text="مفيش جرد متسجل قبل كده" />
            ) : (
              <div className="table-wrap" style={{ boxShadow: "none" }}>
                <table>
                  <thead>
                    <tr>
                      <th>التاريخ</th>
                      <th className="num">عدد الأصناف</th>
                      <th className="num">الحالة</th>
                      <th>ملاحظات</th>
                    </tr>
                  </thead>
                  <tbody>
                    {history.map((h) => (
                      <tr key={h.id}>
                        <td style={{ fontSize: 12 }}>{dateTimeAr(h.date)}</td>
                        <td className="num">{num(h.items, 0)}</td>
                        <td className="num">
                          <span className={`badge ${h.status === "applied" ? "ok" : "warn"}`}>
                            {h.status === "applied" ? "مطبّق" : "مسودة"}
                          </span>
                        </td>
                        <td style={{ fontSize: 12, color: "var(--ink-3)" }}>
                          {h.notes || "—"}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </>
      ) : (
        <>
          <div className="toolbar">
            <div className="search-wrap">
              <input
                placeholder="ابحث بالاسم أو الكود…"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
              <span className="ic">🔍</span>
            </div>
            <select
              style={{ width: 170 }}
              value={catFilter}
              onChange={(e) => setCatFilter(e.target.value)}
            >
              <option value="">كل التصنيفات</option>
              {cats.map((c) => (
                <option key={c.id} value={c.name}>
                  {c.name}
                </option>
              ))}
            </select>
            <button
              className={`btn ${onlyDiff ? "accent" : "ghost"}`}
              onClick={() => setOnlyDiff((v) => !v)}
            >
              الفروقات فقط
            </button>
            <div style={{ flex: 1 }} />
            <button className="btn" disabled={!entered.length} onClick={() => setAsk(true)}>
              ✅ تطبيق التسوية
            </button>
            <button className="btn ghost" onClick={() => setSession(null)}>
              خروج بدون تطبيق
            </button>
          </div>

          <div className="grid c4" style={{ marginBottom: 14 }}>
            <div className="stat">
              <div className="ic">✍️</div>
              <div>
                <div className="lbl">أصناف اتعدّت</div>
                <div className="val">
                  {num(entered.length, 0)} / {num(rows.length, 0)}
                </div>
              </div>
            </div>
            <div className="stat">
              <div className="ic">📉</div>
              <div>
                <div className="lbl">أصناف بعجز</div>
                <div className="val">{num(shortage.length, 0)}</div>
              </div>
            </div>
            <div className="stat">
              <div className="ic">📈</div>
              <div>
                <div className="lbl">أصناف بزيادة</div>
                <div className="val">{num(surplus.length, 0)}</div>
              </div>
            </div>
            <div className="stat accent">
              <div className="ic">💰</div>
              <div>
                <div className="lbl">أثر الفروقات بالتكلفة</div>
                <div className="val">{num(valueImpact)}</div>
              </div>
            </div>
          </div>

          <div className="table-wrap">
            {view.length === 0 ? (
              <Empty icon="📦" text="مفيش أصناف مطابقة" />
            ) : (
              <table>
                <thead>
                  <tr>
                    <th>الكود</th>
                    <th>الصنف</th>
                    <th>التصنيف</th>
                    <th className="num">رصيد البرنامج</th>
                    <th className="num">الكمية الفعلية</th>
                    <th className="num">الفرق</th>
                    <th className="num">القيمة</th>
                  </tr>
                </thead>
                <tbody>
                  {view.map((r) => {
                    const c = counted[r.id];
                    const has = c !== undefined && c !== "";
                    const d = has ? n2(c) - n2(r.qty) : 0;
                    return (
                      <tr key={r.id}>
                        <td style={{ color: "var(--ink-3)" }}>{r.code}</td>
                        <td style={{ fontWeight: 600 }}>{r.name}</td>
                        <td>{r.category_name || "—"}</td>
                        <td className="num">
                          {fq(r.qty)} {r.unit}
                        </td>
                        <td className="num">
                          <input
                            type="number"
                            step="0.001"
                            style={{ width: 100 }}
                            value={c ?? ""}
                            placeholder="—"
                            onChange={(e) =>
                              setCounted((s) => ({ ...s, [r.id]: e.target.value }))
                            }
                          />
                        </td>
                        <td className="num">
                          {has ? (
                            <span
                              className={`badge ${d === 0 ? "ok" : d < 0 ? "danger" : "warn"}`}
                            >
                              {d > 0 ? "+" : ""}
                              {fq(d)}
                            </span>
                          ) : (
                            "—"
                          )}
                        </td>
                        <td className="num">
                          {has && d !== 0 ? num(d * n2(r.cost_price)) : "—"}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            )}
          </div>
        </>
      )}

      {ask && (
        <Confirm
          title="تطبيق تسوية الجرد"
          message={`هيتم تعديل ${diffs.length} صنف ليطابق الكمية الفعلية، وتسجيل الحركة بسبب «جرد». أثر الفروقات على قيمة المخزن: ${num(
            valueImpact
          )} ${currency}. تكمل؟`}
          confirmText="طبّق"
          onConfirm={() => void apply()}
          onClose={() => setAsk(false)}
        />
      )}
    </>
  );
}
