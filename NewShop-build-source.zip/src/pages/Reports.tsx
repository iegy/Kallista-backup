import { useCallback, useEffect, useMemo, useState } from "react";
import { useApp } from "../lib/app";
import { dateAr, n2, num, qty as fq, todayIso } from "../lib/format";
import * as R from "../lib/reports";
import { exportExcel } from "../lib/exporter";
import { Empty, Field } from "../components/ui";
import ReportPrint, { type RepCol, type RepData } from "../components/ReportPrint";
import { query } from "../lib/db";
import { useAuth } from "../lib/auth";

type Tab = "pnl" | "sales" | "stock" | "dues" | "audit";
type SalesView = "daily" | "product" | "customer" | "user";
type StockView = "balances" | "low" | "dead";
type DuesView = "customers" | "suppliers";

const TABS: { k: Tab; label: string; icon: string }[] = [
  { k: "pnl", label: "الأرباح والخسائر", icon: "📈" },
  { k: "sales", label: "المبيعات", icon: "🛒" },
  { k: "stock", label: "المخزون", icon: "📦" },
  { k: "dues", label: "المديونيات", icon: "💳" },
  { k: "audit", label: "سجل التدقيق", icon: "🛡️" },
];

function firstOfMonth() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-01`;
}

export default function Reports() {
  const { toast, currency, settings } = useApp();
  const { user } = useAuth();
  const [tab, setTab] = useState<Tab>("pnl");
  const [salesView, setSalesView] = useState<SalesView>("daily");
  const [stockView, setStockView] = useState<StockView>("balances");
  const [duesView, setDuesView] = useState<DuesView>("customers");
  const [deadDays, setDeadDays] = useState("30");

  const [from, setFrom] = useState(firstOfMonth());
  const [to, setTo] = useState(todayIso());

  const [pnl, setPnl] = useState<R.PnL | null>(null);
  const [rows, setRows] = useState<any[]>([]);
  const [busy, setBusy] = useState(false);

  const range = useMemo(() => ({ from, to }), [from, to]);

  const load = useCallback(async () => {
    setBusy(true);
    try {
      if (tab === "pnl") {
        setPnl(await R.profitAndLoss(range));
        setRows(await R.expensesByCategory(range));
      } else if (tab === "sales") {
        setRows(
          salesView === "daily"
            ? await R.salesDaily(range)
            : salesView === "product"
            ? await R.salesByProduct(range)
            : salesView === "customer"
            ? await R.salesByCustomer(range)
            : await R.salesByUser(range)
        );
      } else if (tab === "stock") {
        setRows(
          stockView === "balances"
            ? await R.stockBalances()
            : stockView === "low"
            ? await R.lowStock()
            : await R.deadStock(Number(deadDays) || 30)
        );
      } else if (tab === "dues") {
        setRows(duesView === "customers" ? await R.customerDues() : await R.supplierDues());
      } else {
        setRows(await query(
          `SELECT a.timestamp,a.action,a.entity_type,a.entity_id,a.reason,
                  COALESCE(u.full_name,u.username,'النظام') AS user_name,
                  COALESCE(o.full_name,o.username,'—') AS override_name
             FROM audit_log a
             LEFT JOIN users u ON u.id=a.user_id
             LEFT JOIN users o ON o.id=a.override_user_id
            WHERE date(a.timestamp) BETWEEN ? AND ?
            ORDER BY a.id DESC LIMIT 2000`,
          [from,to]
        ));
      }
    } catch (e) {
      toast(String(e), "err");
    } finally {
      setBusy(false);
    }
  }, [tab, salesView, stockView, duesView, deadDays, range, toast]);

  useEffect(() => {
    void load();
  }, [load]);

  /* ---------- تعريف أعمدة كل تقرير ---------- */
  const def: { title: string; cols: RepCol[]; sumKeys: string[]; note?: string } = useMemo(() => {
    if (tab === "sales") {
      if (salesView === "daily")
        return {
          title: "تقرير المبيعات اليومي",
          cols: [
            { key: "day_ar", label: "اليوم", width: 18 },
            { key: "invoices", label: "عدد الفواتير", type: "number" },
            { key: "total", label: "المبيعات", type: "number" },
            { key: "discount", label: "الخصومات", type: "number" },
            { key: "cogs", label: "تكلفة المباع", type: "number" },
            { key: "profit", label: "مجمل الربح", type: "number" },
            { key: "remaining", label: "آجل", type: "number" },
          ],
          sumKeys: ["invoices", "total", "discount", "cogs", "profit", "remaining"],
        };
      if (salesView === "product")
        return {
          title: "تقرير المبيعات بالصنف",
          cols: [
            { key: "name", label: "الصنف", width: 26 },
            { key: "code", label: "الكود" },
            { key: "qty", label: "الكمية المباعة", type: "qty" },
            { key: "total", label: "الإيراد", type: "number" },
            { key: "cost", label: "التكلفة", type: "number" },
            { key: "profit", label: "الربح", type: "number" },
          ],
          sumKeys: ["qty", "total", "cost", "profit"],
          note: "الإيراد موزّع على البنود بعد خصمي السطر والفاتورة، والضريبة لا تُحسب ضمن الربح.",
        };
      if (salesView === "customer")
        return {
          title: "تقرير المبيعات بالعميل",
          cols: [
            { key: "name", label: "العميل", width: 28 },
            { key: "invoices", label: "عدد الفواتير", type: "number" },
            { key: "total", label: "الإجمالي", type: "number" },
            { key: "paid", label: "المدفوع", type: "number" },
            { key: "remaining", label: "المتبقي", type: "number" },
          ],
          sumKeys: ["invoices", "total", "paid", "remaining"],
        };
      return {
        title: "تقرير المبيعات بالمستخدم",
        cols: [
          { key: "name", label: "المستخدم", width: 30 },
          { key: "invoices", label: "عدد الفواتير", type: "number" },
          { key: "total", label: "الإجمالي", type: "number" },
          { key: "discount", label: "الخصومات", type: "number" },
        ],
        sumKeys: ["invoices", "total", "discount"],
      };
    }

    if (tab === "stock") {
      if (stockView === "balances")
        return {
          title: "تقرير أرصدة المخزون وتقييمه",
          cols: [
            { key: "code", label: "الكود" },
            { key: "name", label: "الصنف", width: 24 },
            { key: "category", label: "التصنيف" },
            { key: "qty", label: "الكمية", type: "qty" },
            { key: "cost_price", label: "التكلفة", type: "number" },
            { key: "cost_value", label: "القيمة بالتكلفة", type: "number" },
            { key: "sell_value", label: "القيمة بالبيع", type: "number" },
          ],
          sumKeys: ["cost_value", "sell_value"],
        };
      if (stockView === "low")
        return {
          title: "تقرير الأصناف الناقصة",
          cols: [
            { key: "code", label: "الكود" },
            { key: "name", label: "الصنف", width: 30 },
            { key: "qty", label: "المتاح", type: "qty" },
            { key: "min_qty", label: "الحد الأدنى", type: "qty" },
            { key: "shortage", label: "العجز", type: "qty" },
            { key: "cost_price", label: "التكلفة", type: "number" },
          ],
          sumKeys: [],
        };
      return {
        title: `تقرير الأصناف الراكدة (مفيش بيع من ${deadDays} يوم)`,
        cols: [
          { key: "code", label: "الكود" },
          { key: "name", label: "الصنف", width: 28 },
          { key: "qty", label: "الكمية", type: "qty" },
          { key: "value", label: "القيمة بالتكلفة", type: "number" },
          { key: "last_sale_ar", label: "آخر بيع", width: 20 },
        ],
        sumKeys: ["value"],
      };
    }

    if (tab === "dues")
      return {
        title: duesView === "customers" ? "تقرير مديونيات العملاء" : "تقرير مستحقات الموردين",
        cols: [
          { key: "name", label: "الاسم", width: 40 },
          { key: "phone", label: "التليفون", width: 25 },
          { key: "balance", label: "الرصيد", type: "number" },
        ],
        sumKeys: ["balance"],
      };

    if (tab === "audit")
      return {
        title: "سجل التدقيق",
        cols: [
          { key: "timestamp", label: "الوقت", width: 18 },
          { key: "user_name", label: "المستخدم" },
          { key: "action", label: "الإجراء", width: 20 },
          { key: "entity_type", label: "نوع المستند" },
          { key: "entity_id", label: "الرقم", type: "number" },
          { key: "override_name", label: "موافقة" },
          { key: "reason", label: "السبب", width: 22 },
        ],
        sumKeys: [],
      };

    return {
      title: "المصروفات حسب البند",
      cols: [
        { key: "category", label: "البند", width: 40 },
        { key: "count", label: "عدد العمليات", type: "number" },
        { key: "total", label: "الإجمالي", type: "number" },
      ],
      sumKeys: ["count", "total"],
    };
  }, [tab, salesView, stockView, duesView, deadDays]);

  /* ---------- تجهيز الصفوف للعرض والتصدير ---------- */
  const data: RepData = useMemo(() => {
    const prepared = rows.map((r) => {
      const o = { ...r };
      if (r.day) o.day_ar = dateAr(r.day);
      if (r.last_sale_text)
        o.last_sale_ar = r.last_sale ? dateAr(r.last_sale) : "لم يُبع أبدًا";
      if (tab === "sales" && salesView === "daily")
        o.profit = n2(r.total) - n2(r.cogs);
      return o;
    });

    const totals: Record<string, number> = {};
    for (const k of def.sumKeys) totals[k] = prepared.reduce((a, r) => a + n2(r[k]), 0);

    return {
      title: def.title,
      from,
      to,
      cols: def.cols,
      rows: prepared,
      totals: def.sumKeys.length ? totals : undefined,
      totalsLabel: "الإجمالي",
    };
  }, [rows, def, from, to, tab, salesView]);

  /* ---------- التصدير ---------- */
  async function toExcel() {
    try {
      const sheets = [
        {
          name: def.title.slice(0, 28),
          title: `${def.title} — ${settings.shop_name || "NewShop"}`,
          subtitle: `الفترة: من ${dateAr(from)} إلى ${dateAr(to)}`,
          cols: def.cols.map((c) => ({
            key: c.key,
            label: c.label,
            width: c.width ? c.width + 6 : 16,
            type: (c.type ? "number" : "text") as "number" | "text",
          })),
          rows: data.rows,
          totalsLabel: "الإجمالي",
          totals: data.totals,
        },
      ];

      if (tab === "pnl" && pnl) {
        sheets.unshift({
          name: "الأرباح والخسائر",
          title: `بيان الأرباح والخسائر — ${settings.shop_name || "NewShop"}`,
          subtitle: `الفترة: من ${dateAr(from)} إلى ${dateAr(to)}`,
          cols: [
            { key: "bnd", label: "البند", width: 34, type: "text" as const },
            { key: "val", label: `القيمة (${currency})`, width: 18, type: "number" as const },
          ],
          rows: pnlRows(pnl),
          totalsLabel: "صافي الربح",
          totals: { val: pnl.netProfit },
        });
      }

      const path = await exportExcel(
        `${def.title.replace(/[\\/:*?"<>|]/g, "-")} ${from} — ${to}`,
        sheets
      );
      if (path) toast("اتصدّر الملف بنجاح");
    } catch (e) {
      toast(String(e), "err");
    }
  }

  const cell = (c: RepCol, row: any) =>
    c.type === "number" ? num(row[c.key]) : c.type === "qty" ? fq(row[c.key]) : row[c.key] ?? "—";

  return (
    <>
      <div className="tabs">
        {TABS.filter((t) => t.k !== "audit" || user?.role === "owner" || user?.role === "admin").map((t) => (
          <button
            key={t.k}
            className={`tab${tab === t.k ? " active" : ""}`}
            onClick={() => setTab(t.k)}
          >
            {t.icon} {t.label}
          </button>
        ))}
      </div>

      <div className="toolbar">
        <Field label="من تاريخ">
          <input type="date" value={from} onChange={(e) => setFrom(e.target.value)} />
        </Field>
        <Field label="إلى تاريخ">
          <input type="date" value={to} onChange={(e) => setTo(e.target.value)} />
        </Field>

        {tab === "sales" && (
          <Field label="نوع التقرير">
            <select
              value={salesView}
              onChange={(e) => setSalesView(e.target.value as SalesView)}
            >
              <option value="daily">يومي</option>
              <option value="product">بالصنف</option>
              <option value="customer">بالعميل</option>
              <option value="user">بالمستخدم</option>
            </select>
          </Field>
        )}
        {tab === "stock" && (
          <>
            <Field label="نوع التقرير">
              <select
                value={stockView}
                onChange={(e) => setStockView(e.target.value as StockView)}
              >
                <option value="balances">الأرصدة والتقييم</option>
                <option value="low">الأصناف الناقصة</option>
                <option value="dead">الأصناف الراكدة</option>
              </select>
            </Field>
            {stockView === "dead" && (
              <Field label="راكد من (يوم)">
                <input
                  type="number"
                  style={{ width: 100 }}
                  value={deadDays}
                  onChange={(e) => setDeadDays(e.target.value)}
                />
              </Field>
            )}
          </>
        )}
        {tab === "dues" && (
          <Field label="الطرف">
            <select value={duesView} onChange={(e) => setDuesView(e.target.value as DuesView)}>
              <option value="customers">العملاء</option>
              <option value="suppliers">الموردين</option>
            </select>
          </Field>
        )}

        <div style={{ flex: 1 }} />
        <button
          className="btn ghost"
          style={{ marginTop: 18 }}
          onClick={() => {
            setFrom(todayIso());
            setTo(todayIso());
          }}
        >
          النهارده
        </button>
        <button
          className="btn ghost"
          style={{ marginTop: 18 }}
          onClick={() => {
            setFrom(firstOfMonth());
            setTo(todayIso());
          }}
        >
          الشهر ده
        </button>
        <button className="btn accent" style={{ marginTop: 18 }} onClick={() => void toExcel()}>
          📊 Excel
        </button>
        <button className="btn" style={{ marginTop: 18 }} onClick={() => window.print()}>
          🖨️ طباعة / PDF
        </button>
      </div>

      {tab === "pnl" && pnl && (
        <div className="grid c2" style={{ marginBottom: 14 }}>
          <div className="card">
            <h3>بيان الأرباح والخسائر</h3>
            <div className="pnl-line">
              <span>إجمالي المبيعات</span>
              <b>{num(pnl.grossSales)}</b>
            </div>
            <div className="pnl-line sub">
              <span>ناقص: مرتجعات البيع</span>
              <b>− {num(pnl.salesReturns)}</b>
            </div>
            <div className="pnl-line strong">
              <span>صافي المبيعات</span>
              <b>{num(pnl.netSales)}</b>
            </div>
            <div className="pnl-line sub">
              <span>ناقص: تكلفة البضاعة المباعة</span>
              <b>− {num(pnl.cogs)}</b>
            </div>
            <div className="pnl-line strong">
              <span>مجمل الربح</span>
              <b>{num(pnl.grossProfit)}</b>
            </div>
            <div className="pnl-line sub">
              <span>ناقص: المصروفات</span>
              <b>− {num(pnl.expenses)}</b>
            </div>
            <div className={`pnl-line final${pnl.netProfit < 0 ? " loss" : ""}`}>
              <span>{pnl.netProfit < 0 ? "صافي الخسارة" : "صافي الربح"}</span>
              <b>
                {num(pnl.netProfit)} {currency}
              </b>
            </div>
          </div>

          <div>
            <div className="grid c2">
              <div className="stat">
                <div className="ic">🧾</div>
                <div>
                  <div className="lbl">عدد الفواتير</div>
                  <div className="val">{num(pnl.invoices, 0)}</div>
                </div>
              </div>
              <div className="stat">
                <div className="ic">🏷️</div>
                <div>
                  <div className="lbl">الخصومات الممنوحة</div>
                  <div className="val">{num(pnl.salesDiscount)}</div>
                </div>
              </div>
              <div className="stat">
                <div className="ic">🚚</div>
                <div>
                  <div className="lbl">المشتريات</div>
                  <div className="val">{num(pnl.purchases)}</div>
                </div>
              </div>
              <div className="stat accent">
                <div className="ic">📊</div>
                <div>
                  <div className="lbl">هامش الربح</div>
                  <div className="val">
                    {pnl.netSales > 0
                      ? `${num((pnl.grossProfit / pnl.netSales) * 100)} %`
                      : "—"}
                  </div>
                </div>
              </div>
            </div>
            <div className="card" style={{ marginTop: 14, fontSize: 12.5, lineHeight: 2, color: "var(--ink-2)" }}>
              <b style={{ color: "var(--ink)" }}>إزاي بتتحسب الأرقام دي؟</b>
              <div>• تكلفة البضاعة المباعة بتتاخد من سعر التكلفة <b>وقت البيع</b> نفسه.</div>
              <div>• المرتجعات بتتخصم من الإيراد ومن التكلفة مع بعض.</div>
              <div>• الفواتير الملغية مستبعدة تمامًا.</div>
              <div>• المشتريات مش بتتخصم من الربح — بتزوّد المخزن، والتكلفة بتتحسب وقت البيع.</div>
            </div>
          </div>
        </div>
      )}

      {def.note && (
        <div className="hint" style={{ marginBottom: 8 }}>
          ℹ️ {def.note}
        </div>
      )}

      <div className="table-wrap">
        {busy ? (
          <Empty icon="⏳" text="جارٍ التحميل…" />
        ) : data.rows.length === 0 ? (
          <Empty icon="📊" text="مفيش بيانات في الفترة دي" />
        ) : (
          <table>
            <thead>
              <tr>
                <th className="num" style={{ width: 46 }}>
                  م
                </th>
                {def.cols.map((c) => (
                  <th key={c.key} className={c.type ? "num" : undefined}>
                    {c.label}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {data.rows.map((row, i) => (
                <tr key={i}>
                  <td className="num" style={{ color: "var(--ink-3)" }}>
                    {i + 1}
                  </td>
                  {def.cols.map((c) => (
                    <td
                      key={c.key}
                      className={c.type ? "num" : undefined}
                      style={
                        c.key === "profit"
                          ? {
                              fontWeight: 700,
                              color: n2(row[c.key]) < 0 ? "var(--danger)" : "var(--ok)",
                            }
                          : undefined
                      }
                    >
                      {cell(c, row)}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
            {data.totals && (
              <tfoot>
                <tr style={{ background: "var(--surface)", fontWeight: 800 }}>
                  <td className="num"></td>
                  {def.cols.map((c, i) => (
                    <td key={c.key} className={c.type ? "num" : undefined}>
                      {i === 0
                        ? "الإجمالي"
                        : data.totals![c.key] !== undefined
                        ? num(data.totals![c.key])
                        : ""}
                    </td>
                  ))}
                </tr>
              </tfoot>
            )}
          </table>
        )}
      </div>

      <ReportPrint data={data} />
    </>
  );
}

/** صفوف بيان الأرباح والخسائر لملف Excel */
function pnlRows(p: R.PnL) {
  return [
    { bnd: "إجمالي المبيعات", val: p.grossSales },
    { bnd: "مرتجعات البيع", val: -p.salesReturns },
    { bnd: "صافي المبيعات", val: p.netSales },
    { bnd: "تكلفة البضاعة المباعة", val: -p.cogs },
    { bnd: "مجمل الربح", val: p.grossProfit },
    { bnd: "المصروفات", val: -p.expenses },
    { bnd: "عدد الفواتير", val: p.invoices },
    { bnd: "الخصومات الممنوحة", val: p.salesDiscount },
    { bnd: "المشتريات في الفترة", val: p.purchases },
  ];
}
