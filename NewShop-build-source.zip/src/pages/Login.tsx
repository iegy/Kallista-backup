import { useState } from "react";
import { useApp } from "../lib/app";
import { useAuth } from "../lib/auth";
import { isTauri } from "../lib/db";
import { Field } from "../components/ui";

export default function Login() {
  const { settings } = useApp();
  const { needsSetup, login, createFirstAdmin } = useAuth();

  const [username, setUsername] = useState("");
  const [fullName, setFullName] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setErr("");
    setBusy(true);
    try {
      if (needsSetup) {
        if (password !== confirm) throw new Error("كلمتا السر مش متطابقتين");
        await createFirstAdmin(username, fullName, password);
      } else {
        await login(username, password);
      }
    } catch (e: any) {
      setErr(e?.message ? String(e.message) : String(e));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="gate">
      <form className="gate-card" onSubmit={submit}>
        <div className="gate-logo">
          {settings.shop_logo ? <img src={settings.shop_logo} alt="" /> : "NS"}
        </div>
        <h2>{needsSetup ? "إنشاء حساب المدير" : settings.shop_name || "NewShop"}</h2>
        <div className="sub">
          {needsSetup
            ? "أول تشغيل للبرنامج — اعمل حساب المدير عشان تبدأ"
            : "سجّل الدخول للمتابعة"}
        </div>

        <Field label="اسم المستخدم">
          <input
            autoFocus
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            autoComplete="username"
          />
        </Field>

        {needsSetup && (
          <Field label="الاسم بالكامل">
            <input
              value={fullName}
              placeholder="مثال: محمد حسين"
              onChange={(e) => setFullName(e.target.value)}
            />
          </Field>
        )}

        <Field label="كلمة السر">
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            autoComplete={needsSetup ? "new-password" : "current-password"}
          />
        </Field>

        {needsSetup && (
          <Field label="تأكيد كلمة السر">
            <input
              type="password"
              value={confirm}
              onChange={(e) => setConfirm(e.target.value)}
              autoComplete="new-password"
            />
          </Field>
        )}

        <button className="btn" disabled={busy} type="submit">
          {busy ? "…" : needsSetup ? "إنشاء الحساب والدخول" : "دخول"}
        </button>

        {err && <div className="gate-err">{err}</div>}

        {!isTauri() && !needsSetup && (
          <div className="gate-foot" style={{ color: "var(--warn)" }}>
            وضع المعاينة: المستخدم <b>admin</b> وكلمة السر <b>admin</b>
          </div>
        )}

        <div className="gate-foot">
          NewShop v2.0.0 — تصميم وبرمجة محمد حسين
          <br />
          iegy.net
        </div>
      </form>
    </div>
  );
}
