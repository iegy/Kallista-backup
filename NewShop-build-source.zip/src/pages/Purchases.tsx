import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { execute, query } from "../lib/db";
import { useApp } from "../lib/app";
import { useAuth } from "../lib/auth";
import { dateTimeAr, n2, normalizeAr, num, qty as fq, todayIso } from "../lib/format";
import {
  buyTotal,
  getPurchase,
  newAvgCost,
  savePurchase,
  type BuyLine,
  type PurchaseHead,
  type PurchaseLine,
} from "../lib/purchases";
import { Empty, Field, Modal } from "../components/ui";

interface P {
  id: number;
  code: string;
  name: string;
  barcode: string | null;
  barcodes: string | null;
  unit: string;
  cost_price: number;
  qty: number;
}

export default function Purchases() {
  const { toast, currency, shift } = useApp();
  const { user } = useAuth();
  const [from, setFrom] = useState(todayIso());
  const [to, setTo] = useState(todayIso());
  const [list, setList] = useState<any[]>([]);
  const [view, setView] = useState<{ head: PurchaseHead; lines: PurchaseLine[] } | null>(
    null
  );

  const [products, setProducts] = useState<P[]>([]);
  const [suppliers, setSuppliers] = useState<{ id: number; name: string }[]>([]);

  const [open, setOpen] = useState(false);
  const [lines, setLines] = useState<BuyLine[]>([]);
  const [supId, setSupId] = useState("");
  const [invNo, setInvNo] = useState("");
  const [disc, setDisc] = useState("");
  const [additional, setAdditional] = useState("");
  const [paid, setPaid] = useState("");
  const [dueDate, setDueDate] = useState("");
  const [paymentMethod, setPaymentMethod] = useState<"cash" | "card" | "wallet" | "bank">("cash");
  const [landedMethod, setLandedMethod] = useState<"value" | "quantity">("value");
  const [notes, setNotes] = useState("");
  const [newSup, setNewSup] = useState("");
  const [search, setSearch] = useState("");
  const [hi, setHi] = useState(0);
  const searchRef = useRef<HTMLInputElement>(null);

  const loadList = useCallback(async () => {
    setList(
      await query(
        `SELECT p.*, COALESCE(s.name,'—') AS supplier FROM purchases p
           LEFT JOIN suppliers s ON s.id = p.supplier_id
          WHERE date(p.date) BETWEEN ? AND ? ORDER BY p.id DESC LIMIT 500`,
        [from, to]
      )
    );
  }, [from, to]);

  const loadRefs = useCallback(async () => {
    setProducts(
      await query<P>(
        `SELECT p.id,p.code,p.name,p.barcode,p.unit,p.cost_price,p.qty,
                (SELECT GROUP_CONCAT(pb.barcode,'|') FROM product_barcodes pb
                  WHERE pb.product_id=p.id) AS barcodes
           FROM products p WHERE p.is_active = 1 ORDER BY p.name COLLATE NOCASE`
      )
    );
    setSuppliers(await query(`SELECT id, name FROM suppliers ORDER BY name`));
  }, []);

  useEffect(() => {
    loadList().catch((e) => toast(String(e), "err"));
  }, [loadList, toast]);
  useEffect(() => {
    loadRefs().catch((e) => toast(String(e), "err"));
  }, [loadRefs, toast]);

  const sugg = useMemo(() => {
    const raw = search.trim();
    if (!raw) return [] as P[];
    const s = normalizeAr(raw);
    return products
      .filter(
        (p) =>
          (p.barcode || "") === raw || (p.barcodes || "").split("|").includes(raw) ||
          normalizeAr(p.name).includes(s) ||
          normalizeAr(p.code || "").includes(s)
      )
      .slice(0, 8);
  }, [search, products]);

  function addLine(p: P) {
    setLines((cur) => {
      const i = cur.findIndex((l) => l.product_id === p.id);
      if (i >= 0) {
        const c = [...cur];
        c[i] = { ...c[i], qty: n2(c[i].qty) + 1 };
        return c;
      }
      return [
        ...cur,
        {
          product_id: p.id,
          code: p.code,
          name: p.name,
          unit: p.unit,
          qty: 1,
          cost: n2(p.cost_price),
          old_qty: n2(p.qty),
          old_cost: n2(p.cost_price),
        },
      ];
    });
    setSearch("");
    searchRef.current?.focus();
  }

  const patch = (i: number, k: "qty" | "cost" | "line_discount", v: number) =>
    setLines((cur) => {
      const c = [...cur];
      c[i] = { ...c[i], [k]: Math.max(0, v) };
      return c;
    });

  const subtotal = lines.reduce((s, l) => s + buyTotal(l), 0);
  const discount = Math.min(n2(disc), subtotal);
  const total = subtotal - discount + Math.max(0, n2(additional));
  const remaining = Math.max(0, total - n2(paid));

  function reset() {
    setLines([]);
    setSupId("");
    setInvNo("");
    setDisc("");
    setAdditional("");
    setPaid("");
    setDueDate("");
    setPaymentMethod("cash");
    setLandedMethod("value");
    setNotes("");
    setSearch("");
  }

  async function addSupplier() {
    const nm = newSup.trim();
    if (!nm) return;
    try {
      const r = await execute(`INSERT INTO suppliers(name) VALUES(?)`, [nm]);
      setNewSup("");
      setSuppliers(await query(`SELECT id, name FROM suppliers ORDER BY name`));
      setSupId(String(r.last_insert_id));
      toast("تمت إضافة المورد");
    } catch (e) {
      toast(String(e), "err");
    }
  }

  async function save() {
    try {
      await savePurchase({
        lines,
        supplierId: supId ? Number(supId) : null,
        invoiceNo: invNo,
        discount: n2(disc),
        paid: n2(paid),
        notes: notes.trim() || undefined,
        userId: user?.id ?? null,
        shiftId: shift?.id ?? null,
        dueDate: dueDate || null,
        paymentMethod,
        additionalCosts: n2(additional),
        landedCostMethod: landedMethod,
      });
      toast("اتحفظت فاتورة الشراء واتحدّث المخزن ومتوسط التكلفة");
      setOpen(false);
      reset();
      await loadRefs();
      await loadList();
    } catch (e) {
      toast(String(e), "err");
    }
  }

  const totalBuy = list
    .filter((r) => r.status === "active")
    .reduce((a, r) => a + n2(r.total), 0);
  const totalDue = list
    .filter((r) => r.status === "active")
    .reduce((a, r) => a + n2(r.remaining), 0);

  return (
    <>
      <div className="toolbar">
        <Field label="من تاريخ">
          <input type="date" value={from} onChange={(e) => setFrom(e.target.value)} />
        </Field>
        <Field label="إلى تاريخ">
          <input type="date" value={to} onChange={(e) => setTo(e.target.value)} />
        </Field>
        <div style={{ flex: 1 }} />
        <button className="btn" style={{ marginTop: 18 }} onClick={() => setOpen(true)}>
          ＋ فاتورة شراء جديدة
        </button>
      </div>

      <div className="grid c3" style={{ marginBottom: 14 }}>
        <div className="stat">
          <div className="ic">🚚</div>
          <div>
            <div className="lbl">عدد فواتير الشراء</div>
            <div className="val">{num(list.length, 0)}</div>
          </div>
        </div>
        <div className="stat">
          <div className="ic">💰</div>
          <div>
            <div className="lbl">إجمالي المشتريات</div>
            <div className="val">{num(totalBuy)}</div>
          </div>
        </div>
        <div className="stat accent">
          <div className="ic">⏳</div>
          <div>
            <div className="lbl">المستحق للموردين</div>
            <div className="val">{num(totalDue)}</div>
          </div>
        </div>
      </div>

      <div className="table-wrap">
        {list.length === 0 ? (
          <Empty icon="🚚" text="مفيش فواتير شراء في الفترة دي" />
        ) : (
          <table>
            <thead>
              <tr>
                <th>رقم الفاتورة</th>
                <th>التاريخ</th>
                <th>المورد</th>
                <th className="num">الإجمالي</th>
                <th className="num">المدفوع</th>
                <th className="num">المتبقي</th>
                <th className="num">إجراءات</th>
              </tr>
            </thead>
            <tbody>
              {list.map((r) => (
                <tr key={r.id}>
                  <td style={{ fontWeight: 700 }}>{r.invoice_no}</td>
                  <td style={{ fontSize: 12, color: "var(--ink-3)" }}>
                    {dateTimeAr(r.date)}
                  </td>
                  <td>{r.supplier}</td>
                  <td className="num" style={{ fontWeight: 700 }}>
                    {num(r.total)}
                  </td>
                  <td className="num">{num(r.paid)}</td>
                  <td className="num">
                    {n2(r.remaining) > 0 ? (
                      <span className="badge danger">{num(r.remaining)}</span>
                    ) : (
                      "—"
                    )}
                  </td>
                  <td>
                    <div className="row-actions">
                      <button
                        className="icon-btn"
                        title="عرض"
                        onClick={async () => {
                          const d = await getPurchase(r.id);
                          if (d) setView(d);
                        }}
                      >
                        👁
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* إدخال فاتورة شراء */}
      {open && (
        <Modal
          wide
          title="فاتورة شراء جديدة"
          onClose={() => setOpen(false)}
          footer={
            <>
              <button className="btn" disabled={!lines.length} onClick={() => void save()}>
                💾 حفظ الفاتورة
              </button>
              <button className="btn ghost" onClick={reset}>
                تفريغ
              </button>
              <button className="btn ghost" onClick={() => setOpen(false)}>
                إغلاق
              </button>
            </>
          }
        >
          <div className="grid c3">
            <Field label="المورد *">
              <select value={supId} onChange={(e) => setSupId(e.target.value)}>
                <option value="">— اختر المورد —</option>
                {suppliers.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="رقم فاتورة المورد">
              <input
                value={invNo}
                placeholder="اختياري"
                onChange={(e) => setInvNo(e.target.value)}
              />
            </Field>
            <Field label="إضافة مورد جديد">
              <div style={{ display: "flex", gap: 6 }}>
                <input
                  value={newSup}
                  placeholder="اسم المورد"
                  onChange={(e) => setNewSup(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      e.preventDefault();
                      void addSupplier();
                    }
                  }}
                />
                <button className="btn ghost" onClick={() => void addSupplier()}>
                  ＋
                </button>
              </div>
            </Field>
          </div>

          <div className="pos-search" style={{ marginTop: 14 }}>
            <input
              ref={searchRef}
              value={search}
              placeholder="ابحث عن صنف أو امسح الباركود لإضافته للفاتورة…"
              onChange={(e) => setSearch(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "ArrowDown") {
                  e.preventDefault();
                  setHi((h) => Math.min(h + 1, sugg.length - 1));
                } else if (e.key === "ArrowUp") {
                  e.preventDefault();
                  setHi((h) => Math.max(h - 1, 0));
                } else if (e.key === "Enter") {
                  e.preventDefault();
                  const exact = products.find((p) =>
                    (p.barcode || "") === search.trim() ||
                    (p.barcodes || "").split("|").includes(search.trim())
                  );
                  const pick = exact || sugg[hi];
                  if (pick) addLine(pick);
                }
              }}
            />
            <span className="ic">🔍</span>
            {sugg.length > 0 && (
              <div className="sugg">
                {sugg.map((p, i) => (
                  <div
                    key={p.id}
                    className={`sugg-row${i === hi ? " on" : ""}`}
                    onMouseEnter={() => setHi(i)}
                    onMouseDown={(e) => {
                      e.preventDefault();
                      addLine(p);
                    }}
                  >
                    <div className="nm">
                      {p.name}
                      <div className="meta">
                        {p.code} · الرصيد {fq(p.qty)} {p.unit} · التكلفة{" "}
                        {num(p.cost_price)}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="table-wrap" style={{ marginTop: 12 }}>
            {lines.length === 0 ? (
              <Empty icon="📦" text="ابحث عن الأصناف وضيفها للفاتورة" />
            ) : (
              <table>
                <thead>
                  <tr>
                    <th>الصنف</th>
                    <th className="num" style={{ width: 100 }}>
                      الكمية
                    </th>
                    <th className="num" style={{ width: 110 }}>
                      سعر الشراء
                    </th>
                    <th className="num" style={{ width: 100 }}>خصم السطر</th>
                    <th className="num" style={{ width: 110 }}>
                      الإجمالي
                    </th>
                    <th className="num" style={{ width: 150 }}>
                      التكلفة بعد الشراء
                    </th>
                    <th style={{ width: 44 }}></th>
                  </tr>
                </thead>
                <tbody>
                  {lines.map((l, i) => (
                    <tr key={l.product_id}>
                      <td>
                        <div style={{ fontWeight: 600 }}>{l.name}</div>
                        <div style={{ fontSize: 11.5, color: "var(--ink-3)" }}>
                          الرصيد الحالي {fq(l.old_qty)} {l.unit} · التكلفة{" "}
                          {num(l.old_cost)}
                        </div>
                      </td>
                      <td className="num">
                        <input
                          type="number"
                          step="0.001"
                          value={l.qty}
                          onChange={(e) => patch(i, "qty", Number(e.target.value))}
                        />
                      </td>
                      <td className="num">
                        <input
                          type="number"
                          step="0.01"
                          value={l.cost}
                          onChange={(e) => patch(i, "cost", Number(e.target.value))}
                        />
                      </td>
                      <td className="num">
                        <input type="number" step="0.01" value={l.line_discount ?? 0}
                          onChange={(e) => patch(i,"line_discount",Number(e.target.value))} />
                      </td>
                      <td className="num" style={{ fontWeight: 700 }}>
                        {num(buyTotal(l))}
                      </td>
                      <td className="num">
                        <span className="badge">
                          {num(newAvgCost(l.old_qty, l.old_cost, l.qty, l.cost))}
                        </span>
                      </td>
                      <td>
                        <button
                          className="icon-btn danger"
                          onClick={() => setLines((c) => c.filter((_, x) => x !== i))}
                        >
                          ✕
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>

          <div className="grid c2" style={{ marginTop: 14 }}>
            <div>
              <div className="grid c2">
                <Field label={`خصم الفاتورة (${currency})`}>
                  <input
                    type="number"
                    step="0.01"
                    value={disc}
                    onChange={(e) => setDisc(e.target.value)}
                  />
                </Field>
                <Field label={`المدفوع (${currency})`}>
                  <input
                    type="number"
                    step="0.01"
                    value={paid}
                    onChange={(e) => setPaid(e.target.value)}
                  />
                </Field>
                <Field label={`تكاليف إضافية (${currency})`} hint="شحن أو نقل يضاف للتكلفة الفعلية">
                  <input type="number" step="0.01" value={additional} onChange={(e) => setAdditional(e.target.value)} />
                </Field>
                <Field label="توزيع التكاليف الإضافية">
                  <select value={landedMethod} onChange={(e) => setLandedMethod(e.target.value as "value" | "quantity")}>
                    <option value="value">بنسبة قيمة الصنف</option>
                    <option value="quantity">بنسبة الكمية</option>
                  </select>
                </Field>
                <Field label="طريقة الدفع">
                  <select value={paymentMethod} onChange={(e) => setPaymentMethod(e.target.value as any)}>
                    <option value="cash">نقدي</option><option value="card">كارت</option>
                    <option value="wallet">محفظة</option><option value="bank">تحويل بنكي</option>
                  </select>
                </Field>
                <Field label="تاريخ الاستحقاق">
                  <input type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} />
                </Field>
              </div>
              <div style={{ marginTop: 10 }}>
                <Field label="ملاحظات">
                  <textarea
                    style={{ minHeight: 60 }}
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                  />
                </Field>
              </div>
            </div>
            <div className="card" style={{ padding: 12 }}>
              <div className="tot-row">
                <span>المجموع</span>
                <b>{num(subtotal)}</b>
              </div>
              <div className="tot-row">
                <span>الخصم</span>
                <b>{num(discount)}</b>
              </div>
              <div className="tot-row"><span>تكاليف إضافية</span><b>{num(additional)}</b></div>
              <div className="tot-grand">
                <span>الإجمالي</span>
                <span className="v">{num(total)}</span>
              </div>
              <div className="tot-row">
                <span>المتبقي للمورد</span>
                <b style={{ color: remaining > 0 ? "var(--danger)" : "var(--ok)" }}>
                  {num(remaining)}
                </b>
              </div>
              <button
                className="btn ghost sm"
                style={{ marginTop: 8, width: "100%", justifyContent: "center" }}
                onClick={() => setPaid(String(total))}
              >
                دفع الكل
              </button>
            </div>
          </div>
        </Modal>
      )}

      {view && (
        <Modal
          wide
          title={`فاتورة شراء ${view.head.invoice_no}`}
          onClose={() => setView(null)}
          footer={
            <button className="btn ghost" onClick={() => setView(null)}>
              إغلاق
            </button>
          }
        >
          <div className="grid c2" style={{ marginBottom: 12 }}>
            <div className="tot-row">
              <span>المورد</span>
              <b>{view.head.supplier_name || "—"}</b>
            </div>
            <div className="tot-row">
              <span>التاريخ</span>
              <b>{dateTimeAr(view.head.date)}</b>
            </div>
          </div>
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>الصنف</th>
                  <th className="num">الكمية</th>
                  <th className="num">سعر الشراء</th>
                  <th className="num">الإجمالي</th>
                </tr>
              </thead>
              <tbody>
                {view.lines.map((l) => (
                  <tr key={l.id}>
                    <td>{l.name}</td>
                    <td className="num">
                      {fq(l.qty)} {l.unit}
                    </td>
                    <td className="num">{num(l.cost)}</td>
                    <td className="num" style={{ fontWeight: 700 }}>
                      {num(l.total)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div style={{ marginTop: 12, maxWidth: 320, marginRight: "auto" }}>
            <div className="tot-row">
              <span>المجموع</span>
              <b>{num(view.head.subtotal)}</b>
            </div>
            <div className="tot-row">
              <span>الخصم</span>
              <b>{num(view.head.discount)}</b>
            </div>
            <div className="tot-grand">
              <span>الإجمالي</span>
              <span className="v">{num(view.head.total)}</span>
            </div>
            <div className="tot-row">
              <span>المدفوع</span>
              <b>{num(view.head.paid)}</b>
            </div>
            <div className="tot-row">
              <span>المتبقي</span>
              <b>{num(view.head.remaining)}</b>
            </div>
          </div>
        </Modal>
      )}
    </>
  );
}
