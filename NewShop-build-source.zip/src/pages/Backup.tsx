import { useCallback, useEffect, useState } from "react";
import { invoke } from "@tauri-apps/api/core";
import { isTauri, sessionToken } from "../lib/db";
import { useApp } from "../lib/app";
import { num, todayIso } from "../lib/format";
import { Confirm, Empty } from "../components/ui";

interface BackupInfo {
  path: string;
  name: string;
  size: number;
}

export default function Backup() {
  const { toast } = useApp();
  const [list, setList] = useState<BackupInfo[]>([]);
  const [busy, setBusy] = useState(false);
  const [restorePath, setRestorePath] = useState<string | null>(null);
  const [done, setDone] = useState(false);

  const load = useCallback(async () => {
    if (!isTauri()) return;
    try {
      setList(
        await invoke<BackupInfo[]>("list_backups", { sessionToken: sessionToken() })
      );
    } catch (e) {
      toast(String(e), "err");
    }
  }, [toast]);

  useEffect(() => {
    void load();
  }, [load]);

  const kb = (n: number) =>
    n > 1024 * 1024 ? `${num(n / 1024 / 1024)} م.ب` : `${num(n / 1024)} ك.ب`;

  async function backupNow() {
    if (!isTauri()) return toast("النسخ الاحتياطي شغال داخل البرنامج بس", "err");
    setBusy(true);
    try {
      const license = await invoke<{ activated: boolean; trial: boolean }>("license_status");
      if (!license.activated || license.trial) {
        throw new Error("النسخ الاحتياطي الخارجي متاح بعد التفعيل الرسمي فقط");
      }
      const { save } = await import("@tauri-apps/plugin-dialog");
      const dest = await save({
        defaultPath: `NewShop-Backup-${todayIso()}.zip`,
        filters: [{ name: "نسخة احتياطية", extensions: ["zip"] }],
      });
      if (!dest) return;
      const info = await invoke<BackupInfo>("backup_now", {
        dest,
        sessionToken: sessionToken(),
      });
      toast(`اتحفظت النسخة (${kb(info.size)})`);
      await load();
    } catch (e) {
      toast(String(e), "err");
    } finally {
      setBusy(false);
    }
  }

  async function autoBackup() {
    if (!isTauri()) return toast("شغال داخل البرنامج بس", "err");
    setBusy(true);
    try {
      const info = await invoke<BackupInfo>("auto_backup", { daily: false });
      toast(`اتعملت نسخة داخلية (${kb(info.size)})`);
      await load();
    } catch (e) {
      toast(String(e), "err");
    } finally {
      setBusy(false);
    }
  }

  async function pickAndRestore() {
    if (!isTauri()) return toast("شغال داخل البرنامج بس", "err");
    try {
      const { open } = await import("@tauri-apps/plugin-dialog");
      const p = await open({
        multiple: false,
        filters: [{ name: "نسخة احتياطية", extensions: ["zip", "db"] }],
      });
      if (typeof p === "string") setRestorePath(p);
    } catch (e) {
      toast(String(e), "err");
    }
  }

  async function doRestore(path: string) {
    setBusy(true);
    try {
      await invoke<string>("restore", {
        path,
        sessionToken: sessionToken(),
      });
      setDone(true);
      toast("تم الاسترجاع — اتعملت نسخة أمان من الوضع القديم");
      await load();
    } catch (e) {
      toast(String(e), "err");
    } finally {
      setBusy(false);
      setRestorePath(null);
    }
  }

  return (
    <>
      {done && (
        <div className="card" style={{ borderColor: "var(--ok)", marginBottom: 14 }}>
          <b style={{ color: "var(--ok)" }}>تم الاسترجاع بنجاح.</b>
          <div style={{ marginTop: 6, lineHeight: 1.9, color: "var(--ink-2)" }}>
            يُفضّل تقفل البرنامج وتفتحه تاني عشان كل الشاشات تقرأ البيانات الجديدة.
          </div>
        </div>
      )}

      <div className="grid c2">
        <div className="card">
          <h3>نسخة احتياطية</h3>
          <p style={{ color: "var(--ink-2)", lineHeight: 1.9, marginTop: 0 }}>
            بتاخد نسخة كاملة من قاعدة البيانات (الأصناف، الفواتير، العملاء، كل حاجة)
            في ملف <b>.zip</b> واحد. احفظه على فلاشة أو على درايف تاني.
          </p>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            <button className="btn" disabled={busy} onClick={() => void backupNow()}>
              💾 نسخة احتياطية الآن
            </button>
            <button className="btn ghost" disabled={busy} onClick={() => void autoBackup()}>
              📁 نسخة داخلية سريعة
            </button>
          </div>
          <div className="hint" style={{ marginTop: 10, lineHeight: 1.9 }}>
            في النسخة التجريبية تظل النسخ الداخلية التلقائية فعّالة لحماية بياناتك،
            أما إخراج نسخة إلى مكان تختاره فيحتاج التفعيل الرسمي.
            <br />
            البرنامج كمان بياخد <b>نسخة تلقائية عند القفل</b> وبيحتفظ بآخر ١٠ نسخ في:
            <br />
            <code>%APPDATA%\NewShop\backups</code>
          </div>
        </div>

        <div className="card">
          <h3>استرجاع</h3>
          <p style={{ color: "var(--ink-2)", lineHeight: 1.9, marginTop: 0 }}>
            بيستبدل البيانات الحالية ببيانات النسخة. البرنامج بياخد <b>نسخة أمان</b> من
            الوضع الحالي قبل الاسترجاع أوتوماتيك، فمفيش حاجة بتضيع.
          </p>
          <button className="btn accent" disabled={busy} onClick={() => void pickAndRestore()}>
            ♻️ استرجاع من ملف
          </button>
        </div>
      </div>

      <div className="card" style={{ marginTop: 14 }}>
        <h3>النسخ التلقائية المحفوظة</h3>
        {!isTauri() ? (
          <Empty icon="💾" text="النسخ الاحتياطي بيشتغل داخل البرنامج على ويندوز" />
        ) : list.length === 0 ? (
          <Empty icon="💾" text="مفيش نسخ محفوظة لسه" />
        ) : (
          <div className="table-wrap" style={{ boxShadow: "none" }}>
            <table>
              <thead>
                <tr>
                  <th>اسم الملف</th>
                  <th className="num">الحجم</th>
                  <th className="num">إجراءات</th>
                </tr>
              </thead>
              <tbody>
                {list.map((b) => (
                  <tr key={b.path}>
                    <td style={{ fontFamily: "monospace", direction: "ltr", textAlign: "right" }}>
                      {b.name}
                    </td>
                    <td className="num">{kb(b.size)}</td>
                    <td className="num">
                      <button
                        className="btn sm ghost"
                        onClick={() => setRestorePath(b.path)}
                      >
                        استرجاع
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {restorePath && (
        <Confirm
          danger
          title="تأكيد الاسترجاع"
          message="هيتم استبدال كل البيانات الحالية ببيانات النسخة دي. هتتاخد نسخة أمان من الوضع الحالي قبلها. تكمل؟"
          confirmText="استرجع"
          onConfirm={() => void doRestore(restorePath)}
          onClose={() => setRestorePath(null)}
        />
      )}
    </>
  );
}
