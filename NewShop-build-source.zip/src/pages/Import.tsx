import { useMemo, useRef, useState } from "react";
import { useApp } from "../lib/app";
import { num } from "../lib/format";
import {
  applyPlan,
  buildPlan,
  FIELDS,
  guessMapping,
  KIND_LABEL,
  type ImportKind,
  type ImportPlan,
} from "../lib/importer";
import { readTable, type SheetData } from "../lib/xlsxread";
import { exportExcel } from "../lib/exporter";
import { Empty, Field } from "../components/ui";

const KINDS: ImportKind[] = ["products", "customers", "suppliers"];

export default function Import() {
  const { toast } = useApp();
  const fileRef = useRef<HTMLInputElement>(null);

  const [kind, setKind] = useState<ImportKind>("products");
  const [sheets, setSheets] = useState<SheetData[] | null>(null);
  const [sheetIdx, setSheetIdx] = useState(0);
  const [fileName, setFileName] = useState("");
  const [hasHeader, setHasHeader] = useState(true);
  const [mapping, setMapping] = useState<Record<string, number>>({});
  const [plan, setPlan] = useState<ImportPlan | null>(null);
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState<{ created: number; updated: number } | null>(null);

  const rows = sheets?.[sheetIdx]?.rows ?? [];
  const headers = useMemo(() => {
    if (!rows.length) return [] as string[];
    const width = Math.max(...rows.slice(0, 20).map((r) => r.length));
    return Array.from({ length: width }, (_, i) =>
      hasHeader ? rows[0][i] || `عمود ${i + 1}` : `عمود ${i + 1}`
    );
  }, [rows, hasHeader]);

  const preview = hasHeader ? rows.slice(1, 6) : rows.slice(0, 5);

  function reset() {
    setSheets(null);
    setPlan(null);
    setDone(null);
    setMapping({});
    setFileName("");
    setSheetIdx(0);
    if (fileRef.current) fileRef.current.value = "";
  }

  async function onFile(file?: File) {
    if (!file) return;
    setBusy(true);
    setPlan(null);
    setDone(null);
    try {
      const sh = await readTable(file);
      setSheets(sh);
      setSheetIdx(0);
      setFileName(file.name);
      const first = sh[0]?.rows[0] ?? [];
      setMapping(guessMapping(first, kind));
      toast(`اتقرا الملف: ${sh[0]?.rows.length ?? 0} صف`);
    } catch (e) {
      toast(e instanceof Error ? e.message : String(e), "err");
      reset();
    } finally {
      setBusy(false);
    }
  }

  function changeKind(k: ImportKind) {
    setKind(k);
    setPlan(null);
    setDone(null);
    if (rows.length) setMapping(guessMapping(rows[0] ?? [], k));
  }

  async function doPreview() {
    setBusy(true);
    try {
      setPlan(await buildPlan(rows, mapping, kind, hasHeader));
    } catch (e) {
      toast(String(e), "err");
    } finally {
      setBusy(false);
    }
  }

  async function doApply() {
    if (!plan) return;
    setBusy(true);
    try {
      const r = await applyPlan(plan);
      setDone(r);
      setPlan(null);
      toast(`تم الاستيراد: ${r.created} جديد و${r.updated} تعديل`);
    } catch (e) {
      toast(String(e), "err");
    } finally {
      setBusy(false);
    }
  }

  /** ملف نموذجي بالأعمدة الصح عشان المستخدم يملاه */
  async function downloadTemplate() {
    const defs = FIELDS[kind];
    try {
      await exportExcel(
        `نموذج-${KIND_LABEL[kind]}`,
        [
          {
            name: KIND_LABEL[kind],
            cols: defs.map((d) => ({
              key: d.key,
              label: d.label + (d.required ? " *" : ""),
              width: 20,
              type: d.kind === "number" ? ("number" as const) : ("text" as const),
            })),
            rows: [],
          },
        ]
      );
      toast("اتحفظ الملف النموذجي");
    } catch (e) {
      toast(String(e), "err");
    }
  }

  return (
    <>
      {/* ١ — النوع والملف */}
      <div className="card">
        <h3>١) إيه اللي عايز تستورده؟</h3>
        <div className="pay-grid" style={{ maxWidth: 560 }}>
          {KINDS.map((k) => (
            <button
              key={k}
              className={`pay-opt${kind === k ? " on" : ""}`}
              onClick={() => changeKind(k)}
            >
              {KIND_LABEL[k]}
            </button>
          ))}
        </div>

        <div style={{ display: "flex", gap: 10, marginTop: 16, flexWrap: "wrap" }}>
          <input
            ref={fileRef}
            type="file"
            accept=".xlsx,.csv,.txt,.tsv"
            style={{ display: "none" }}
            onChange={(e) => void onFile(e.target.files?.[0])}
          />
          <button className="btn" disabled={busy} onClick={() => fileRef.current?.click()}>
            📂 اختار ملف (xlsx أو CSV)
          </button>
          <button className="btn ghost" onClick={() => void downloadTemplate()}>
            ⬇️ نزّل ملف نموذجي فاضي
          </button>
          {fileName && (
            <button className="btn ghost" onClick={reset}>
              ✕ ابدأ من الأول
            </button>
          )}
        </div>

        {fileName && (
          <div className="hint" style={{ marginTop: 10 }}>
            الملف: <b>{fileName}</b> · عدد الصفوف: <b>{rows.length}</b>
            {sheets && sheets.length > 1 && (
              <>
                {" "}· الشيت:{" "}
                <select
                  value={sheetIdx}
                  onChange={(e) => {
                    const i = Number(e.target.value);
                    setSheetIdx(i);
                    setPlan(null);
                    setMapping(guessMapping(sheets[i].rows[0] ?? [], kind));
                  }}
                  style={{ width: "auto", display: "inline-block" }}
                >
                  {sheets.map((s, i) => (
                    <option key={i} value={i}>
                      {s.name}
                    </option>
                  ))}
                </select>
              </>
            )}
          </div>
        )}
      </div>

      {/* ٢ — ربط الأعمدة */}
      {rows.length > 0 && (
        <div className="card">
          <h3>٢) اربط أعمدة الملف بحقول البرنامج</h3>

          <label className="perm-item" style={{ marginBottom: 12 }}>
            <input
              type="checkbox"
              checked={hasHeader}
              onChange={(e) => {
                setHasHeader(e.target.checked);
                setPlan(null);
              }}
            />
            الصف الأول في الملف هو أسماء الأعمدة
          </label>

          <div className="grid c3">
            {FIELDS[kind].map((f) => (
              <Field
                key={f.key}
                label={f.label + (f.required ? " *" : "")}
                hint={f.required ? "إجباري" : undefined}
              >
                <select
                  value={mapping[f.key] ?? ""}
                  onChange={(e) => {
                    const v = e.target.value;
                    setPlan(null);
                    setMapping((m) => {
                      const c = { ...m };
                      if (v === "") delete c[f.key];
                      else c[f.key] = Number(v);
                      return c;
                    });
                  }}
                >
                  <option value="">— مش موجود —</option>
                  {headers.map((h, i) => (
                    <option key={i} value={i}>
                      {h}
                    </option>
                  ))}
                </select>
              </Field>
            ))}
          </div>

          <div className="sh-sub" style={{ marginTop: 16 }}>
            معاينة أول ٥ صفوف من الملف
          </div>
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  {headers.map((h, i) => (
                    <th key={i}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {preview.map((r, i) => (
                  <tr key={i}>
                    {headers.map((_, c) => (
                      <td key={c}>{r[c] ?? ""}</td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div style={{ marginTop: 14 }}>
            <button className="btn" disabled={busy} onClick={() => void doPreview()}>
              🔍 اعرض المعاينة قبل التنفيذ
            </button>
          </div>
        </div>
      )}

      {/* ٣ — المعاينة */}
      {plan && (
        <div className="card">
          <h3>٣) المعاينة — لسه مافيش أي حاجة اتغيّرت في البرنامج</h3>

          <div className="grid c4" style={{ marginBottom: 14 }}>
            <div className="stat">
              <div className="ic">🆕</div>
              <div>
                <div className="lbl">هيتضاف جديد</div>
                <div className="val">{num(plan.create.length, 0)}</div>
              </div>
            </div>
            <div className="stat">
              <div className="ic">✏️</div>
              <div>
                <div className="lbl">هيتعدّل الموجود</div>
                <div className="val">{num(plan.update.length, 0)}</div>
              </div>
            </div>
            <div className="stat accent">
              <div className="ic">⚠️</div>
              <div>
                <div className="lbl">صفوف فيها مشاكل</div>
                <div className="val">{num(plan.issues.length, 0)}</div>
              </div>
            </div>
            <div className="stat">
              <div className="ic">⏭️</div>
              <div>
                <div className="lbl">صفوف فاضية اتخطّت</div>
                <div className="val">{num(plan.skipped, 0)}</div>
              </div>
            </div>
          </div>

          {plan.newCategories.length > 0 && (
            <div className="hint" style={{ marginBottom: 10 }}>
              هيتعمل تصنيفات جديدة: <b>{plan.newCategories.join("، ")}</b>
            </div>
          )}

          {plan.issues.length > 0 && (
            <>
              <div className="sh-sub">المشاكل (الصفوف دي مش هتتستورد)</div>
              <div className="table-wrap" style={{ maxHeight: 240, marginBottom: 14 }}>
                <table>
                  <thead>
                    <tr>
                      <th style={{ width: 90 }}>السطر</th>
                      <th>المشكلة</th>
                    </tr>
                  </thead>
                  <tbody>
                    {plan.issues.slice(0, 200).map((is, i) => (
                      <tr key={i}>
                        <td className="num">{is.row}</td>
                        <td>{is.message}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </>
          )}

          {plan.update.length > 0 && (
            <>
              <div className="sh-sub">هيتعدّل (موجود بنفس الكود أو الباركود أو الاسم)</div>
              <div className="table-wrap" style={{ maxHeight: 220, marginBottom: 14 }}>
                <table>
                  <tbody>
                    {plan.update.slice(0, 100).map((u, i) => (
                      <tr key={i}>
                        <td>{u.name}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </>
          )}

          {plan.create.length + plan.update.length === 0 ? (
            <Empty icon="🤷" text="مفيش أي صف صالح للاستيراد — راجع ربط الأعمدة" />
          ) : (
            <div style={{ display: "flex", gap: 10 }}>
              <button className="btn accent" disabled={busy} onClick={() => void doApply()}>
                ✅ نفّذ الاستيراد
              </button>
              <button className="btn ghost" onClick={() => setPlan(null)}>
                رجوع للتعديل
              </button>
            </div>
          )}
        </div>
      )}

      {/* ٤ — تم */}
      {done && (
        <div className="card">
          <h3>تم الاستيراد ✅</h3>
          <p style={{ lineHeight: 2, margin: 0 }}>
            اتضاف <b>{done.created}</b> سجل جديد، واتعدّل <b>{done.updated}</b> سجل موجود.
          </p>
          <div style={{ marginTop: 12 }}>
            <button className="btn ghost" onClick={reset}>
              استيراد ملف تاني
            </button>
          </div>
        </div>
      )}
    </>
  );
}
