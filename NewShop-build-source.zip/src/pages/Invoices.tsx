import { useCallback, useEffect, useState } from "react";
import { batch, query } from "../lib/db";
import { useApp } from "../lib/app";
import { useAuth } from "../lib/auth";
import { dateTimeAr, normalizeAr, num, qty as fq, todayIso } from "../lib/format";
import {
  cancelSale,
  getInvoice,
  type InvoiceHead,
  type InvoiceLine,
  type PaySplit,
  PAY_LABELS,
} from "../lib/sales";
import { Empty, Field, ManagerApprove, Modal } from "../components/ui";
import InvoicePrint from "../components/InvoicePrint";



export default function Invoices() {
  const { toast, currency, shift } = useApp();
  const { user, can } = useAuth();
  const [from, setFrom] = useState(todayIso());
  const [to, setTo] = useState(todayIso());
  const [search, setSearch] = useState("");
  const [rows, setRows] = useState<any[]>([]);
  const [open, setOpen] = useState<{
    head: InvoiceHead;
    lines: InvoiceLine[];
    payments: PaySplit[];
  } | null>(
    null
  );
  const [cancelId, setCancelId] = useState<number | null>(null);
  const [reason, setReason] = useState("");
  const [managerAsk, setManagerAsk] = useState(false);
  const [copy, setCopy] = useState(false);

  const load = useCallback(async () => {
    setRows(
      await query(
        `SELECT s.*, COALESCE(c.name,'عميل نقدي') AS customer
           FROM sales s LEFT JOIN customers c ON c.id = s.customer_id
          WHERE date(s.date) BETWEEN ? AND ?
          ORDER BY s.id DESC LIMIT 500`,
        [from, to]
      )
    );
  }, [from, to]);

  useEffect(() => {
    load().catch((e) => toast(String(e), "err"));
  }, [load, toast]);

  const view = rows.filter((r) => {
    const s = normalizeAr(search);
    if (!s) return true;
    return (
      normalizeAr(r.invoice_no).includes(s) || normalizeAr(r.customer || "").includes(s)
    );
  });

  const sum = view
    .filter((r) => r.status === "active")
    .reduce((a, r) => a + Number(r.total || 0), 0);
  const due = view
    .filter((r) => r.status === "active")
    .reduce((a, r) => a + Number(r.remaining || 0), 0);

  async function show(id: number) {
    const inv = await getInvoice(id);
    if (inv) {
      setCopy(false);
      setOpen(inv);
    }
  }

  async function reprint() {
    if (!open) return;
    if (!can("sales_reprint")) return toast("مالكش صلاحية إعادة طباعة الفاتورة", "err");
    try {
      await batch([
        {
          sql: `INSERT INTO audit_log(user_id,action,entity_type,entity_id,new_values)
                VALUES(?,'invoice_reprinted','sale',?,?)`,
          params: [user?.id ?? null,open.head.id,JSON.stringify({ invoice_no: open.head.invoice_no })],
        },
      ],"sales_reprint");
      setCopy(true);
      setTimeout(() => window.print(),120);
    } catch (e) {
      toast(String(e),"err");
    }
  }

  async function doCancel(approvedBy: number | null = null) {
    if (cancelId === null) return;
    if (!reason.trim()) return toast("سبب الإلغاء مطلوب", "err");
    if (!can("invoices_cancel") && approvedBy === null) {
      setManagerAsk(true);
      return;
    }
    try {
      await cancelSale(
        cancelId,
        reason.trim(),
        user?.id ?? null,
        shift?.id ?? null,
        approvedBy
      );
      toast("تم إلغاء الفاتورة ورجوع الأصناف للمخزن");
      setCancelId(null);
      setReason("");
      setOpen(null);
      await load();
    } catch (e) {
      toast(String(e), "err");
    }
  }

  return (
    <>
      <div className="toolbar">
        <Field label="من تاريخ">
          <input type="date" value={from} onChange={(e) => setFrom(e.target.value)} />
        </Field>
        <Field label="إلى تاريخ">
          <input type="date" value={to} onChange={(e) => setTo(e.target.value)} />
        </Field>
        <div className="search-wrap" style={{ marginTop: 18 }}>
          <input
            placeholder="ابحث برقم الفاتورة أو اسم العميل…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
          <span className="ic">🔍</span>
        </div>
        <button
          className="btn ghost"
          style={{ marginTop: 18 }}
          onClick={() => {
            setFrom(todayIso());
            setTo(todayIso());
          }}
        >
          النهارده
        </button>
      </div>

      <div className="grid c3" style={{ marginBottom: 14 }}>
        <div className="stat">
          <div className="ic">🧾</div>
          <div>
            <div className="lbl">عدد الفواتير</div>
            <div className="val">{num(view.length, 0)}</div>
          </div>
        </div>
        <div className="stat">
          <div className="ic">💰</div>
          <div>
            <div className="lbl">إجمالي المبيعات</div>
            <div className="val">{num(sum)}</div>
          </div>
        </div>
        <div className="stat accent">
          <div className="ic">⏳</div>
          <div>
            <div className="lbl">المتبقي (آجل)</div>
            <div className="val">{num(due)}</div>
          </div>
        </div>
      </div>

      <div className="table-wrap">
        {view.length === 0 ? (
          <Empty icon="🧾" text="مفيش فواتير في الفترة دي" />
        ) : (
          <table>
            <thead>
              <tr>
                <th>رقم الفاتورة</th>
                <th>التاريخ</th>
                <th>العميل</th>
                <th className="num">الإجمالي</th>
                <th className="num">المدفوع</th>
                <th className="num">المتبقي</th>
                <th className="num">الدفع</th>
                <th className="num">الحالة</th>
                <th className="num">إجراءات</th>
              </tr>
            </thead>
            <tbody>
              {view.map((s) => (
                <tr key={s.id} style={s.status !== "active" ? { opacity: 0.55 } : undefined}>
                  <td style={{ fontWeight: 700 }}>{s.invoice_no}</td>
                  <td style={{ fontSize: 12, color: "var(--ink-3)" }}>
                    {dateTimeAr(s.date)}
                  </td>
                  <td>{s.customer}</td>
                  <td className="num" style={{ fontWeight: 700 }}>
                    {num(s.total)}
                  </td>
                  <td className="num">{num(s.paid)}</td>
                  <td className="num">
                    {Number(s.remaining) > 0 ? (
                      <span className="badge danger">{num(s.remaining)}</span>
                    ) : (
                      "—"
                    )}
                  </td>
                  <td className="num">
                    <span className={`badge ${s.remaining > 0 ? "warn" : "ok"}`}>
                      {PAY_LABELS[s.payment_type] || s.payment_type}
                    </span>
                  </td>
                  <td className="num">
                    <span className={`badge ${s.status === "active" ? "ok" : "danger"}`}>
                      {s.status === "active" ? "سارية" : "ملغية"}
                    </span>
                  </td>
                  <td>
                    <div className="row-actions">
                      <button
                        className="icon-btn"
                        title="عرض وطباعة"
                        onClick={() => void show(s.id)}
                      >
                        👁
                      </button>
                      {s.status === "active" && (
                        <button
                          className="icon-btn danger"
                          title="إلغاء الفاتورة"
                          onClick={() => setCancelId(s.id)}
                        >
                          ✕
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {open && (
        <Modal
          wide
          title={`فاتورة ${open.head.invoice_no}`}
          onClose={() => setOpen(null)}
          footer={
            <>
              <button className="btn" onClick={() => void reprint()}>
                🖨️ إعادة طباعة / حفظ PDF
              </button>
              {open.head.status === "active" && (
                <button
                  className="btn danger"
                  onClick={() => setCancelId(open.head.id)}
                >
                  إلغاء الفاتورة
                </button>
              )}
              <button className="btn ghost" onClick={() => setOpen(null)}>
                إغلاق
              </button>
            </>
          }
        >
          <div className="grid c2" style={{ marginBottom: 12 }}>
            <div className="tot-row">
              <span>العميل</span>
              <b>{open.head.customer_name || "عميل نقدي"}</b>
            </div>
            <div className="tot-row">
              <span>التاريخ</span>
              <b>{dateTimeAr(open.head.date)}</b>
            </div>
          </div>

          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>الصنف</th>
                  <th className="num">الكمية</th>
                  <th className="num">السعر</th>
                  <th className="num">خصم</th>
                  <th className="num">الإجمالي</th>
                </tr>
              </thead>
              <tbody>
                {open.lines.map((l) => (
                  <tr key={l.id}>
                    <td>{l.name}</td>
                    <td className="num">
                      {fq(l.qty)} {l.unit}
                    </td>
                    <td className="num">{num(l.price)}</td>
                    <td className="num">{l.discount ? num(l.discount) : "—"}</td>
                    <td className="num" style={{ fontWeight: 700 }}>
                      {num(l.total)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div style={{ marginTop: 12, maxWidth: 320, marginRight: "auto" }}>
            <div className="tot-row">
              <span>المجموع</span>
              <b>{num(open.head.subtotal)}</b>
            </div>
            <div className="tot-row">
              <span>الخصم</span>
              <b>{num(open.head.discount)}</b>
            </div>
            <div className="tot-grand">
              <span>الإجمالي</span>
              <span className="v">
                {num(open.head.total)} {currency}
              </span>
            </div>
            <div className="tot-row">
              <span>المدفوع</span>
              <b>{num(open.head.paid)}</b>
            </div>
            <div className="tot-row">
              <span>المتبقي</span>
              <b style={{ color: Number(open.head.remaining) > 0 ? "var(--danger)" : "" }}>
                {num(open.head.remaining)}
              </b>
            </div>
          </div>
        </Modal>
      )}

      {cancelId !== null && (
        <Modal
          title="إلغاء فاتورة"
          onClose={() => setCancelId(null)}
          footer={
            <>
              <button className="btn danger" onClick={() => void doCancel()}>
                تأكيد الإلغاء
              </button>
              <button className="btn ghost" onClick={() => setCancelId(null)}>
                رجوع
              </button>
            </>
          }
        >
          <p style={{ marginTop: 0, lineHeight: 1.9 }}>
            هيتم رجوع كل الأصناف للمخزن، وتعديل رصيد العميل لو الفاتورة كانت آجل.
            الفاتورة هتفضل موجودة بحالة «ملغية» للمراجعة.
          </p>
          <Field label="سبب الإلغاء">
            <input
              autoFocus
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="مثال: العميل رجّع البضاعة"
            />
          </Field>
        </Modal>
      )}
      {managerAsk && (
        <ManagerApprove
          perm="invoices_cancel"
          title="موافقة مدير على إلغاء الفاتورة"
          message="هذه العملية تعكس المخزون والمدفوعات وتُسجل في سجل التدقيق. أدخل بيانات مدير مخوّل."
          onApprove={(approver) => void doCancel(approver.id)}
          onClose={() => setManagerAsk(false)}
        />
      )}

      {open && (
        <InvoicePrint head={open.head} lines={open.lines} payments={open.payments} copy={copy} />
      )}
    </>
  );
}
