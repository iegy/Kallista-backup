import { useEffect, useState } from "react";
import { appInfo, isTauri, type AppInfo } from "../lib/db";
import { getLicense, type LicenseStatus } from "./Activate";
import { useAuth } from "../lib/auth";

export default function About() {
  const [info, setInfo] = useState<AppInfo | null>(null);
  const [lic, setLic] = useState<LicenseStatus | null>(null);
  const { user } = useAuth();

  useEffect(() => {
    appInfo().then(setInfo).catch(() => {});
    getLicense().then(setLic).catch(() => {});
  }, []);

  const Line = ({ k, v }: { k: string; v: string }) => (
    <div
      style={{
        display: "flex",
        gap: 12,
        padding: "9px 0",
        borderBottom: "1px solid #eeeae0",
      }}
    >
      <div style={{ width: 150, color: "var(--ink-3)", fontSize: 13 }}>{k}</div>
      <div style={{ fontWeight: 600, wordBreak: "break-all" }}>{v}</div>
    </div>
  );

  return (
    <div style={{ maxWidth: 720 }}>
      <div className="card" style={{ textAlign: "center", padding: 26 }}>
        <div
          style={{
            width: 74,
            height: 74,
            margin: "0 auto 12px",
            borderRadius: 18,
            background: "var(--primary)",
            color: "#fff",
            display: "grid",
            placeItems: "center",
            fontSize: 27,
            fontWeight: 800,
          }}
        >
          NS
        </div>
        <h2 style={{ margin: "0 0 4px", fontSize: 22 }}>NewShop</h2>
        <div style={{ color: "var(--ink-3)", fontSize: 13 }}>
          برنامج إدارة المبيعات والمخزون — نسخة {info?.version ?? "2.0.0"}
        </div>
        <div style={{ marginTop: 10 }}>
          <span className="badge ok">يعمل أوفلاين بالكامل</span>{" "}
          <span className={`badge ${lic?.trial ? "danger" : ""}`}>
            {lic?.trial ? "نسخة تجريبية 15 يومًا" : "النسخة الكاملة"}
          </span>
        </div>
      </div>

      <div className="card">
        <h3>بيانات المطور</h3>
        <Line k="تصميم وبرمجة" v="محمد حسين" />
        <Line k="الموقع" v="iegy.net" />
        <Line k="تليفون" v="01000220606" />
        <Line k="إيميل" v="egyup@outlook.com" />
      </div>

      <div className="card">
        <h3>معلومات النظام</h3>
        <Line k="نسخة البرنامج" v={info?.version ?? "2.0.0"} />
        <Line k="مكان قاعدة البيانات" v={info?.db_path ?? "—"} />
        <Line k="مجلد البيانات" v={info?.app_dir ?? "—"} />
        <Line k="بيئة التشغيل" v={isTauri() ? "نافذة NewShop (ويندوز)" : "معاينة في المتصفح"} />
        <Line k="وضع البيانات" v={info?.portable ? "Portable" : "AppData"} />
        <Line k="المستخدم الحالي" v={`${user?.full_name || user?.username || "—"} (${user?.role === "owner" ? "مالك" : user?.role === "admin" ? "مدير" : "كاشير"})`} />
      </div>

      <div className="card">
        <h3>الترخيص</h3>
        <div style={{ marginBottom: 10 }}>
          <span className={`badge ${lic?.activated ? "ok" : "danger"}`}>
            {lic?.trial
              ? lic.activated
                ? `نسخة تجريبية — متبقي ${lic.trial_days_remaining ?? 0} يوم`
                : "انتهت الفترة التجريبية"
              : lic?.activated
              ? lic.license_type === "expiring"
                ? `مفعّل حتى ${lic.expires_at}`
                : lic.legacy
                  ? "Legacy Lifetime License"
                  : "مفعّل مدى الحياة على هذا الجهاز"
              : "غير مفعّل"}
          </span>
        </div>
        <Line k="كود الجهاز" v={lic?.device_code ?? "—"} />
        <Line k="تاريخ التفعيل" v={lic?.since ?? "—"} />
        {lic?.trial_started_at && <Line k="بداية التجربة" v={lic.trial_started_at} />}
        {lic?.trial_expires_at && <Line k="نهاية التجربة" v={lic.trial_expires_at} />}
        <Line k="إصدار الترخيص" v={lic?.format_version ? `V${lic.format_version}` : "—"} />
        {lic?.customer_name && <Line k="اسم العميل" v={lic.customer_name} />}
        {lic?.license_id && <Line k="رقم الترخيص" v={lic.license_id} />}
        {lic?.edition && <Line k="الإصدار" v={lic.edition} />}
        {lic?.expires_at && <Line k="تاريخ الانتهاء" v={lic.expires_at} />}
        {lic?.key && <Line k="كود التفعيل" v={`${lic.key.slice(0, 24)}…`} />}
        <p style={{ marginBottom: 0, marginTop: 12, color: "var(--ink-3)", fontSize: 12.5, lineHeight: 1.9 }}>
          للتفعيل أو النقل لجهاز تاني: ابعت كود الجهاز لصاحب البرنامج على واتساب
          01000220606.
        </p>
      </div>

      <div className="card">
        <h3>حقوق النشر</h3>
        <p style={{ margin: 0, lineHeight: 2, color: "var(--ink-2)" }}>
          © 2026 محمد حسين — iegy.net. كل الحقوق محفوظة.
          <br />
          هذه النسخة مرخّصة للاستخدام على جهاز واحد فقط.
        </p>
      </div>
    </div>
  );
}
