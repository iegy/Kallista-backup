import { useCallback, useEffect, useMemo, useState } from "react";
import { batch, execute, query, type Op } from "../lib/db";
import { useApp } from "../lib/app";
import { useAuth } from "../lib/auth";
import { dateTimeAr, n2, normalizeAr, num, qty as fq } from "../lib/format";
import { Confirm, Empty, Field, Modal } from "../components/ui";

interface Product {
  id: number;
  code: string;
  name: string;
  secondary_name: string | null;
  barcode: string | null;
  barcodes: string | null;
  plu: string | null;
  category_id: number | null;
  category_name: string | null;
  unit: string;
  cost_price: number;
  sell_price: number;
  wholesale_price: number;
  qty: number;
  min_qty: number;
  max_qty: number | null;
  preferred_supplier_id: number | null;
  price_level_special: number | null;
  is_active: number;
  notes: string | null;
}

const UNITS = [
  "قطعة", "كجم", "جرام", "لتر", "علبة", "كرتونة",
  "كيس", "زجاجة", "طبق", "متر", "شنطة", "دستة",
];

const blank = {
  id: 0,
  code: "",
  name: "",
  secondary_name: "",
  barcode: "",
  additional_barcodes: "",
  plu: "",
  category_id: "" as string | number,
  unit: "قطعة",
  cost_price: "",
  sell_price: "",
  wholesale_price: "",
  qty: "",
  min_qty: "",
  max_qty: "",
  preferred_supplier_id: "" as string | number,
  price_level_special: "",
  is_active: 1,
  notes: "",
};

export default function Products() {
  const { toast, settings, currency } = useApp();
  const { can } = useAuth();
  const [rows, setRows] = useState<Product[]>([]);
  const [cats, setCats] = useState<{ id: number; name: string }[]>([]);
  const [suppliers, setSuppliers] = useState<{ id: number; name: string }[]>([]);
  const [search, setSearch] = useState("");
  const [catFilter, setCatFilter] = useState("");
  const [onlyLow, setOnlyLow] = useState(false);
  const [form, setForm] = useState<typeof blank | null>(null);
  const [delId, setDelId] = useState<number | null>(null);
  const [moves, setMoves] = useState<{ p: Product; list: any[] } | null>(null);

  const load = useCallback(async () => {
    setRows(
      await query<Product>(
        `SELECT p.*, c.name AS category_name,
                (SELECT GROUP_CONCAT(pb.barcode,'|') FROM product_barcodes pb
                  WHERE pb.product_id=p.id ORDER BY pb.is_primary DESC,pb.id) AS barcodes
           FROM products p LEFT JOIN categories c ON c.id = p.category_id
          ORDER BY p.name COLLATE NOCASE`
      )
    );
    setCats(await query(`SELECT id, name FROM categories ORDER BY name`));
    setSuppliers(await query(`SELECT id,name FROM suppliers ORDER BY name`));
  }, []);

  useEffect(() => {
    load().catch((e) => toast(String(e), "err"));
  }, [load, toast]);

  const view = useMemo(() => {
    const s = normalizeAr(search);
    return rows.filter((p) => {
      if (catFilter && String(p.category_id) !== catFilter) return false;
      if (onlyLow && !(n2(p.qty) <= n2(p.min_qty))) return false;
      if (!s) return true;
      return (
        normalizeAr(p.name).includes(s) ||
        normalizeAr(p.code || "").includes(s) ||
        (p.barcode || "").includes(search.trim()) ||
        (p.barcodes || "").includes(search.trim())
      );
    });
  }, [rows, search, catFilter, onlyLow]);

  const totals = useMemo(() => {
    let cost = 0, sell = 0, low = 0;
    for (const p of view) {
      cost += n2(p.qty) * n2(p.cost_price);
      sell += n2(p.qty) * n2(p.sell_price);
      if (n2(p.qty) <= n2(p.min_qty)) low++;
    }
    return { cost, sell, low };
  }, [view]);

  async function nextCode(): Promise<string> {
    const r = await query<any>(
      `SELECT code FROM products WHERE code LIKE 'P%' ORDER BY id DESC LIMIT 50`
    );
    let max = 0;
    for (const x of r) {
      const m = /^P(\d+)$/.exec(x.code || "");
      if (m) max = Math.max(max, Number(m[1]));
    }
    return "P" + String(max + 1).padStart(3, "0");
  }

  async function openNew() {
    setForm({
      ...blank,
      code: await nextCode(),
      min_qty: settings.default_min_qty || "5",
    });
  }

  function openEdit(p: Product) {
    setForm({
      id: p.id,
      code: p.code || "",
      name: p.name,
      secondary_name: p.secondary_name || "",
      barcode: p.barcode || "",
      additional_barcodes: (p.barcodes || "")
        .split("|")
        .filter((x) => x && x !== p.barcode)
        .join("\n"),
      plu: p.plu || "",
      category_id: p.category_id ?? "",
      unit: p.unit || "قطعة",
      cost_price: String(p.cost_price ?? ""),
      sell_price: String(p.sell_price ?? ""),
      wholesale_price: String(p.wholesale_price ?? ""),
      qty: String(p.qty ?? ""),
      min_qty: String(p.min_qty ?? ""),
      max_qty: String(p.max_qty ?? ""),
      preferred_supplier_id: p.preferred_supplier_id ?? "",
      price_level_special: String(p.price_level_special ?? ""),
      is_active: p.is_active,
      notes: p.notes || "",
    });
  }

  async function save() {
    if (!form) return;
    if (!form.name.trim()) return toast("لازم تدخل اسم الصنف", "err");
    if (n2(form.sell_price) <= 0) return toast("سعر البيع لازم يكون أكبر من صفر", "err");

    const p = [
      form.code.trim() || null,
      form.name.trim(),
      form.secondary_name.trim() || null,
      form.barcode.trim() || null,
      form.plu.trim() || null,
      form.category_id === "" ? null : Number(form.category_id),
      form.unit,
      n2(form.cost_price),
      n2(form.sell_price),
      n2(form.wholesale_price) || n2(form.sell_price),
      n2(form.qty),
      n2(form.min_qty),
      form.max_qty === "" ? null : n2(form.max_qty),
      form.preferred_supplier_id === "" ? null : Number(form.preferred_supplier_id),
      form.price_level_special === "" ? null : n2(form.price_level_special),
      form.is_active,
      form.notes.trim() || null,
    ];

    const barcodes = [
      form.barcode.trim(),
      ...form.additional_barcodes.split(/[\n,،;]+/).map((x) => x.trim()),
    ].filter((x, i, a) => x && a.indexOf(x) === i);

    try {
      if (form.id) {
        const old = rows.find((r) => r.id === form.id)!;
        const ops: Op[] = [{
          sql: `UPDATE products SET code=?,name=?,secondary_name=?,barcode=?,plu=?,category_id=?,unit=?,
                  cost_price=?,sell_price=?,wholesale_price=?,qty=?,min_qty=?,max_qty=?,
                  preferred_supplier_id=?,price_level_special=?,is_active=?,notes=? WHERE id=?`,
          params: [...(p as any), form.id],
        }];
        const diff = n2(form.qty) - n2(old.qty);
        if (diff !== 0) {
          ops.push({
            sql: `INSERT INTO stock_moves(product_id,qty_change,type,note,reference_type,
                    reference_id,qty_before,qty_after,unit_cost,total_value)
                  VALUES(?,?,'manual','تعديل يدوي للكمية من شاشة الأصناف','manual',?,?,?, ?,?)`,
            params: [form.id, diff, form.id, old.qty, n2(form.qty), n2(form.cost_price), diff * n2(form.cost_price)],
          });
        }
        ops.push({ sql: `DELETE FROM product_barcodes WHERE product_id=?`, params: [form.id] });
        barcodes.forEach((code, i) => ops.push({
          sql: `INSERT INTO product_barcodes(product_id,barcode,label,is_primary)
                VALUES(?,?,?,?)`,
          params: [form.id, code, i === 0 ? "أساسي" : `إضافي ${i}`, i === 0 ? 1 : 0],
        }));
        ops.push({
          sql: `INSERT INTO audit_log(action,entity_type,entity_id,new_values)
                VALUES('product_updated','product',?,?)`,
          params: [form.id, JSON.stringify({ name: form.name.trim(), barcodes: barcodes.length })],
        });
        await batch(ops, "products_edit");
        toast("تم حفظ التعديلات");
      } else {
        const ops: Op[] = [{
          sql: `INSERT INTO products(code,name,secondary_name,barcode,plu,category_id,unit,cost_price,
                  sell_price,wholesale_price,qty,min_qty,max_qty,preferred_supplier_id,
                  price_level_special,is_active,notes)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
          params: p as any,
        }];
        if (n2(form.qty) !== 0) {
          ops.push({
            sql: `INSERT INTO stock_moves(product_id,qty_change,type,note,reference_type,
                    reference_id,qty_before,qty_after,unit_cost,total_value)
                  VALUES(?,?,'manual','رصيد افتتاحي','opening',?,0,?,?,?)`,
            params: ["$LAST_ID:0", n2(form.qty), "$LAST_ID:0", n2(form.qty), n2(form.cost_price), n2(form.qty) * n2(form.cost_price)],
          });
        }
        barcodes.forEach((code, i) => ops.push({
          sql: `INSERT INTO product_barcodes(product_id,barcode,label,is_primary)
                VALUES(?,?,?,?)`,
          params: ["$LAST_ID:0", code, i === 0 ? "أساسي" : `إضافي ${i}`, i === 0 ? 1 : 0],
        }));
        ops.push({
          sql: `INSERT INTO audit_log(action,entity_type,entity_id,new_values)
                VALUES('product_created','product',?,?)`,
          params: ["$LAST_ID:0", JSON.stringify({ name: form.name.trim(), barcodes: barcodes.length })],
        });
        await batch(ops, "products_edit");
        toast("تمت إضافة الصنف");
      }
      setForm(null);
      await load();
    } catch (e: any) {
      const m = String(e);
      toast(
        m.includes("UNIQUE") ? "الكود ده مستخدم قبل كده — غيّره" : m,
        "err"
      );
    }
  }

  async function remove(id: number) {
    try {
      const [u] = await query<any>(
        `SELECT (SELECT COUNT(*) FROM sale_items WHERE product_id=?) +
                (SELECT COUNT(*) FROM purchase_items WHERE product_id=?) AS n`,
        [id, id]
      );
      if (Number(u?.n || 0) > 0) {
        await execute(`UPDATE products SET is_active=0 WHERE id=?`, [id]);
        toast("الصنف عليه حركة — تم إيقافه بدل حذفه");
      } else {
        await execute(`DELETE FROM products WHERE id=?`, [id]);
        toast("تم حذف الصنف");
      }
      await load();
    } catch (e) {
      toast(String(e), "err");
    }
  }

  async function showMoves(p: Product) {
    const list = await query(
      `SELECT * FROM stock_moves WHERE product_id=? ORDER BY id DESC LIMIT 200`,
      [p.id]
    );
    setMoves({ p, list });
  }

  const MOVE_AR: Record<string, string> = {
    sale: "بيع",
    purchase: "شراء",
    return_sale: "مرتجع بيع",
    return_purchase: "مرتجع شراء",
    stocktake: "جرد",
    manual: "تعديل يدوي",
  };

  const set = (k: keyof typeof blank, v: any) =>
    setForm((f) => (f ? { ...f, [k]: v } : f));

  return (
    <>
      <div className="toolbar">
        <div className="search-wrap">
          <input
            placeholder="ابحث بالاسم أو الكود أو الباركود…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
          <span className="ic">🔍</span>
        </div>
        <select
          style={{ width: 170 }}
          value={catFilter}
          onChange={(e) => setCatFilter(e.target.value)}
        >
          <option value="">كل التصنيفات</option>
          {cats.map((c) => (
            <option key={c.id} value={c.id}>
              {c.name}
            </option>
          ))}
        </select>
        <button
          className={`btn ${onlyLow ? "accent" : "ghost"}`}
          onClick={() => setOnlyLow((v) => !v)}
        >
          ⚠️ النواقص فقط
        </button>
        <div style={{ flex: 1 }} />
        {can("products_edit") && (
          <button className="btn" onClick={() => void openNew()}>
            ＋ صنف جديد
          </button>
        )}
      </div>

      <div className="grid c4" style={{ marginBottom: 14 }}>
        <div className="stat">
          <div className="ic">📦</div>
          <div>
            <div className="lbl">عدد الأصناف المعروضة</div>
            <div className="val">{num(view.length, 0)}</div>
          </div>
        </div>
        <div className="stat">
          <div className="ic">🏦</div>
          <div>
            <div className="lbl">تقييم بسعر التكلفة</div>
            <div className="val">{can("view_cost") ? num(totals.cost) : "—"}</div>
          </div>
        </div>
        <div className="stat">
          <div className="ic">🏷️</div>
          <div>
            <div className="lbl">تقييم بسعر البيع</div>
            <div className="val">{num(totals.sell)}</div>
          </div>
        </div>
        <div className="stat accent">
          <div className="ic">⚠️</div>
          <div>
            <div className="lbl">أصناف تحت الحد الأدنى</div>
            <div className="val">{num(totals.low, 0)}</div>
          </div>
        </div>
      </div>

      <div className="table-wrap">
        {view.length === 0 ? (
          <Empty icon="📦" text="مفيش أصناف مطابقة — اضغط «صنف جديد» للإضافة" />
        ) : (
          <table>
            <thead>
              <tr>
                <th>الكود</th>
                <th>الاسم</th>
                <th>التصنيف</th>
                <th>الباركود</th>
                {can("view_cost") && <th className="num">شراء</th>}
                <th className="num">بيع</th>
                <th className="num">جملة</th>
                <th className="num">الكمية</th>
                <th className="num">الحد الأدنى</th>
                <th className="num">إجراءات</th>
              </tr>
            </thead>
            <tbody>
              {view.map((p) => {
                const low = n2(p.qty) <= n2(p.min_qty);
                return (
                  <tr key={p.id} style={!p.is_active ? { opacity: 0.5 } : undefined}>
                    <td style={{ color: "var(--ink-3)" }}>{p.code}</td>
                    <td style={{ fontWeight: 600 }}>
                      {p.name}
                      {!p.is_active && (
                        <span className="badge" style={{ marginRight: 6 }}>
                          موقوف
                        </span>
                      )}
                    </td>
                    <td>{p.category_name || "—"}</td>
                    <td style={{ fontSize: 12, color: "var(--ink-3)" }}>
                      {(p.barcodes || p.barcode || "—").split("|").join("، ")}
                    </td>
                    {can("view_cost") && (
                      <td className="num">{num(p.cost_price)}</td>
                    )}
                    <td className="num" style={{ fontWeight: 700 }}>
                      {num(p.sell_price)}
                    </td>
                    <td className="num">{num(p.wholesale_price)}</td>
                    <td className="num">
                      <span className={`badge ${low ? (n2(p.qty) <= 0 ? "danger" : "warn") : "ok"}`}>
                        {fq(p.qty)} {p.unit}
                      </span>
                    </td>
                    <td className="num">{fq(p.min_qty)}</td>
                    <td>
                      <div className="row-actions">
                        <button
                          className="icon-btn"
                          title="حركة الصنف"
                          onClick={() => void showMoves(p)}
                        >
                          📈
                        </button>
                        {can("products_edit") && (
                          <>
                            <button className="icon-btn" title="تعديل" onClick={() => openEdit(p)}>
                              ✏️
                            </button>
                            <button
                              className="icon-btn danger"
                              title="حذف"
                              onClick={() => setDelId(p.id)}
                            >
                              🗑
                            </button>
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>

      {form && (
        <Modal
          wide
          title={form.id ? "تعديل صنف" : "صنف جديد"}
          onClose={() => setForm(null)}
          footer={
            <>
              <button className="btn" onClick={() => void save()}>
                حفظ
              </button>
              <button className="btn ghost" onClick={() => setForm(null)}>
                إلغاء
              </button>
            </>
          }
        >
          <div className="grid c3">
            <Field label="الكود">
              <input value={form.code} onChange={(e) => set("code", e.target.value)} />
            </Field>
            <Field label="اسم الصنف *">
              <input
                autoFocus
                value={form.name}
                onChange={(e) => set("name", e.target.value)}
              />
            </Field>
            <Field label="اسم ثانوي">
              <input value={form.secondary_name} onChange={(e) => set("secondary_name", e.target.value)} />
            </Field>
            <Field label="الباركود" hint="اقرأه بالماسح مباشرة أو اكتبه">
              <input
                value={form.barcode}
                onChange={(e) => set("barcode", e.target.value)}
              />
            </Field>
            <Field label="باركودات إضافية" hint="باركود واحد في كل سطر">
              <textarea
                value={form.additional_barcodes}
                onChange={(e) => set("additional_barcodes", e.target.value)}
                style={{ minHeight: 74 }}
              />
            </Field>

            <Field
              label="كود الميزان (PLU)"
              hint="للأصناف اللي بتتوزن — نفس الكود المبرمج على الميزان"
            >
              <input
                value={form.plu}
                inputMode="numeric"
                onChange={(e) => set("plu", e.target.value.replace(/\D/g, ""))}
              />
            </Field>

            <Field label="التصنيف">
              <select
                value={String(form.category_id)}
                onChange={(e) => set("category_id", e.target.value)}
              >
                <option value="">— بدون —</option>
                {cats.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="الوحدة">
              <select value={form.unit} onChange={(e) => set("unit", e.target.value)}>
                {UNITS.map((u) => (
                  <option key={u}>{u}</option>
                ))}
              </select>
            </Field>
            <Field label="الحالة">
              <select
                value={String(form.is_active)}
                onChange={(e) => set("is_active", Number(e.target.value))}
              >
                <option value="1">مفعّل</option>
                <option value="0">موقوف</option>
              </select>
            </Field>

            <Field label={`سعر الشراء (${currency})`} hint="متوسط التكلفة — بيتحدّث تلقائيًا مع كل شراء">
              <input
                type="number"
                step="0.01"
                value={form.cost_price}
                onChange={(e) => set("cost_price", e.target.value)}
              />
            </Field>
            <Field label={`سعر البيع (${currency}) *`}>
              <input
                type="number"
                step="0.01"
                value={form.sell_price}
                onChange={(e) => set("sell_price", e.target.value)}
              />
            </Field>
            <Field label={`سعر الجملة (${currency})`} hint="لو فاضي هياخد سعر البيع">
              <input
                type="number"
                step="0.01"
                value={form.wholesale_price}
                onChange={(e) => set("wholesale_price", e.target.value)}
              />
            </Field>

            <Field label="الكمية الحالية">
              <input
                type="number"
                step="0.001"
                value={form.qty}
                onChange={(e) => set("qty", e.target.value)}
              />
            </Field>
            <Field label="الحد الأدنى للتنبيه">
              <input
                type="number"
                step="0.001"
                value={form.min_qty}
                onChange={(e) => set("min_qty", e.target.value)}
              />
            </Field>
            <Field label="الحد الأقصى للمخزون">
              <input type="number" step="0.001" value={form.max_qty} onChange={(e) => set("max_qty", e.target.value)} />
            </Field>
            <Field label="المورد المفضّل">
              <select value={String(form.preferred_supplier_id)} onChange={(e) => set("preferred_supplier_id", e.target.value)}>
                <option value="">— بدون —</option>
                {suppliers.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
              </select>
            </Field>
            <Field label={`سعر خاص (${currency})`}>
              <input type="number" step="0.01" value={form.price_level_special} onChange={(e) => set("price_level_special", e.target.value)} />
            </Field>
            <Field label="هامش الربح">
              <input
                disabled
                value={
                  n2(form.sell_price) > 0 && n2(form.cost_price) > 0
                    ? `${num(
                        ((n2(form.sell_price) - n2(form.cost_price)) /
                          n2(form.cost_price)) *
                          100
                      )} %`
                    : "—"
                }
              />
            </Field>
          </div>
          <div style={{ marginTop: 12 }}>
            <Field label="ملاحظات">
              <textarea
                value={form.notes}
                onChange={(e) => set("notes", e.target.value)}
              />
            </Field>
          </div>
        </Modal>
      )}

      {moves && (
        <Modal
          wide
          title={`حركة الصنف — ${moves.p.name}`}
          onClose={() => setMoves(null)}
        >
          {moves.list.length === 0 ? (
            <Empty icon="📈" text="مفيش حركة مسجلة على الصنف ده" />
          ) : (
            <div className="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th>التاريخ</th>
                    <th>النوع</th>
                    <th className="num">التغيير</th>
                    <th>ملاحظة</th>
                  </tr>
                </thead>
                <tbody>
                  {moves.list.map((m: any) => (
                    <tr key={m.id}>
                      <td style={{ fontSize: 12 }}>{dateTimeAr(m.date)}</td>
                      <td>{MOVE_AR[m.type] || m.type}</td>
                      <td className="num">
                        <span
                          className={`badge ${n2(m.qty_change) >= 0 ? "ok" : "danger"}`}
                        >
                          {n2(m.qty_change) >= 0 ? "+" : ""}
                          {fq(m.qty_change)}
                        </span>
                      </td>
                      <td style={{ fontSize: 12, color: "var(--ink-3)" }}>
                        {m.note || "—"}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Modal>
      )}

      {delId !== null && (
        <Confirm
          danger
          title="حذف صنف"
          message="متأكد إنك عايز تحذف الصنف ده؟ لو عليه حركة بيع أو شراء هيتم إيقافه بدل حذفه."
          confirmText="احذف"
          onConfirm={() => void remove(delId)}
          onClose={() => setDelId(null)}
        />
      )}
    </>
  );
}
